#!/usr/bin/env python3
"""
TEDOKI kids – Quiz-Bilder einbauen.

  python3 tools/comics_einbauen.py comics-neu/     # Bilder zuschneiden, umwandeln, einbauen
  python3 tools/comics_einbauen.py --fehlende      # zeigt, welche Quizfragen noch kein eigenes Bild haben

Die Bilddateien müssen so heißen wie in docs/COMIC-PROMPTS.md (z. B. quiz_vid_1.png).
Das Skript schneidet mittig auf 4:3 zu, verkleinert auf 1200 x 900, speichert als WebP
und legt die Datei nach app/src/main/res/drawable-nodpi/.

Benötigt: pip install pillow
"""
import pathlib
import re
import sys

ROOT = pathlib.Path(__file__).resolve().parent.parent
TARGET = ROOT / "app/src/main/res/drawable-nodpi"
QUIZ_SRC = ROOT / "app/src/main/java/com/example/data/quiz"
W, H = 1200, 900
NAME_OK = re.compile(r"^[a-z][a-z0-9_]*$")


def install(folder: pathlib.Path) -> None:
    from PIL import Image  # erst hier importieren, damit --fehlende auch ohne Pillow geht

    files = [p for p in sorted(folder.iterdir()) if p.suffix.lower() in (".png", ".jpg", ".jpeg", ".webp")]
    if not files:
        print(f"Keine Bilder in {folder} gefunden.")
        return
    TARGET.mkdir(parents=True, exist_ok=True)
    for f in files:
        name = f.stem.lower().replace("-", "_").replace(" ", "_")
        if not NAME_OK.match(name):
            print(f"  ✗ {f.name}: Name ungültig (nur a–z, 0–9 und _ erlaubt)")
            continue
        if not name.startswith("quiz_"):
            print(f"  ! {f.name}: beginnt nicht mit quiz_ – wird trotzdem übernommen")
        img = Image.open(f).convert("RGB")
        # mittig auf 4:3 zuschneiden
        w, h = img.size
        if w / h > W / H:
            new_w = int(h * W / H)
            left = (w - new_w) // 2
            img = img.crop((left, 0, left + new_w, h))
        else:
            new_h = int(w * H / W)
            top = (h - new_h) // 2
            img = img.crop((0, top, w, top + new_h))
        img = img.resize((W, H), Image.LANCZOS)
        out = TARGET / f"{name}.webp"
        img.save(out, "WEBP", quality=82, method=6)
        print(f"  ✓ {f.name} → {out.relative_to(ROOT)} ({out.stat().st_size // 1024} KB)")


def missing() -> None:
    ids = []
    for kt in sorted(QUIZ_SRC.glob("QuizModules*.kt")):
        ids += re.findall(r'id = "([cp]_[a-z0-9_]+)"', kt.read_text(encoding="utf-8"))
    have = {p.stem for p in TARGET.glob("*.*")}
    todo = []
    for qid in ids:
        shared = "quiz_" + qid[2:]
        if f"quiz_{qid}" not in have and shared not in have:
            todo.append((qid, shared))
    if not todo:
        print("Alle Quizfragen haben ein eigenes Bild. 🎉")
        return
    print(f"{len(todo)} Fragen ohne eigenes Bild (zeigen bisher die gezeichnete Ersatz-Illustration):")
    for qid, shared in todo:
        print(f"  {qid:14s} → {shared}.webp")


if __name__ == "__main__":
    if len(sys.argv) == 2 and sys.argv[1] == "--fehlende":
        missing()
    elif len(sys.argv) == 2:
        install(pathlib.Path(sys.argv[1]))
    else:
        print(__doc__)
