# TEDOKI kids – Einheitliche Quiz-Comics

Ziel: Jede Quizfrage bekommt **ein eigenes Bild im gleichen Stil**, das auf dem Handy im 4:3-Rahmen gut aussieht.
Die Frage selbst steht immer als (vorlesbarer) Text unter dem Bild – **deshalb kein Text im Bild**.

## Technische Vorgaben

| Punkt | Vorgabe |
|---|---|
| Format | **4:3 quer**, z. B. 1200 × 900 px |
| Dateiformat | WebP (Qualität ~82) – oder PNG/JPG, dann vor dem Einchecken umwandeln |
| Ablageort | `app/src/main/res/drawable-nodpi/` (**nicht** `drawable/`, sonst wird das Bild auf dem Handy bis zu 4× hochskaliert → Speicher/Absturz) |
| Dateiname | `quiz_call_1.webp` = gemeinsames Bild für Kind- **und** Elternfrage `c_call_1`/`p_call_1`  ·  `quiz_c_call_1.webp` = nur für die Kinderfrage |
| Sonderbilder | `quiz_intro_call`, `quiz_intro_camera`, `quiz_intro_whatsapp`, `quiz_intro_photos`, `quiz_intro_messages`, `quiz_intro_surf`, `quiz_intro_quiz_hero`, `quiz_feedback_success`, `quiz_feedback_retry`, `quiz_parent_discussion` |
| Bildaufbau | Hauptfigur und Handy in der **Mitte** (Sicherheitsrand ~8 % an allen Seiten), ruhiger Hintergrund, max. 2–3 Figuren |
| Text im Bild | **keiner** – keine Sprechblasen mit Wörtern, keine Überschriften. Symbole (✓, ✗, ?, Herz, Schloss, Glocke) sind okay |

Sobald eine Datei mit passendem Namen im Ordner liegt, nimmt die App sie automatisch – am Code muss nichts geändert werden.

## Stil-Block (vor jeden Prompt setzen)

```
Children's picture-book illustration, warm and friendly, clean bold outlines, soft cel shading,
bright but not neon colors (sky blue, warm yellow, soft green, coral), simple cozy background
with few details, rounded shapes, large expressive faces. Recurring characters:
"Tedo" – 8-year-old boy, short messy brown hair, blue hoodie;
"Kiki" – 8-year-old girl, dark curly hair in two puffs, yellow-striped shirt;
"Mama" – woman, brown shoulder-length hair, green cardigan;
"Papa" – man, short dark hair and beard, orange sweater.
The smartphone is a simple rounded rectangle with a blue case; screen content shown only as
simple icons and shapes. Landscape 4:3, subject centered with generous margin.
Absolutely NO text, NO letters, NO words, NO speech-bubble text anywhere in the image.
```

Gleicher Stil-Block + gleiche Figurenbeschreibung bei jedem Bild ist der wichtigste Punkt für einheitliche Bilder.
Wenn dein Bildgenerator Referenzbilder kann: das erste gelungene Bild als Stil-/Figurenreferenz für alle weiteren nutzen.

## Szenen (gemeinsam für Kind- und Elternfrage)

| Datei | Fragen | Szene (an den Stil-Block anhängen) |
|---|---|---|
| `quiz_call_1` | c/p_call_1 | Tedo on the sofa scrolls a contact list with round avatar icons on his phone, Mama's avatar with a heart is highlighted, green call button glowing. |
| `quiz_call_2` | c/p_call_2 | Tedo looks slightly surprised at his phone showing an outgoing call, his finger on the red hang-up button, small "oops" sweat drop, relaxed mood. |
| `quiz_call_3` | c/p_call_3 | Tedo holds the phone to his ear, waiting; a small clock icon and a speech-bubble icon (message symbol) float next to him, patient expression. |
| `quiz_unk_1` | c/p_unk_1 | Kiki looks at a ringing phone on the table showing a grey avatar with a question mark; she calmly walks toward Mama in the background. |
| `quiz_unk_2` | c/p_unk_2 | Kiki on the phone, a shadowy grey silhouette icon on the screen; above her head a little house icon inside a shield with a lock – she shakes her head confidently. |
| `quiz_unk_3` | c/p_unk_3 | Phone on a table showing many repeated grey call icons stacked; Kiki and Papa together tap a shield/block icon on the screen. |
| `quiz_msg_1` | c/p_msg_1 | Tedo plays with building blocks, his phone lies beside him with a small message notification dot; relaxed, no hurry, a little hourglass icon. |
| `quiz_msg_2` | c/p_msg_2 | Kiki looks puzzled at a chat with a big question-mark bubble, then types a reply bubble with a question-mark icon; thought bubble with a light bulb. |
| `quiz_msg_3` | c/p_msg_3 | Tedo looks sad at a chat bubble with a jagged red angry-face icon; Mama sits beside him with an arm around him, comforting. |
| `quiz_wa_1` | c_wa_1, p_wa_1 | Phone screen showing a group chat as many round friendly kid avatars connected in a circle, small chat bubbles with emoji icons between them. |
| `quiz_c_wa_2` | c_wa_2 | Kiki looks at her phone showing a group of grey unknown avatars with question marks; she presses a door/exit icon, calm and sure. |
| `quiz_wa_3` | c_wa_3, p_wa_2 | In a group chat a photo of a crying child appears; Tedo holds up a hand like "stop" and shows his phone to Mama. |
| `quiz_p_wa_3` | p_wa_3 | Kiki's finger hovers above a send button over a big group of avatars, a yellow pause/think icon above; she thinks before sending. |
| `quiz_cam_1` | c/p_cam_1 | Tedo holds up the phone camera and smiles at Kiki, Kiki gives a thumbs-up and nods (consent). |
| `quiz_cam_2` | c/p_cam_2 | Kiki's photo gallery shows a blurry picture; her finger taps a trash-can icon, the blurry picture flies into the bin. |
| `quiz_cam_3` | c/p_cam_3 | Phone screen shows a photo of a friend in front of a house; the house number area is highlighted with a red circle and a magnifier icon. |
| `quiz_oth_1` | c/p_oth_1 | Tedo holds a phone with a funny photo of a friend making a face; a big question mark between the phone and a group-chat icon. |
| `quiz_oth_2` | c/p_oth_2 | Kiki says (gesture, no text) "please don't" with crossed hands; Tedo puts his phone away and nods, respectful. |
| `quiz_p_oth_3` | p_oth_3 | Group photo of several children on a phone, Papa and Tedo look at it together, a lock icon and question mark above. |
| `quiz_vn_1` | c/p_vn_1 | Tedo with headphones listens to a voice message (sound-wave icon on screen) later in a quiet room, relaxed; a small clock shows "later". |
| `quiz_vn_2` | c/p_vn_2 | Kiki wants to record a voice message, many other kids chat behind her; she walks to a quiet corner, microphone icon on screen. |
| `quiz_blk_1` | c/p_blk_1 | Phone buzzing with many annoying message bubbles; Kiki shows it to Mama, both look determined. |
| `quiz_blk_2` | c/p_blk_2 | Phone screen with a contact avatar and a big shield icon closing like a door between the avatar and Tedo; messages bounce off the shield. |
| `quiz_dat_1` | c/p_dat_1 | Tedo holds a treasure chest with icons inside (house, school, phone, birthday cake), lock on the chest, smiling. |
| `quiz_dat_2` | c/p_dat_2 | Chat from a grey unknown avatar with icons house + school + name tag; Kiki holds up a stop-sign-shaped hand, then shows Papa. |
| `quiz_p_dat_3` | p_dat_3 | Mama and Kiki sit together at the kitchen table looking at a tablet, open friendly conversation, a small shield with heart icon. |
| `quiz_snd_1` | c/p_snd_1 | Tedo holds his phone, a photo ready to send; above him a checklist icon with three ticks; his finger waits above the send button. |
| `quiz_snd_2` | c/p_snd_2 | Kiki laughs at a funny picture on her phone, then pauses and imagines a sad friend in a thought bubble; send button greyed. |
| `quiz_p_snd_3` | p_snd_3 | Tedo shows his phone to Papa, both look at the screen together, Papa gives a calm thumbs-up. |
| `quiz_surf_1` | c_surf_1, p_surf_2 | Tedo turns away from a tablet showing a dark scary shape (not graphic), and runs to Mama who opens her arms. |
| `quiz_c_surf_2` | c_surf_2 | Tablet shows a colorful form with input fields and a sticker prize icon; Kiki pulls her hand back, lock icon above. |
| `quiz_surf_3` | c_surf_3, p_surf_4 | Tablet shows a flashing gift box with stars and a big fake "win" phone icon; Tedo looks suspicious with a magnifying glass. |
| `quiz_c_surf_4` | c_surf_4 | Kiki plays an online game, a chat icon from a grey unknown avatar pops up with a house and meeting-point icon; she closes it and calls Mama. |
| `quiz_p_surf_1` | p_surf_1 | Child-safe "garden": a tablet screen designed like a walled garden with friendly icons (book, mouse, music), Papa and Tedo explore together. |
| `quiz_p_surf_3` | p_surf_3 | Kitchen timer/clock and a tablet on the table; Tedo puts the tablet away happily and goes to play football. |

### Neu: Videos & Spiele (für automatisch erkannte Apps)

| Datei | Fragen | Szene (an den Stil-Block anhängen) |
|---|---|---|
| `quiz_vid_1` | c/p_vid_1 | Tedo on the sofa, phone shows a video player with a big "next" arrow icon and a small countdown circle; he calmly puts the phone face-down on the table, a little clock icon above. |
| `quiz_vid_2` | c/p_vid_2 | Kiki looks uneasy at a tablet showing a dark cloud shape (not scary in detail); she presses a big pause icon and turns to Papa who sits next to her. |
| `quiz_vid_3` | c/p_vid_3 | Phone screen with a video and a comment bubble from a grey unknown avatar containing house and birthday-cake icons; Tedo shakes his head and shows the phone to Mama. |
| `quiz_game_1` | c/p_game_1 | Kiki plays a colorful game on her phone; a chat bubble from a grey avatar offers a shiny gem icon in exchange for a key icon; Kiki holds the key icon close to her chest, determined. |
| `quiz_game_2` | c/p_game_2 | A big blinking shop button with a gem icon and a coin stack on Tedo's phone screen; Tedo raises his finger and looks over to Mama with a questioning face. |
| `quiz_game_3` | c/p_game_3 | Tedo after losing a game, small grey storm-cloud bubbles coming from the phone; he presses a shield/block icon and Papa puts a hand on his shoulder. |

## Sonderbilder

| Datei | Szene |
|---|---|
| `quiz_intro_quiz_hero` | Tedo in a little superhero cape holds his phone proudly, confetti, friendly. |
| `quiz_intro_call` | Tedo holds the phone to his ear, big green phone icon beside him. |
| `quiz_intro_camera` | Tedo takes a photo of a flower, big camera icon beside him. |
| `quiz_intro_whatsapp` | Kiki with phone, generic green chat-bubble icon (no WhatsApp logo). |
| `quiz_intro_photos` | Kiki scrolls a photo gallery of colorful thumbnails. |
| `quiz_intro_messages` | Tedo types a message, blue chat-bubble icon. |
| `quiz_intro_surf` | Tedo and Kiki look at a tablet with a globe icon. |
| `quiz_feedback_success` | Tedo and Kiki cheer with arms up, confetti and a big green check mark. |
| `quiz_feedback_retry` | Kiki thinks with her finger on her chin, light bulb, friendly – no failure mood. |
| `quiz_parent_discussion` | Mama/Papa and child sit together on the sofa looking at a phone. |

Hinweis: Echte Marken (WhatsApp-Logo usw.) im Bild weglassen und durch neutrale Symbole ersetzen.

## So werden die Bilder schön und einheitlich (Schritt für Schritt)

1. **Erst die Figuren festlegen, dann die Szenen.** Mit dem Stil-Block oben zuerst ein „Figurenblatt“ erzeugen:
   `Character sheet: Tedo, Kiki, Mama and Papa standing side by side, front view, neutral pose, plain white background` + Stil-Block.
   So lange neu erzeugen, bis es wirklich gefällt. Dieses Bild ist ab jetzt die **Vorlage**.
2. **Bei jedem weiteren Bild das Figurenblatt als Referenzbild mitgeben** („Use the attached image as character and style reference“).
   Das ist der wichtigste Trick – ohne Referenz sehen die Figuren jedes Mal anders aus.
3. **Immer derselbe Bildgenerator, dieselben Einstellungen, Querformat 4:3.**
4. **Pro Szene 2–4 Varianten erzeugen und die beste nehmen.** Bilder mit Text, Buchstaben oder Markenlogos aussortieren.
5. Bilder **genau so benennen wie in der Tabelle** (z. B. `quiz_vid_1.png`) und in einen Ordner legen, z. B. `comics-neu/`.
6. Einbauen mit dem Skript (macht Zuschnitt 4:3, Größe 1200 × 900, WebP und den richtigen Ordner):
   ```
   pip install pillow
   python3 tools/comics_einbauen.py comics-neu/
   ```
7. Welche Fragen noch kein eigenes Bild haben, zeigt:
   ```
   python3 tools/comics_einbauen.py --fehlende
   ```

## Neue Apps und Quiz-Themen

TEDOKI ordnet jede App automatisch einem Quiz-Thema zu (bekannte App → Herstellerangabe wie „Spiel“ oder „Video“ →
was die App darf, z. B. Kamera oder Mikrofon). Apps ohne Internetzugriff brauchen kein Quiz.
Eltern können das Thema im Elternbereich unter **Medienpädagogik → Quiz-Themen für weitere Apps** ändern oder abschalten.
Bilder brauchen dafür nur die Themen-Bilder oben – nicht ein Bild pro App.

