package com.example.ui.settings

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.DropdownMenu
import androidx.compose.material3.DropdownMenuItem
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.quiz.AppQuizClassifier
import com.example.model.ButtonType
import com.example.model.LauncherButton
import com.example.model.quiz.QuizCategory
import com.example.ui.theme.AssistiveBlue
import com.example.ui.theme.AssistiveBorder
import com.example.ui.theme.AssistiveSurface
import com.example.ui.theme.AssistiveTextMuted
import com.example.ui.theme.AssistiveTextPrimary
import com.example.ui.theme.AssistiveTextSecondary

/**
 * Elternbereich: Für jede auf dem Homescreen platzierte App sehen, welches Quiz-Thema
 * TEDOKI vorschlägt (und warum) – und es bei Bedarf selbst ändern oder abschalten.
 */
@Composable
fun AppQuizTopicsSection(buttons: List<LauncherButton>) {
    val apps = buttons
        .filter { it.type == ButtonType.APP && it.packageName.isNotBlank() }
        .distinctBy { it.packageName }

    // Neu zeichnen, wenn die Eltern ein Thema ändern
    AppQuizClassifier.version.intValue

    Text(
        text = "QUIZ-THEMEN FÜR WEITERE APPS",
        fontSize = 11.sp,
        fontWeight = FontWeight.SemiBold,
        letterSpacing = 0.8.sp,
        color = AssistiveTextMuted,
        modifier = Modifier.padding(start = 4.dp, top = 12.dp)
    )

    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = AssistiveSurface),
        border = BorderStroke(1.dp, AssistiveBorder),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(14.dp)) {
            Text(
                text = "TEDOKI schlägt für jede App automatisch ein passendes Quiz vor – auch für Apps, die es nicht kennt. " +
                    "Es schaut dafür, was der Hersteller angibt (z. B. „Spiel“) und was die App darf (Kamera, Mikrofon, Kontakte, Internet). " +
                    "Passt der Vorschlag nicht, tippe auf das Thema und wähle ein anderes.",
                fontSize = 12.sp,
                color = AssistiveTextSecondary,
                lineHeight = 17.sp
            )

            if (apps.isEmpty()) {
                Text(
                    text = "Noch keine weiteren Apps auf dem Homescreen.",
                    fontSize = 13.sp,
                    color = AssistiveTextMuted
                )
            }

            apps.forEach { app -> AppTopicRow(app) }
        }
    }
}

@Composable
private fun AppTopicRow(app: LauncherButton) {
    val pkg = app.packageName
    val hasOverride = AppQuizClassifier.hasOverride(pkg)
    val suggestion = AppQuizClassifier.suggest(pkg)
    val current: QuizCategory? = if (hasOverride) AppQuizClassifier.overrideFor(pkg) else suggestion.category
    var menuOpen by remember { mutableStateOf(false) }

    Row(verticalAlignment = Alignment.CenterVertically) {
        Column(modifier = Modifier.weight(1f)) {
            Text(text = app.title, fontSize = 15.sp, fontWeight = FontWeight.SemiBold, color = AssistiveTextPrimary)
            Text(
                text = if (hasOverride) "von euch festgelegt" else "Vorschlag: ${suggestion.reasonDe}",
                fontSize = 11.sp,
                color = AssistiveTextMuted
            )
        }
        Spacer(modifier = Modifier.width(8.dp))
        Box {
            OutlinedButton(
                onClick = { menuOpen = true },
                shape = RoundedCornerShape(10.dp),
                border = BorderStroke(1.dp, AssistiveBlue),
                contentPadding = PaddingValues(horizontal = 10.dp, vertical = 4.dp)
            ) {
                Text(
                    text = current?.titleDe ?: "Kein Quiz",
                    fontSize = 12.sp,
                    color = AssistiveBlue,
                    fontWeight = FontWeight.SemiBold
                )
            }
            DropdownMenu(expanded = menuOpen, onDismissRequest = { menuOpen = false }) {
                DropdownMenuItem(
                    text = { Text("Automatisch (${suggestion.category?.titleDe ?: "kein Quiz"})") },
                    onClick = {
                        AppQuizClassifier.setOverride(pkg, null)
                        menuOpen = false
                    }
                )
                QuizCategory.values().forEach { cat ->
                    DropdownMenuItem(
                        text = { Text(cat.titleDe) },
                        onClick = {
                            AppQuizClassifier.setOverride(pkg, cat)
                            menuOpen = false
                        }
                    )
                }
                DropdownMenuItem(
                    text = { Text("Kein Quiz (sofort frei)") },
                    onClick = {
                        AppQuizClassifier.setOverride(pkg, null, noQuiz = true)
                        menuOpen = false
                    }
                )
            }
        }
    }
}
