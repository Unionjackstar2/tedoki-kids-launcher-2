package com.example.ui.settings

import androidx.compose.foundation.layout.windowInsetsPadding
import com.example.ui.components.launcherSafe
import android.net.Uri
import android.provider.Settings
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.platform.LocalSoftwareKeyboardController
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.model.LauncherSettings
import com.example.ui.theme.AssistiveBackground
import com.example.ui.theme.AssistiveBlue
import com.example.ui.theme.AssistiveBorder
import com.example.ui.theme.AssistiveSurface
import com.example.ui.theme.AssistiveTextPrimary
import com.example.ui.theme.AssistiveTextSecondary
import com.example.ui.theme.LocalIsDarkTheme

@Composable
fun ParentSettingsScreen(
    currentSettings: LauncherSettings,
    pedagogyPreferences: com.example.data.quiz.PedagogyPreferences? = null,
    onSaveSettings: (LauncherSettings) -> Unit,
    onReturnToHome: () -> Unit,
    onLanguageChange: (String) -> Unit,
    onResetLauncher: (() -> Unit)? = null
) {
    val context = LocalContext.current
    val focusManager = LocalFocusManager.current
    val keyboardController = LocalSoftwareKeyboardController.current
    val scrollState = rememberScrollState()
    val isDark = LocalIsDarkTheme.current

    val pedPrefs = remember(pedagogyPreferences) {
        pedagogyPreferences ?: com.example.data.quiz.PedagogyPreferences(context)
    }

    val safeReturnToHome = {
        focusManager.clearFocus()
        keyboardController?.hide()
        onReturnToHome()
    }

    BackHandler { safeReturnToHome() }

    var layoutStyle by remember { mutableStateOf(currentSettings.layoutStyle) }
    var buttons by remember { mutableStateOf(currentSettings.buttons.toMutableList()) }
    var emergencyNumber by remember { mutableStateOf(currentSettings.emergencyNumber) }
    var emergencyContactName by remember { mutableStateOf(currentSettings.emergencyContactName) }
    var pin by remember { mutableStateOf(currentSettings.pin) }
    var currentLanguage by remember { mutableStateOf(currentSettings.language) }
    var themeMode by remember(currentSettings.themeMode) { mutableStateOf(currentSettings.themeMode) }

    var showAppsSubScreen by remember { mutableStateOf(false) }
    var showEmergencySubScreen by remember { mutableStateOf(false) }
    var showBrowserSubScreen by remember { mutableStateOf(false) }
    var showContactsSubScreen by remember { mutableStateOf(false) }
    var showPinSubScreen by remember { mutableStateOf(false) }
    var showLockscreenSubScreen by remember { mutableStateOf(false) }
    var showResetSubScreen by remember { mutableStateOf(false) }
    var showSystemSubScreen by remember { mutableStateOf(false) }
    var showPedagogySubScreen by remember { mutableStateOf(false) }

    var childName by remember(currentSettings.childName) { mutableStateOf(currentSettings.childName) }
    var childAvatar by remember(currentSettings.childAvatar) { mutableStateOf(currentSettings.childAvatar) }
    var showAvatarModal by remember { mutableStateOf(false) }

    val childAvatarPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            val permanentUri = com.example.util.ImageStorageUtils.saveImageToInternalStorage(context, uri, "child_avatar") ?: uri.toString()
            childAvatar = permanentUri
            onSaveSettings(currentSettings.copy(childAvatar = permanentUri))
        }
    }

    if (showPinSubScreen) {
        PinSettingsSubScreen(
            currentSettings = currentSettings,
            onSaveSettings = { updated ->
                pin = updated.pin
                onSaveSettings(updated)
            },
            onBack = { showPinSubScreen = false }
        )
        return
    }

    if (showAppsSubScreen) {
        AppsSettingsSubScreen(
            currentSettings = currentSettings,
            onSaveSettings = { updated ->
                buttons = updated.buttons.toMutableList()
                onSaveSettings(updated)
            },
            onBack = { showAppsSubScreen = false }
        )
        return
    }

    if (showEmergencySubScreen) {
        EmergencySettingsSubScreen(
            currentSettings = currentSettings,
            onSaveSettings = onSaveSettings,
            onBack = { showEmergencySubScreen = false }
        )
        return
    }

    if (showBrowserSubScreen) {
        BrowserSettingsSubScreen(
            currentSettings = currentSettings,
            onSaveSettings = onSaveSettings,
            onBack = { showBrowserSubScreen = false }
        )
        return
    }

    if (showContactsSubScreen) {
        ContactsSettingsSubScreen(
            currentSettings = currentSettings,
            onSaveSettings = onSaveSettings,
            onBack = { showContactsSubScreen = false }
        )
        return
    }

    if (showLockscreenSubScreen) {
        LockscreenSettingsSubScreen(
            currentSettings = currentSettings,
            onSaveSettings = onSaveSettings,
            onBack = { showLockscreenSubScreen = false }
        )
        return
    }

    if (showResetSubScreen) {
        ResetLauncherSubScreen(
            currentSettings = currentSettings,
            onResetLauncher = {
                showResetSubScreen = false
                if (onResetLauncher != null) {
                    onResetLauncher()
                } else {
                    pedPrefs.resetAllPedagogy()
                    onSaveSettings(LauncherSettings(isSetupComplete = false))
                    onReturnToHome()
                }
            },
            onBack = { showResetSubScreen = false }
        )
        return
    }

    if (showSystemSubScreen) {
        SystemSettingsSubScreen(
            currentSettings = currentSettings,
            onSaveSettings = onSaveSettings,
            onBack = { showSystemSubScreen = false }
        )
        return
    }

    if (showPedagogySubScreen) {
        PedagogySettingsSubScreen(
            currentSettings = currentSettings,
            pedagogyPreferences = pedPrefs,
            onBack = { showPedagogySubScreen = false }
        )
        return
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(AssistiveBackground)
            .windowInsetsPadding(WindowInsets.launcherSafe)
            .padding(top = 8.dp)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 20.dp)
        ) {
            // Screen Header
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 16.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    modifier = Modifier.weight(1f, fill = false),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(42.dp)
                            .clip(CircleShape)
                            .background(AssistiveSurface)
                            .border(1.dp, AssistiveBorder, CircleShape),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Settings,
                            contentDescription = null,
                            tint = AssistiveBlue,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                    Text(
                        text = stringResource(R.string.settings_title),
                        fontSize = 20.sp,
                        fontWeight = FontWeight.Bold,
                        color = AssistiveTextPrimary,
                        maxLines = 1,
                        overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
                    )
                }

                Spacer(modifier = Modifier.width(8.dp))

                // Compact Pill Language Selector
                Row(
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .background(AssistiveSurface)
                        .border(1.dp, AssistiveBorder, RoundedCornerShape(20.dp))
                        .padding(3.dp),
                    horizontalArrangement = Arrangement.spacedBy(2.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(16.dp))
                            .background(if (currentLanguage == "de") AssistiveBlue else Color.Transparent)
                            .clickable {
                                currentLanguage = "de"
                                onLanguageChange("de")
                            }
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                            .testTag("lang_toggle_de"),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "DE",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (currentLanguage == "de") Color.White else AssistiveTextSecondary
                        )
                    }

                    Box(
                        modifier = Modifier
                            .clip(RoundedCornerShape(16.dp))
                            .background(if (currentLanguage == "en") AssistiveBlue else Color.Transparent)
                            .clickable {
                                currentLanguage = "en"
                                onLanguageChange("en")
                            }
                            .padding(horizontal = 10.dp, vertical = 6.dp)
                            .testTag("lang_toggle_en"),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "EN",
                            fontSize = 12.sp,
                            fontWeight = FontWeight.Bold,
                            color = if (currentLanguage == "en") Color.White else AssistiveTextSecondary
                        )
                    }
                }
            }

            // Scrollable Settings Content
            Column(
                modifier = Modifier
                    .weight(1f)
                    .verticalScroll(scrollState),
                verticalArrangement = Arrangement.spacedBy(16.dp)
            ) {
                ProfileSection(
                    currentSettings = currentSettings,
                    onSaveSettings = onSaveSettings,
                    isDark = isDark,
                    childName = childName,
                    childAvatarPickerLauncher = childAvatarPickerLauncher,
                    childAvatar = childAvatar,
                    showAvatarModal = showAvatarModal,
                    onChildAvatarChange = { childAvatar = it },
                    onShowAvatarModalChange = { showAvatarModal = it }
                )

                HomescreenSection(
                    currentSettings = currentSettings,
                    onSaveSettings = onSaveSettings,
                    isDark = isDark,
                    buttons = buttons,
                    layoutStyle = layoutStyle,
                    themeMode = themeMode,
                    onLayoutStyleChange = { layoutStyle = it },
                    onThemeModeChange = { themeMode = it },
                    onShowAppsSubScreenChange = { showAppsSubScreen = it }
                )

                CommunicationSection(
                    currentSettings = currentSettings,
                    isDark = isDark,
                    onShowEmergencySubScreenChange = { showEmergencySubScreen = it },
                    onShowBrowserSubScreenChange = { showBrowserSubScreen = it },
                    onShowContactsSubScreenChange = { showContactsSubScreen = it }
                )

                SecuritySection(
                    currentSettings = currentSettings,
                    isDark = isDark,
                    onShowPinSubScreenChange = { showPinSubScreen = it },
                    onShowLockscreenSubScreenChange = { showLockscreenSubScreen = it },
                    onShowPedagogySubScreenChange = { showPedagogySubScreen = it }
                )

                SystemSection(
                    isDark = isDark,
                    safeReturnToHome = safeReturnToHome,
                    onShowResetSubScreenChange = { showResetSubScreen = it },
                    onShowSystemSubScreenChange = { showSystemSubScreen = it }
                )

                Spacer(modifier = Modifier.height(24.dp))
            }
        }
    }
}

@Composable
internal fun ThemeTogglePill(
    title: String,
    isSelected: Boolean,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    val isDark = LocalIsDarkTheme.current
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(16.dp))
            .border(
                2.dp,
                if (isSelected) AssistiveBlue else AssistiveBorder,
                RoundedCornerShape(16.dp)
            )
            .background(
                if (isSelected) {
                    if (isDark) Color(0xFF1E3A8A).copy(alpha = 0.5f) else Color(0xFFEFF6FF)
                } else {
                    if (isDark) Color(0xFF0F172A) else Color(0xFFF8FAFC)
                }
            )
            .clickable(onClick = onClick)
            .padding(vertical = 12.dp, horizontal = 4.dp),
        contentAlignment = Alignment.Center
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.spacedBy(4.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = title,
                tint = if (isSelected) AssistiveBlue else AssistiveTextSecondary,
                modifier = Modifier.size(22.dp)
            )
            Text(
                text = title,
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = if (isSelected) AssistiveBlue else AssistiveTextPrimary,
                maxLines = 1,
                overflow = androidx.compose.ui.text.style.TextOverflow.Ellipsis
            )
        }
    }
}

@Composable
internal fun LayoutTogglePill(
    title: String,
    isSelected: Boolean,
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    modifier: Modifier = Modifier,
    onClick: () -> Unit
) {
    val isDark = LocalIsDarkTheme.current
    Box(
        modifier = modifier
            .clip(RoundedCornerShape(18.dp))
            .border(
                2.dp,
                if (isSelected) AssistiveBlue else AssistiveBorder,
                RoundedCornerShape(18.dp)
            )
            .background(
                if (isSelected) {
                    if (isDark) Color(0xFF1E3A8A).copy(alpha = 0.5f) else Color(0xFFEFF6FF)
                } else {
                    if (isDark) Color(0xFF0F172A) else Color(0xFFF8FAFC)
                }
            )
            .clickable(onClick = onClick)
            .padding(vertical = 14.dp, horizontal = 12.dp),
        contentAlignment = Alignment.Center
    ) {
        Row(
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(8.dp)
        ) {
            Icon(
                imageVector = icon,
                contentDescription = title,
                tint = if (isSelected) AssistiveBlue else AssistiveTextSecondary,
                modifier = Modifier.size(22.dp)
            )
            Text(
                text = title,
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = if (isSelected) AssistiveBlue else AssistiveTextPrimary
            )
        }
    }
}

@Composable
internal fun SettingsSectionLabel(
    title: String,
    modifier: Modifier = Modifier
) {
    Text(
        text = title.uppercase(),
        fontSize = 12.sp,
        fontWeight = FontWeight.Bold,
        letterSpacing = 0.8.sp,
        color = Color(0xFF64748B),
        modifier = modifier.padding(start = 4.dp, top = 6.dp)
    )
}
