package com.example.ui.setup

import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowForward
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Quiz
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.ui.theme.AssistiveAmber
import com.example.ui.theme.AssistiveAmberLight
import com.example.ui.theme.AssistiveBlue
import com.example.ui.theme.AssistiveBorder
import com.example.ui.theme.AssistiveGreen
import com.example.ui.theme.AssistiveGreenLight
import com.example.ui.theme.AssistiveSurface
import com.example.ui.theme.AssistiveTextPrimary
import com.example.ui.theme.AssistiveTextSecondary

// =====================================================================================
// STEP 1: WELCOME
// =====================================================================================
@Composable
internal fun WelcomeStep(
    isEn: Boolean,
    onNext: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 24.dp, vertical = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.fillMaxWidth()
        ) {
            Spacer(modifier = Modifier.height(16.dp))

            // Hero Brand Logo
            Image(
                painter = painterResource(id = R.drawable.img_tedoki_logo),
                contentDescription = "TEDOKI Kids Launcher Logo",
                modifier = Modifier
                    .size(96.dp)
                    .clip(RoundedCornerShape(22.dp)),
                contentScale = ContentScale.Fit
            )

            Spacer(modifier = Modifier.height(18.dp))

            Text(
                text = if (isEn) "Welcome to TEDOKI Kids" else "Willkommen bei TEDOKI Kids",
                fontSize = 26.sp,
                fontWeight = FontWeight.Bold,
                color = AssistiveTextPrimary,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = if (isEn)
                    "A thoughtfully simplified launcher providing a safe, calm, and playful smartphone start for your child."
                else
                    "Ein bewusst reduzierter Launcher, mit dem Kinder ihre ersten Schritte mit dem Smartphone sicher, ruhig und spielerisch unternehmen können.",
                fontSize = 15.sp,
                color = AssistiveTextSecondary,
                textAlign = TextAlign.Center,
                lineHeight = 22.sp,
                modifier = Modifier.padding(horizontal = 8.dp)
            )

            Spacer(modifier = Modifier.height(24.dp))

            // 3 Key highlights
            WelcomeFeatureCard(
                icon = "🛡️",
                title = if (isEn) "Protected Space" else "Geschützter Raum",
                description = if (isEn)
                    "No ad traps, no social media doomscrolling, and no uncontrolled access to the open web."
                else
                    "Keine Werbefallen, keine Social-Media-Sogwirkung und kein unkontrollierter Zugriff auf das offene Internet."
            )

            Spacer(modifier = Modifier.height(12.dp))

            WelcomeFeatureCard(
                icon = "🧘",
                title = if (isEn) "Thoughtfully Simplified" else "Bewusst reduziert",
                description = if (isEn)
                    "Large tiles, clear typography, and a calm, clean design for a stress-free experience."
                else
                    "Große Kacheln, klare Schriften und ein ruhiges, aufgeräumtes Design für beste Übersicht."
            )

            Spacer(modifier = Modifier.height(12.dp))

            WelcomeFeatureCard(
                icon = "🌱",
                title = if (isEn) "Educational Guidance" else "Pädagogisch begleitet",
                description = if (isEn)
                    "Features aren't silently banned; they are unlocked together through kid-friendly quizzes and reflections."
                else
                    "Funktionen werden nicht stumm verboten, sondern gemeinsam mit deinem Kind über kindgerechte Quizze freigeschaltet."
            )
        }

        Spacer(modifier = Modifier.height(24.dp))

        Button(
            onClick = onNext,
            shape = RoundedCornerShape(16.dp),
            colors = ButtonDefaults.buttonColors(containerColor = AssistiveBlue),
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp)
                .testTag("welcome_next_button")
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(8.dp)
            ) {
                Text(
                    text = if (isEn) "Get Started" else "Jetzt einrichten",
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
                Icon(
                    imageVector = Icons.Default.ArrowForward,
                    contentDescription = null,
                    tint = Color.White
                )
            }
        }
    }
}

@Composable
internal fun WelcomeFeatureCard(
    icon: String,
    title: String,
    description: String
) {
    Card(
        shape = RoundedCornerShape(18.dp),
        colors = CardDefaults.cardColors(containerColor = AssistiveSurface),
        border = BorderStroke(1.dp, AssistiveBorder),
        elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.Top,
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Text(text = icon, fontSize = 28.sp)
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = AssistiveTextPrimary
                )
                Spacer(modifier = Modifier.height(3.dp))
                Text(
                    text = description,
                    fontSize = 13.sp,
                    color = AssistiveTextSecondary,
                    lineHeight = 18.sp
                )
            }
        }
    }
}

// =====================================================================================
// STEP 2: PEDAGOGY CONCEPT
// =====================================================================================
@Composable
internal fun PedagogyConceptStep(
    isEn: Boolean,
    onNext: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 24.dp, vertical = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.fillMaxWidth()
        ) {
            Spacer(modifier = Modifier.height(12.dp))

            Box(
                modifier = Modifier
                    .size(86.dp)
                    .clip(CircleShape)
                    .background(AssistiveGreenLight),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Quiz,
                    contentDescription = null,
                    tint = AssistiveGreen,
                    modifier = Modifier.size(46.dp)
                )
            }

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = if (isEn) "Unlock Together" else "Gemeinsam freischalten",
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                color = AssistiveTextPrimary,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = if (isEn) "Understanding instead of just banning" else "Verstehen statt bloßem Verbieten",
                fontSize = 15.sp,
                fontWeight = FontWeight.SemiBold,
                color = AssistiveGreen,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Explanation Card
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = AssistiveSurface),
                border = BorderStroke(1.dp, AssistiveBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    ConceptStepRow(
                        badgeNumber = "1",
                        badgeColor = AssistiveBlue,
                        title = if (isEn) "Child completes a short quiz" else "Kind absolviert ein Kurz-Quiz",
                        text = if (isEn)
                            "Before your child uses a feature (e.g. Camera, Calls, Browser), they answer 2 short questions with practical tips (e.g. 'Ask for permission first')."
                        else
                            "Bevor dein Kind z. B. fotografiert oder telefoniert, beantwortet es 2 kurze Fragen mit praktischen Tipps (z. B. 'Vorher um Erlaubnis fragen')."
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    ConceptStepRow(
                        badgeNumber = "2",
                        badgeColor = AssistiveAmber,
                        title = if (isEn) "Handover to parents & media tips" else "Übergabe an Eltern & Medientipps",
                        text = if (isEn)
                            "As a parent, you receive compact pedagogical insights and answer brief reflection questions."
                        else
                            "Du als Elternteil erhältst kompakte Hintergrundtipps und beantwortest kurze Reflexionsfragen zur Medienbegleitung."
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    ConceptStepRow(
                        badgeNumber = "3",
                        badgeColor = AssistiveGreen,
                        title = if (isEn) "Unlock via Parent PIN" else "Freischaltung per Eltern-PIN",
                        text = if (isEn)
                            "The feature is activated with your 4-digit parent PIN. Quick refreshers are scheduled after 30 and 90 days."
                        else
                            "Mit deiner 4-stelligen Eltern-PIN wird die Funktion anschließend aktiviert. Nach 30 und 90 Tagen gibt es kurze Auffrischungsfragen."
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Yellow note
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = AssistiveAmberLight),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Info,
                        contentDescription = null,
                        tint = AssistiveAmber,
                        modifier = Modifier.size(24.dp)
                    )
                    Text(
                        text = if (isEn)
                            "You maintain full control in the Parent Dashboard at all times and can reset quizzes whenever needed."
                        else
                            "Du behältst im Elterndashboard jederzeit die volle Kontrolle und kannst Quizze bei Bedarf zurücksetzen.",
                        fontSize = 13.sp,
                        color = Color(0xFF78350F),
                        lineHeight = 18.sp
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        Button(
            onClick = onNext,
            shape = RoundedCornerShape(16.dp),
            colors = ButtonDefaults.buttonColors(containerColor = AssistiveBlue),
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp)
                .testTag("pedagogy_concept_next_button")
        ) {
            Text(
                text = if (isEn) "Next: Child Profile" else "Weiter: Angaben zum Kind",
                fontSize = 17.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
        }
    }
}

@Composable
internal fun ConceptStepRow(
    badgeNumber: String,
    badgeColor: Color,
    title: String,
    text: String
) {
    Row(
        verticalAlignment = Alignment.Top,
        horizontalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Box(
            modifier = Modifier
                .size(28.dp)
                .clip(CircleShape)
                .background(badgeColor),
            contentAlignment = Alignment.Center
        ) {
            Text(
                text = badgeNumber,
                color = Color.White,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold
            )
        }
        Column {
            Text(
                text = title,
                fontSize = 15.sp,
                fontWeight = FontWeight.Bold,
                color = AssistiveTextPrimary
            )
            Spacer(modifier = Modifier.height(2.dp))
            Text(
                text = text,
                fontSize = 13.sp,
                color = AssistiveTextSecondary,
                lineHeight = 18.sp
            )
        }
    }
}
