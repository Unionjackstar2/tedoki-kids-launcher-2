package com.example.ui.home

import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.foundation.layout.windowInsetsPadding
import com.example.ui.components.launcherSafe
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.gestures.detectDragGesturesAfterLongPress
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.itemsIndexed
import androidx.compose.foundation.lazy.itemsIndexed
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberUpdatedState
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.geometry.Rect
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.graphicsLayer
import androidx.compose.ui.hapticfeedback.HapticFeedbackType
import androidx.compose.ui.input.pointer.pointerInput
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.layout.boundsInRoot
import androidx.compose.ui.layout.onGloballyPositioned
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalHapticFeedback
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.zIndex
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.material3.Button
import androidx.compose.animation.core.*
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.R
import com.example.data.quiz.PedagogyPreferences
import com.example.model.LauncherButton
import com.example.model.LauncherSettings
import com.example.model.LayoutStyle
import com.example.model.quiz.AppPedagogyStatus
import com.example.model.quiz.QuizCategory
import com.example.model.quiz.ReviewDueState
import com.example.ui.components.PinKeypadDialog
import com.example.ui.components.SosModalDialog
import com.example.ui.theme.AssistiveBackground
import com.example.ui.theme.AssistiveBorder
import com.example.ui.theme.AssistiveSurface
import com.example.ui.theme.AssistiveTextPrimary
import com.example.ui.theme.AssistiveTextSecondary
import com.example.ui.theme.LocalIsDarkTheme
import kotlinx.coroutines.delay
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

@Composable
fun SimplifiedHomeScreen(
    settings: LauncherSettings,
    pedagogyStatuses: Map<String, AppPedagogyStatus> = emptyMap(),
    celebrationMessage: String? = null,
    onDismissCelebration: () -> Unit = {},
    onButtonClick: (LauncherButton) -> Unit,
    onTriggerQuiz: (LauncherButton, String, QuizCategory, ReviewDueState) -> Unit = { _, _, _, _ -> },
    onOpenParentSettings: () -> Unit,
    onSosTriggered: () -> Unit,
    onReorderButtons: (List<LauncherButton>) -> Unit = {}
) {
    val context = LocalContext.current
    val haptic = LocalHapticFeedback.current

    LaunchedEffect(Unit) {
        com.example.sms.SmsRepository.init(context)
    }

    var buttonsList by remember(settings.buttons) { mutableStateOf(settings.buttons) }
    var draggingButtonId by remember { mutableStateOf<String?>(null) }
    var startSlotIndex by remember { mutableStateOf<Int?>(null) }
    var targetSlot by remember { mutableStateOf<Int?>(null) }
    var startSlotRect by remember { mutableStateOf(Rect.Zero) }
    var dragOffset by remember { mutableStateOf(Offset.Zero) }
    val slotBounds = remember { mutableStateMapOf<Int, Rect>() }

    val currentButtonsList by rememberUpdatedState(buttonsList)
    val currentOnReorderButtons by rememberUpdatedState(onReorderButtons)

    LaunchedEffect(settings.buttons) {
        if (draggingButtonId == null) {
            buttonsList = settings.buttons
        }
    }

    val displayButtons = remember(buttonsList, draggingButtonId, targetSlot) {
        val currentDraggingId = draggingButtonId
        val currentTargetSlot = targetSlot
        if (currentDraggingId == null || currentTargetSlot == null) {
            buttonsList
        } else {
            val fromIndex = buttonsList.indexOfFirst { it.id == currentDraggingId }
            if (fromIndex != -1 && fromIndex != currentTargetSlot && currentTargetSlot in buttonsList.indices) {
                val list = buttonsList.toMutableList()
                val item = list.removeAt(fromIndex)
                list.add(currentTargetSlot, item)
                list
            } else {
                buttonsList
            }
        }
    }

    val commitDrop = {
        val currentDragId = draggingButtonId
        val currentTarget = targetSlot
        val baseList = currentButtonsList
        if (currentDragId != null && currentTarget != null) {
            val fromIndex = baseList.indexOfFirst { it.id == currentDragId }
            val toIndex = currentTarget
            if (fromIndex != -1 && fromIndex != toIndex && toIndex in baseList.indices) {
                val updated = baseList.toMutableList().apply {
                    val item = removeAt(fromIndex)
                    add(toIndex, item)
                }
                buttonsList = updated
                currentOnReorderButtons(updated)
            }
        }
        draggingButtonId = null
        targetSlot = null
        startSlotIndex = null
        dragOffset = Offset.Zero
    }
    val currentCommitDrop by rememberUpdatedState(commitDrop)

    var showPinDialog by remember { mutableStateOf(false) }
    var showAvatarModal by remember { mutableStateOf(false) }
    var showSosModal by remember { mutableStateOf(false) }
    var currentTime by remember { mutableStateOf("") }
    var currentDate by remember { mutableStateOf("") }

    val locale = if (settings.language == "de") Locale.GERMANY else Locale.US

    // Live clock update
    LaunchedEffect(settings.language) {
        val timeFormat = SimpleDateFormat("HH:mm", locale)
        val dateFormat = SimpleDateFormat("EEEE, d. MMMM", locale)
        while (true) {
            val now = Date()
            currentTime = timeFormat.format(now)
            currentDate = dateFormat.format(now)
            delay(1000)
        }
    }

    val handleTileClick: (LauncherButton) -> Unit = { button ->
        val appKey = PedagogyPreferences.resolveAppKey(button)
        val quizCat = PedagogyPreferences.resolveQuizCategory(button)
        if (quizCat != null) {
            val status = pedagogyStatuses[appKey] ?: AppPedagogyStatus(
                appKey = appKey,
                appName = button.title,
                quizCategory = quizCat
            )
            val reviewDue = status.isReviewDue()
            if (!status.unlocked || reviewDue != ReviewDueState.NONE) {
                onTriggerQuiz(button, appKey, quizCat, reviewDue)
            } else {
                onButtonClick(button)
            }
        } else {
            onButtonClick(button)
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(
                Brush.verticalGradient(
                    colors = if (LocalIsDarkTheme.current) {
                        listOf(
                            Color(0xFF0F172A),
                            AssistiveBackground,
                            Color(0xFF020617)
                        )
                    } else {
                        listOf(
                            Color(0xFFF8FAFC),
                            AssistiveBackground,
                            Color(0xFFE2E8F0)
                        )
                    }
                )
            )
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .windowInsetsPadding(WindowInsets.launcherSafe)
                .padding(horizontal = 20.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Calm Header: Time, Date & Discreet Parent Lock Icon
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(top = 6.dp, bottom = 20.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.Top
            ) {
                Column(
                    modifier = Modifier.weight(1f)
                ) {
                    Text(
                        text = currentTime.ifEmpty { "12:00" },
                        fontSize = 44.sp,
                        fontWeight = FontWeight.Bold,
                        color = AssistiveTextPrimary,
                        letterSpacing = (-1).sp,
                        modifier = Modifier
                            .testTag("home_clock_display")
                            .then(
                                if (settings.enableClockClick) {
                                    Modifier
                                        .clip(RoundedCornerShape(12.dp))
                                        .clickable {
                                            val opened = com.example.util.AppUtils.openClockApp(context)
                                            if (!opened) {
                                                android.widget.Toast.makeText(context, R.string.clock_app_not_found, android.widget.Toast.LENGTH_SHORT).show()
                                            }
                                        }
                                } else Modifier
                            )
                    )
                    Text(
                        text = currentDate.ifEmpty { "Wednesday, 1 October" },
                        fontSize = 18.sp,
                        fontWeight = FontWeight.Medium,
                        color = AssistiveTextSecondary,
                        modifier = Modifier
                            .testTag("home_date_display")
                            .then(
                                if (settings.enableCalendarClick) {
                                    Modifier
                                        .clip(RoundedCornerShape(8.dp))
                                        .clickable {
                                            val opened = com.example.util.AppUtils.openCalendarApp(context)
                                            if (!opened) {
                                                android.widget.Toast.makeText(context, R.string.calendar_app_not_found, android.widget.Toast.LENGTH_SHORT).show()
                                            }
                                        }
                                } else Modifier
                            )
                    )
                }

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    // Circular SOS Button (same size 46.dp, placed left of child avatar button)
                    if (settings.showSosButton) {
                        Box(
                            modifier = Modifier
                                .size(46.dp)
                                .clip(CircleShape)
                                .background(Color(0xFFDC2626))
                                .border(1.5.dp, Color(0xFFFCA5A5), CircleShape)
                                .clickable { showSosModal = true }
                                .testTag("sos_circular_button"),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = "SOS",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Black,
                                color = Color.White,
                                letterSpacing = 0.5.sp
                            )
                        }
                    }

                    val avatarPreset = com.example.ui.setup.PRESET_AVATARS.find { it.id == settings.childAvatar }
                    val isCustomPhoto = settings.childAvatar.startsWith("content://") || settings.childAvatar.startsWith("file://")

                    // Child Avatar Button (same size as parent lock button: 46.dp)
                    Box(
                        modifier = Modifier
                            .size(46.dp)
                            .clip(CircleShape)
                            .background(
                                if (isCustomPhoto) Color.Transparent
                                else Color(avatarPreset?.bgHex ?: 0xFF3B82F6)
                            )
                            .border(1.5.dp, AssistiveBorder, CircleShape)
                            .clickable { showAvatarModal = true }
                            .testTag("child_avatar_button"),
                        contentAlignment = Alignment.Center
                    ) {
                        if (isCustomPhoto) {
                            AsyncImage(
                                model = settings.childAvatar,
                                contentDescription = "Avatar von ${settings.childName}",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier
                                    .fillMaxSize()
                                    .clip(CircleShape)
                            )
                        } else {
                            Text(
                                text = avatarPreset?.emoji ?: "🦁",
                                fontSize = 24.sp
                            )
                        }
                    }

                    // Discreet Parent Access Icon in corner
                    Box(
                        modifier = Modifier
                            .size(46.dp)
                            .clip(CircleShape)
                            .background(AssistiveSurface.copy(alpha = 0.85f))
                            .border(1.dp, AssistiveBorder, CircleShape)
                            .clickable { showPinDialog = true }
                            .testTag("parent_lock_button"),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Lock,
                            contentDescription = "Parent Settings",
                            tint = Color(0xFF64748B),
                            modifier = Modifier.size(22.dp)
                        )
                    }
                }
            }

            // Buttons according to chosen LayoutStyle (Grid or Rows) with live Drag-and-Drop
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
            ) {
                if (settings.layoutStyle == LayoutStyle.GRID) {
                    LazyVerticalGrid(
                        columns = GridCells.Fixed(2),
                        modifier = Modifier
                            .fillMaxSize()
                            .testTag("home_grid_layout"),
                        contentPadding = PaddingValues(top = 8.dp, bottom = 12.dp),
                        horizontalArrangement = Arrangement.spacedBy(16.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        itemsIndexed(displayButtons, key = { _, button -> button.id }) { index, button ->
                            val appKey = PedagogyPreferences.resolveAppKey(button)
                            val isDragging = draggingButtonId == button.id

                            val targetIndex = if (isDragging) (targetSlot ?: index) else index
                            val targetSlotRect = slotBounds[targetIndex] ?: startSlotRect

                            val translationX = if (isDragging && startSlotRect != Rect.Zero && targetSlotRect != Rect.Zero) {
                                startSlotRect.left + dragOffset.x - targetSlotRect.left
                            } else if (isDragging) {
                                dragOffset.x
                            } else 0f

                            val translationY = if (isDragging && startSlotRect != Rect.Zero && targetSlotRect != Rect.Zero) {
                                startSlotRect.top + dragOffset.y - targetSlotRect.top
                            } else if (isDragging) {
                                dragOffset.y
                            } else 0f

                            val tileModifier = Modifier
                                .animateItem()
                                .onGloballyPositioned { coordinates ->
                                    if (draggingButtonId == null) {
                                        slotBounds[index] = coordinates.boundsInRoot()
                                    }
                                }
                                .zIndex(if (isDragging) 10f else 1f)
                                .graphicsLayer {
                                    this.translationX = translationX
                                    this.translationY = translationY
                                    if (isDragging) {
                                        scaleX = 1.08f
                                        scaleY = 1.08f
                                        shadowElevation = 24.dp.toPx()
                                    }
                                }
                                .pointerInput(button.id) {
                                    detectDragGesturesAfterLongPress(
                                        onDragStart = {
                                            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                            val currentIdx = displayButtons.indexOfFirst { it.id == button.id }
                                            draggingButtonId = button.id
                                            startSlotIndex = currentIdx
                                            targetSlot = currentIdx
                                            startSlotRect = slotBounds[currentIdx] ?: Rect.Zero
                                            dragOffset = Offset.Zero
                                        },
                                        onDrag = { change, dragAmount ->
                                            change.consume()
                                            dragOffset += dragAmount

                                            if (startSlotRect != Rect.Zero) {
                                                val currentCenter = startSlotRect.center + dragOffset
                                                val bestSlot = slotBounds.entries
                                                    .filter { it.key < displayButtons.size }
                                                    .minByOrNull { (_, rect) ->
                                                        val dx = rect.center.x - currentCenter.x
                                                        val dy = rect.center.y - currentCenter.y
                                                        dx * dx + dy * dy
                                                    }?.key

                                                if (bestSlot != null && bestSlot != targetSlot) {
                                                    targetSlot = bestSlot
                                                    haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                                }
                                            }
                                        },
                                        onDragEnd = {
                                            currentCommitDrop()
                                        },
                                        onDragCancel = {
                                            currentCommitDrop()
                                        }
                                    )
                                }

                            val quizCat = PedagogyPreferences.resolveQuizCategory(button)
                            AssistiveGridTile(
                                button = button,
                                pedagogyStatus = pedagogyStatuses[appKey] ?: if (quizCat != null) {
                                    AppPedagogyStatus(appKey = appKey, appName = button.title, quizCategory = quizCat, unlocked = false)
                                } else null,
                                modifier = tileModifier,
                                isClickable = draggingButtonId == null,
                                onClick = { handleTileClick(button) }
                            )
                        }
                    }
                } else {
                    LazyColumn(
                        modifier = Modifier
                            .fillMaxSize()
                            .testTag("home_rows_layout"),
                        contentPadding = PaddingValues(top = 8.dp, bottom = 12.dp),
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        itemsIndexed(displayButtons, key = { _, button -> button.id }) { index, button ->
                            val appKey = PedagogyPreferences.resolveAppKey(button)
                            val isDragging = draggingButtonId == button.id

                            val targetIndex = if (isDragging) (targetSlot ?: index) else index
                            val targetSlotRect = slotBounds[targetIndex] ?: startSlotRect

                            val translationX = if (isDragging && startSlotRect != Rect.Zero && targetSlotRect != Rect.Zero) {
                                startSlotRect.left + dragOffset.x - targetSlotRect.left
                            } else if (isDragging) {
                                dragOffset.x
                            } else 0f

                            val translationY = if (isDragging && startSlotRect != Rect.Zero && targetSlotRect != Rect.Zero) {
                                startSlotRect.top + dragOffset.y - targetSlotRect.top
                            } else if (isDragging) {
                                dragOffset.y
                            } else 0f

                            val tileModifier = Modifier
                                .animateItem()
                                .onGloballyPositioned { coordinates ->
                                    if (draggingButtonId == null) {
                                        slotBounds[index] = coordinates.boundsInRoot()
                                    }
                                }
                                .zIndex(if (isDragging) 10f else 1f)
                                .graphicsLayer {
                                    this.translationX = translationX
                                    this.translationY = translationY
                                    if (isDragging) {
                                        scaleX = 1.08f
                                        scaleY = 1.08f
                                        shadowElevation = 24.dp.toPx()
                                    }
                                }
                                .pointerInput(button.id) {
                                    detectDragGesturesAfterLongPress(
                                        onDragStart = {
                                            haptic.performHapticFeedback(HapticFeedbackType.LongPress)
                                            val currentIdx = displayButtons.indexOfFirst { it.id == button.id }
                                            draggingButtonId = button.id
                                            startSlotIndex = currentIdx
                                            targetSlot = currentIdx
                                            startSlotRect = slotBounds[currentIdx] ?: Rect.Zero
                                            dragOffset = Offset.Zero
                                        },
                                        onDrag = { change, dragAmount ->
                                            change.consume()
                                            dragOffset += dragAmount

                                            if (startSlotRect != Rect.Zero) {
                                                val currentCenter = startSlotRect.center + dragOffset
                                                val bestSlot = slotBounds.entries
                                                    .filter { it.key < displayButtons.size }
                                                    .minByOrNull { (_, rect) ->
                                                        val dx = rect.center.x - currentCenter.x
                                                        val dy = rect.center.y - currentCenter.y
                                                        dx * dx + dy * dy
                                                    }?.key

                                                if (bestSlot != null && bestSlot != targetSlot) {
                                                    targetSlot = bestSlot
                                                    haptic.performHapticFeedback(HapticFeedbackType.TextHandleMove)
                                                }
                                            }
                                        },
                                        onDragEnd = {
                                            currentCommitDrop()
                                        },
                                        onDragCancel = {
                                            currentCommitDrop()
                                        }
                                    )
                                }

                            val quizCat = PedagogyPreferences.resolveQuizCategory(button)
                            AssistiveRowTile(
                                button = button,
                                pedagogyStatus = pedagogyStatuses[appKey] ?: if (quizCat != null) {
                                    AppPedagogyStatus(appKey = appKey, appName = button.title, quizCategory = quizCat, unlocked = false)
                                } else null,
                                modifier = tileModifier,
                                isClickable = draggingButtonId == null,
                                onClick = { handleTileClick(button) }
                            )
                        }
                    }
                }
            }

            // Celebration Modal with Confetti when an app was just unlocked
            if (celebrationMessage != null) {
                CelebrationModal(
                    message = celebrationMessage,
                    onDismiss = onDismissCelebration
                )
            }
        }

        // Parent PIN Dialog
        if (showPinDialog) {
            PinKeypadDialog(
                correctPin = settings.pin,
                onPinSuccess = {
                    showPinDialog = false
                    onOpenParentSettings()
                },
                onDismiss = { showPinDialog = false }
            )
        }

        // Child Avatar Explanation Modal
        if (showAvatarModal) {
            ChildAvatarExplanationModal(
                childName = settings.childName,
                childAvatar = settings.childAvatar,
                buttons = buttonsList,
                pedagogyStatuses = pedagogyStatuses,
                onDismiss = { showAvatarModal = false }
            )
        }

        // SOS Hold Modal Overlay
        if (showSosModal) {
            SosModalDialog(
                emergencyNumber = settings.emergencyNumber,
                emergencyContactName = settings.emergencyContactName,
                onSosTriggered = onSosTriggered,
                onDismiss = { showSosModal = false }
            )
        }
    }
}
