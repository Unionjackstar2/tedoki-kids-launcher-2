package com.example.data.quiz

import com.example.model.quiz.QuizCategory
import com.example.model.quiz.QuizModule
import com.example.model.quiz.QuizOption
import com.example.model.quiz.QuizQuestion

// Module für Apps, die TEDOKI über AppQuizClassifier als "Videos" oder "Spiele" erkennt
// (YouTube, TikTok, KiKA, Netflix … bzw. Roblox, Minecraft, Brawl Stars und alle Apps,
// die sich selbst als Spiel/Video-App ausweisen).

internal val videosModule = QuizModule(
    category = QuizCategory.VIDEOS,
    title = "Videos & Streaming",
    childIntroText = "In dieser App kannst du Videos schauen. Das macht Spaß – und du bestimmst, wann Schluss ist.",
    childQuestions = listOf(
        QuizQuestion(
            id = "c_vid_1",
            title = "Noch ein Video?",
            situation = "Ein Video ist zu Ende und sofort startet das nächste. Abgemacht war aber nur eins. Was machst du?",
            options = listOf(
                QuizOption("A", "Weiterschauen, bis der Akku leer ist."),
                QuizOption("B", "Das Handy weglegen – abgemacht ist abgemacht."),
                QuizOption("C", "Heimlich unter der Decke weiterschauen."),
                QuizOption("D", "Schnell noch zehn Videos schauen.")
            ),
            correctIndex = 1,
            explanation = "Videos hören nie von allein auf. Du entscheidest, wann Schluss ist. Das ist richtig stark!"
        ),
        QuizQuestion(
            id = "c_vid_2",
            title = "Ein Video macht Angst",
            situation = "Du siehst ein Video, das dir Angst macht oder komisch ist. Was hilft dir?",
            options = listOf(
                QuizOption("A", "Weiterschauen, vielleicht wird es besser."),
                QuizOption("B", "Allein bleiben und niemandem etwas sagen."),
                QuizOption("C", "Video stoppen und es Mama oder Papa zeigen."),
                QuizOption("D", "Das Video an Freunde schicken.")
            ),
            correctIndex = 2,
            explanation = "Du darfst immer stoppen. Erzähl es einem Erwachsenen – du bekommst keinen Ärger, sondern Hilfe."
        ),
        QuizQuestion(
            id = "c_vid_3",
            title = "Frage in den Kommentaren",
            situation = "Unter einem Video fragt dich jemand, wie alt du bist und wo du wohnst. Was machst du?",
            options = listOf(
                QuizOption("A", "Alles freundlich beantworten."),
                QuizOption("B", "Nicht antworten und es deinen Eltern zeigen."),
                QuizOption("C", "Nur das Alter verraten."),
                QuizOption("D", "Ein Foto von dir schicken.")
            ),
            correctIndex = 1,
            explanation = "Fremde im Internet bekommen keine Infos über dich. Zeig solche Fragen immer deinen Eltern."
        )
    ),
    childSummaryPoints = listOf(
        "Ich entscheide, wann Schluss ist – auch wenn das nächste Video schon startet.",
        "Macht mir ein Video Angst, stoppe ich es und sage Bescheid.",
        "Fremden verrate ich nichts über mich."
    ),
    parentIntroText = "Video-Apps sind darauf gebaut, dass man immer weiterschaut. Mit ein paar Einstellungen und klaren Absprachen wird daraus ein gutes Erlebnis.",
    parentFocusTopics = listOf(
        "Automatisches Weiterspielen (Autoplay)",
        "Kindgerechte Angebote und Profile",
        "Umgang mit verstörenden Inhalten",
        "Kommentare und Kontakt mit Fremden"
    ),
    parentQuestions = listOf(
        QuizQuestion(
            id = "p_vid_1",
            title = "Videozeit begrenzen",
            situation = "Was hilft Kindern am meisten, ihre Videozeit im Griff zu behalten?",
            options = listOf(
                QuizOption("A", "Autoplay ausschalten und feste Zeiten gemeinsam vereinbaren."),
                QuizOption("B", "Erst schimpfen, wenn es zu lange war."),
                QuizOption("C", "Gar keine Regeln – das Kind lernt es von selbst."),
                QuizOption("D", "Das Handy ohne Erklärung wegnehmen.")
            ),
            correctIndex = 0,
            explanation = "Autoplay ist der stärkste „Weiter-weiter“-Mechanismus. Ohne ihn und mit klaren Absprachen fällt das Aufhören viel leichter."
        ),
        QuizQuestion(
            id = "p_vid_2",
            title = "Das richtige Angebot",
            situation = "Ihr Kind möchte Videos auf YouTube oder ähnlichen Plattformen schauen. Was ist sinnvoll?",
            options = listOf(
                QuizOption("A", "Das normale Konto eines Erwachsenen nutzen."),
                QuizOption("B", "Ein Kinderangebot oder Kinderprofil nutzen und Kanäle gemeinsam auswählen."),
                QuizOption("C", "Das Kind sucht selbst – es findet schon das Richtige."),
                QuizOption("D", "Nur Videos mit besonders vielen Klicks erlauben.")
            ),
            correctIndex = 1,
            explanation = "Kinderprofile und Angebote wie KiKA-Player, ZDFtivi oder Die Maus filtern viel heraus. Gemeinsam ausgewählte Kanäle geben zusätzliche Sicherheit."
        ),
        QuizQuestion(
            id = "p_vid_3",
            title = "Etwas Verstörendes gesehen",
            situation = "Ihr Kind kommt zu Ihnen, weil es ein verstörendes Video gesehen hat. Was ist die beste Reaktion?",
            options = listOf(
                QuizOption("A", "Handyverbot als Strafe."),
                QuizOption("B", "Ruhig zuhören, das Gesehene einordnen und loben, dass es gekommen ist."),
                QuizOption("C", "Nicht weiter darauf eingehen."),
                QuizOption("D", "Sagen, dass es selbst schuld ist.")
            ),
            correctIndex = 1,
            explanation = "Wer nach einem Hilferuf bestraft wird, kommt beim nächsten Mal nicht mehr. Ruhiges Zuhören hält den Gesprächsfaden offen."
        )
    ),
    parentTips = listOf(
        "Autoplay in der App ausschalten (meist ein Schalter direkt am Video oder in den Einstellungen).",
        "Kinderprofil bzw. eingeschränkten Modus aktivieren.",
        "Kommentare möglichst ausblenden und gelegentlich gemeinsam schauen."
    )
)

internal val spieleModule = QuizModule(
    category = QuizCategory.SPIELE,
    title = "Spiele & Online-Games",
    childIntroText = "In dieser App kannst du spielen. Manche Spiele haben einen Chat oder Shop – hier lernst du, wie du gut damit umgehst.",
    childQuestions = listOf(
        QuizQuestion(
            id = "c_game_1",
            title = "Geschenk gegen Passwort",
            situation = "Im Spiel schreibt dir jemand: „Ich schenke dir Spielgeld – sag mir dafür dein Passwort.“ Was machst du?",
            options = listOf(
                QuizOption("A", "Das Passwort schicken."),
                QuizOption("B", "Nichts schicken und die Nachricht deinen Eltern zeigen."),
                QuizOption("C", "Das Passwort von Mama schicken."),
                QuizOption("D", "Nach noch mehr Geschenken fragen.")
            ),
            correctIndex = 1,
            explanation = "Ein Passwort ist wie ein Haustürschlüssel – den gibst du niemandem. Echte Freunde fragen nicht danach."
        ),
        QuizQuestion(
            id = "c_game_2",
            title = "Der Kaufen-Knopf",
            situation = "Im Spiel blinkt ein Knopf: „Jetzt Diamanten holen!“ Daneben steht ein Preis. Was machst du?",
            options = listOf(
                QuizOption("A", "Einfach drücken."),
                QuizOption("B", "Erst Mama oder Papa fragen."),
                QuizOption("C", "Ganz oft drücken, dann gibt es mehr."),
                QuizOption("D", "Einen Freund drücken lassen.")
            ),
            correctIndex = 1,
            explanation = "Diamanten, Münzen und Skins kosten oft echtes Geld. Kaufen geht nur zusammen mit deinen Eltern."
        ),
        QuizQuestion(
            id = "c_game_3",
            title = "Gemeine Nachrichten",
            situation = "Du hast verloren und jemand schreibt dir gemeine Sachen. Was hilft dir?",
            options = listOf(
                QuizOption("A", "Genauso gemein zurückschreiben."),
                QuizOption("B", "Spiel kurz weglegen, die Person blockieren und es deinen Eltern erzählen."),
                QuizOption("C", "Traurig sein und niemandem etwas sagen."),
                QuizOption("D", "Das Handy wegwerfen.")
            ),
            correctIndex = 1,
            explanation = "Du musst dir Gemeinheiten nicht anhören. Blockieren ist erlaubt – und darüber reden hilft."
        )
    ),
    childSummaryPoints = listOf(
        "Mein Passwort bleibt geheim – auch für Geschenke.",
        "Kaufen nur zusammen mit Mama oder Papa.",
        "Bei Gemeinheiten: Pause, blockieren, erzählen."
    ),
    parentIntroText = "Viele Spiele sind kostenlos, verdienen aber mit Käufen im Spiel. Dazu kommen Chats mit Fremden. Beides lässt sich gut absichern.",
    parentFocusTopics = listOf(
        "Käufe im Spiel",
        "Chat- und Freundesfunktionen",
        "Altersfreigaben",
        "Spielzeiten"
    ),
    parentQuestions = listOf(
        QuizQuestion(
            id = "p_game_1",
            title = "Ungewollte Käufe",
            situation = "Wie schützen Sie sich am besten vor ungewollten Käufen im Spiel?",
            options = listOf(
                QuizOption("A", "Käufe im App-Store mit Passwort oder Bestätigung absichern und keine Zahlungsart offen hinterlegen."),
                QuizOption("B", "Die Kreditkarte hinterlegen, damit es schnell geht."),
                QuizOption("C", "Darauf vertrauen, dass das Kind nichts drückt."),
                QuizOption("D", "Erst reagieren, wenn eine Rechnung kommt.")
            ),
            correctIndex = 0,
            explanation = "Kaufknöpfe sind bewusst verlockend gestaltet. Eine Bestätigung bei jedem Kauf verhindert teure Überraschungen."
        ),
        QuizQuestion(
            id = "p_game_2",
            title = "Chat im Spiel",
            situation = "Viele Online-Spiele haben einen Chat. Was ist für Grundschulkinder sinnvoll?",
            options = listOf(
                QuizOption("A", "Den Chat für alle offen lassen."),
                QuizOption("B", "Chat ausschalten oder auf bekannte Freunde beschränken und das Spiel gemeinsam einrichten."),
                QuizOption("C", "Das ist egal, es ist ja nur ein Spiel."),
                QuizOption("D", "Das Kind soll das allein entscheiden.")
            ),
            correctIndex = 1,
            explanation = "Über Spiel-Chats nehmen auch Erwachsene mit schlechten Absichten Kontakt auf. Die meisten Spiele lassen sich in den Einstellungen absichern."
        ),
        QuizQuestion(
            id = "p_game_3",
            title = "Das passende Spiel",
            situation = "Woran orientieren Sie sich bei der Auswahl von Spielen?",
            options = listOf(
                QuizOption("A", "Daran, was die Klassenkameraden spielen."),
                QuizOption("B", "An der Altersfreigabe (USK/IARC), Spielbeschreibungen und am besten selbst kurz anspielen."),
                QuizOption("C", "Bunte Grafik bedeutet kindgerecht."),
                QuizOption("D", "An der Zahl der Downloads.")
            ),
            correctIndex = 1,
            explanation = "Die Altersfreigabe ist ein guter Anfang. Selbst kurz reinschauen zeigt, ob Chat, Käufe oder Inhalte zum eigenen Kind passen."
        )
    ),
    parentTips = listOf(
        "Kaufbestätigung im App-Store einschalten.",
        "Chat- und Freundesfunktionen im Spiel gemeinsam einstellen.",
        "Spielzeiten absprechen – Spielrunden haben oft kein natürliches Ende."
    )
)
