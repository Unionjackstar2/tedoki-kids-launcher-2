package com.example.data.quiz

import com.example.model.quiz.QuizCategory
import com.example.model.quiz.QuizModule
import com.example.model.quiz.QuizOption
import com.example.model.quiz.QuizQuestion

internal val anrufenModule = QuizModule(
    category = QuizCategory.ANRUFEN,
    title = "Telefonieren & Anrufen",
    childIntroText = "Mit dem Telefon kannst du Familie und Freunde anrufen und sprechen.",
    childQuestions = listOf(
        QuizQuestion(
            id = "c_call_1",
            title = "Mama anrufen",
            situation = "Du möchtest deine Mama anrufen. Was machst du?",
            options = listOf(
                QuizOption("A", "Du suchst Mama in deinen Kontakten."),
                QuizOption("B", "Du rufst irgendeine Nummer an."),
                QuizOption("C", "Du wartest, bis Mama dich anruft."),
                QuizOption("D", "Du schreibst die Nummer auf einen Zettel.")
            ),
            correctIndex = 0,
            explanation = "Am sichersten ist es, eine bekannte Person über den richtigen Kontakt anzurufen."
        ),
        QuizQuestion(
            id = "c_call_2",
            title = "Aus Versehen angerufen",
            situation = "Du hast jemanden aus Versehen angerufen. Was kannst du machen?",
            options = listOf(
                QuizOption("A", "Immer wieder anrufen."),
                QuizOption("B", "Auflegen und später eine Nachricht schreiben."),
                QuizOption("C", "Das Handy ausschalten."),
                QuizOption("D", "Die Person blockieren.")
            ),
            correctIndex = 1,
            explanation = "Ein versehentlicher Anruf ist kein Problem. Du kannst auflegen und dich gegebenenfalls per Nachricht erklären."
        ),
        QuizQuestion(
            id = "c_call_3",
            title = "Niemand hebt ab",
            situation = "Du rufst jemanden an, aber die Person geht nicht ran. Was kannst du tun?",
            options = listOf(
                QuizOption("A", "20-mal hintereinander anrufen."),
                QuizOption("B", "Eine Nachricht schreiben und später noch einmal versuchen."),
                QuizOption("C", "Das Handy der Person kaputtmachen."),
                QuizOption("D", "Die Nummer löschen.")
            ),
            correctIndex = 1,
            explanation = "Die andere Person kann gerade beschäftigt sein. Eine Nachricht oder ein späterer Anruf reicht."
        )
    ),
    childSummaryPoints = listOf(
        "Bekannte Personen immer über gespeicherte Kontakte anrufen.",
        "Ein versehentlicher Anruf ist nicht schlimm: Einfach auflegen und Bescheid sagen.",
        "Wenn niemand rangeht: Geduld haben, später versuchen oder eine kurze Nachricht schreiben."
    ),
    parentIntroText = "Beim Telefonieren lernt Ihr Kind, verantwortungsvoll mit Kontakten umzugehen und Gesprächsregeln zu beachten.",
    parentFocusTopics = listOf(
        "Nur gespeicherte Kontakte anrufen",
        "Umgang mit versehentlichen Anrufen",
        "Verständnis für Nichterreichbarkeit",
        "Feste Ansprechpartner vereinbaren"
    ),
    parentQuestions = listOf(
        QuizQuestion(
            id = "p_call_1",
            title = "Kontakte anrufen",
            situation = "Ihr Kind möchte jemanden aus seinen Kontakten anrufen. Was ist eine sinnvolle Unterstützung?",
            options = listOf(
                QuizOption("A", "Das Kind soll möglichst über gespeicherte Kontakte anrufen und bei Unsicherheit nachfragen."),
                QuizOption("B", "Das Kind soll irgendeine Nummer ausprobieren."),
                QuizOption("C", "Das Kind soll Telefonnummern aus dem Internet verwenden."),
                QuizOption("D", "Das Kind soll seine Telefonnummer an unbekannte Personen weitergeben.")
            ),
            correctIndex = 0,
            explanation = "Bekannte Kontakte und Nachfragen bei Unsicherheit unterstützen einen sicheren Umgang mit Anrufen."
        ),
        QuizQuestion(
            id = "p_call_2",
            title = "Versehentlicher Anruf",
            situation = "Ihr Kind hat versehentlich jemanden angerufen. Wie reagieren Sie sinnvoll?",
            options = listOf(
                QuizOption("A", "Das Kind dafür bestrafen."),
                QuizOption("B", "Gemeinsam überlegen, ob eine kurze Nachricht zur Erklärung sinnvoll ist."),
                QuizOption("C", "Die Person sofort zurückrufen und beschimpfen."),
                QuizOption("D", "Das Telefonieren grundsätzlich verbieten.")
            ),
            correctIndex = 1,
            explanation = "Ein versehentlicher Anruf ist normalerweise kein großes Problem. Das Kind kann lernen, ruhig damit umzugehen."
        ),
        QuizQuestion(
            id = "p_call_3",
            title = "Niemand erreichbar",
            situation = "Ihr Kind erreicht jemanden telefonisch nicht. Was ist eine gute Regel?",
            options = listOf(
                QuizOption("A", "So lange anrufen, bis jemand abnimmt."),
                QuizOption("B", "Eine kurze Nachricht hinterlassen und später noch einmal versuchen."),
                QuizOption("C", "Die Person über andere Nummern suchen."),
                QuizOption("D", "Die Nummer öffentlich posten.")
            ),
            correctIndex = 1,
            explanation = "Menschen müssen nicht jederzeit erreichbar sein. Eine Nachricht und ein späterer Versuch reichen meist aus."
        )
    ),
    parentTips = listOf(
        "Wichtige Nummern als Favoriten mit Foto speichern.",
        "Erklären, dass Daueranrufe andere stören.",
        "Kind bestärken, bei Unsicherheit nachzufragen."
    )
)

internal val unbekannteNummernModule = QuizModule(
    category = QuizCategory.UNBEKANNTE_NUMMERN,
    title = "Unbekannte Rufnummern",
    childIntroText = "Manchmal rufen Nummern an, die du nicht kennst. Hier lernst du, wie du dich schützt.",
    childQuestions = listOf(
        QuizQuestion(
            id = "c_unk_1",
            title = "Unbekannter Anrufer",
            situation = "Eine Nummer, die du nicht kennst, ruft dich an. Was ist eine gute Idee?",
            options = listOf(
                QuizOption("A", "Sofort zurückrufen."),
                QuizOption("B", "Die Nummer erst prüfen oder einen Erwachsenen fragen."),
                QuizOption("C", "Deine Adresse nennen."),
                QuizOption("D", "Die Nummer an Freunde schicken.")
            ),
            correctIndex = 1,
            explanation = "Bei unbekannten Nummern musst du nicht sofort reagieren. Prüfe die Nummer oder frage eine Vertrauensperson."
        ),
        QuizQuestion(
            id = "c_unk_2",
            title = "Adresse erfragt",
            situation = "Eine unbekannte Person sagt am Telefon: „Sag mir schnell deine Adresse.“ Was machst du?",
            options = listOf(
                QuizOption("A", "Ich sage meine Adresse."),
                QuizOption("B", "Ich frage nach, warum die Person sie braucht."),
                QuizOption("C", "Ich gebe die Adresse nicht heraus und hole mir Hilfe."),
                QuizOption("D", "Ich sage meine Schuladresse.")
            ),
            correctIndex = 2,
            explanation = "Eine Adresse ist eine persönliche Information. Gib sie unbekannten Personen nicht einfach heraus und hole dir Hilfe."
        ),
        QuizQuestion(
            id = "c_unk_3",
            title = "Wiederholte Anrufe",
            situation = "Eine unbekannte Nummer ruft dich immer wieder an. Was kannst du machen?",
            options = listOf(
                QuizOption("A", "Immer zurückrufen."),
                QuizOption("B", "Die Nummer blockieren und einem Erwachsenen Bescheid sagen."),
                QuizOption("C", "Die Nummer öffentlich posten."),
                QuizOption("D", "Deine Telefonnummer zurückschicken.")
            ),
            correctIndex = 1,
            explanation = "Wenn Anrufe unerwünscht sind, kannst du die Nummer blockieren und eine erwachsene Vertrauensperson informieren."
        )
    ),
    childSummaryPoints = listOf(
        "Unbekannte Nummern nicht voreilig zurückrufen.",
        "Niemals die Adresse oder private Infos am Telefon verraten.",
        "Störende Nummern sofort blockieren und Eltern informieren."
    ),
    parentIntroText = "Unerwünschte Werbe- oder Spam-Anrufe verunsichern Kinder. Gemeinsame Regeln geben Sicherheit.",
    parentFocusTopics = listOf(
        "Keine privaten Daten an Fremde",
        "Gemeinsames Prüfen verdächtiger Nummern",
        "Konsequentes Blockieren"
    ),
    parentQuestions = listOf(
        QuizQuestion(
            id = "p_unk_1",
            title = "Umgang mit unbekannten Anrufern",
            situation = "Ihr Kind erhält einen Anruf von einer unbekannten Nummer. Was ist eine sinnvolle Regel?",
            options = listOf(
                QuizOption("A", "Sofort zurückrufen."),
                QuizOption("B", "Die Nummer prüfen und bei Unsicherheit eine erwachsene Vertrauensperson einbeziehen."),
                QuizOption("C", "Zuerst die Adresse nennen."),
                QuizOption("D", "Die Nummer in einer Gruppe veröffentlichen.")
            ),
            correctIndex = 1,
            explanation = "Bei unbekannten Nummern sollte nicht vorschnell reagiert oder persönliche Information herausgegeben werden."
        ),
        QuizQuestion(
            id = "p_unk_2",
            title = "Forderung nach Daten",
            situation = "Eine unbekannte Person verlangt am Telefon die Adresse Ihres Kindes. Was vermitteln Sie?",
            options = listOf(
                QuizOption("A", "Die Adresse nennen, wenn die Person freundlich klingt."),
                QuizOption("B", "Nur die Schuladresse nennen."),
                QuizOption("C", "Keine persönliche Adresse herausgeben und eine Vertrauensperson einbeziehen."),
                QuizOption("D", "Die Adresse der Person im Gegenzug verlangen.")
            ),
            correctIndex = 2,
            explanation = "Eine freundliche Stimme bedeutet nicht, dass eine Person vertrauenswürdig ist. Persönliche Daten bleiben geschützt."
        ),
        QuizQuestion(
            id = "p_unk_3",
            title = "Wiederholte Anrufe",
            situation = "Eine unbekannte Nummer ruft Ihr Kind wiederholt an. Was ist sinnvoll?",
            options = listOf(
                QuizOption("A", "Jedes Mal zurückrufen."),
                QuizOption("B", "Die Nummer blockieren und bei belastenden oder verdächtigen Anrufen darüber sprechen."),
                QuizOption("C", "Die Nummer öffentlich posten."),
                QuizOption("D", "Die Nummer an andere Kinder weitergeben.")
            ),
            correctIndex = 1,
            explanation = "Blockieren kann unerwünschte Kontakte reduzieren. Wichtig ist außerdem, dass das Kind Hilfe holen kann."
        )
    ),
    parentTips = listOf(
        "Spam-Schutz im Betriebssystem aktivieren.",
        "Kind loben, wenn es Anrufe meldet.",
        "Unbekannte Nummern gemeinsam nachschlagen."
    )
)

internal val nachrichtenModule = QuizModule(
    category = QuizCategory.NACHRICHTEN,
    title = "Nachrichten & Chats",
    childIntroText = "Nachrichten schreiben macht Spaß. Hier erfährst du, worauf du beim Schreiben achten solltest.",
    childQuestions = listOf(
        QuizQuestion(
            id = "c_msg_1",
            title = "Antwortzeit",
            situation = "Dein Freund schreibt dir eine Nachricht. Musst du sofort antworten?",
            options = listOf(
                QuizOption("A", "Ja, immer."),
                QuizOption("B", "Nein, ich kann antworten, wenn ich Zeit habe."),
                QuizOption("C", "Nur nachts."),
                QuizOption("D", "Nur wenn er dreimal schreibt.")
            ),
            correctIndex = 1,
            explanation = "Nachrichten müssen nicht sofort beantwortet werden. Du darfst selbst entscheiden, wann du Zeit hast."
        ),
        QuizQuestion(
            id = "c_msg_2",
            title = "Missverständnis",
            situation = "Du verstehst eine Nachricht nicht. Was kannst du tun?",
            options = listOf(
                QuizOption("A", "Wütend antworten."),
                QuizOption("B", "Nachfragen, was gemeint ist."),
                QuizOption("C", "Die Person sofort blockieren."),
                QuizOption("D", "Die Nachricht an alle weiterleiten.")
            ),
            correctIndex = 1,
            explanation = "Bei Missverständnissen hilft Nachfragen. So kannst du herausfinden, was die andere Person wirklich meint."
        ),
        QuizQuestion(
            id = "c_msg_3",
            title = "Gemeine Nachricht",
            situation = "Jemand schreibt dir: „Du bist doof!“ Was wäre eine gute Reaktion?",
            options = listOf(
                QuizOption("A", "„Du bist noch viel doofer!“"),
                QuizOption("B", "Die Nachricht speichern und einen Erwachsenen um Hilfe bitten."),
                QuizOption("C", "Die Nachricht an alle Freunde weiterleiten."),
                QuizOption("D", "Sofort zurückrufen und schreien.")
            ),
            correctIndex = 1,
            explanation = "Du musst nicht zurückbeleidigen. Wenn dich eine Nachricht belastet oder verletzt, kannst du Hilfe holen."
        )
    ),
    childSummaryPoints = listOf(
        "Du musst nicht sofort antworten – nimm dir Zeit.",
        "Erst nachfragen, wenn etwas unklar oder komisch klingt.",
        "Nicht zurückbeleidigen: Screenshot machen und Eltern um Hilfe bitten."
    ),
    parentIntroText = "Beim Chatten entstehen schnell Missverständnisse und Antwortdruck. Fördern Sie gelassene Kommunikation.",
    parentFocusTopics = listOf(
        "Kein permanenter Antwortdruck",
        "Konfliktlösung ohne Beleidigungen",
        "Offener Austausch bei Cybermobbing"
    ),
    parentQuestions = listOf(
        QuizQuestion(
            id = "p_msg_1",
            title = "Antwortdruck abbauen",
            situation = "Ihr Kind antwortet nicht sofort auf eine Nachricht. Was ist eine sinnvolle Haltung?",
            options = listOf(
                QuizOption("A", "Kinder müssen immer sofort antworten."),
                QuizOption("B", "Kinder dürfen selbst entscheiden, wann sie Zeit zum Antworten haben."),
                QuizOption("C", "Eltern sollten jede Nachricht beantworten."),
                QuizOption("D", "Das Handy sollte deshalb weggenommen werden.")
            ),
            correctIndex = 1,
            explanation = "Digitale Kommunikation bedeutet nicht, ständig erreichbar sein zu müssen."
        ),
        QuizQuestion(
            id = "p_msg_2",
            title = "Kontext klären",
            situation = "Ihr Kind versteht eine Nachricht falsch und ist verärgert. Was können Sie fördern?",
            options = listOf(
                QuizOption("A", "Sofort zurückbeleidigen."),
                QuizOption("B", "Nachfragen und versuchen, den Kontext zu klären."),
                QuizOption("C", "Die Nachricht an alle weiterleiten."),
                QuizOption("D", "Die andere Person öffentlich bloßstellen.")
            ),
            correctIndex = 1,
            explanation = "Nachfragen kann Missverständnisse klären und verhindert, dass ein digitaler Konflikt unnötig eskaliert."
        ),
        QuizQuestion(
            id = "p_msg_3",
            title = "Beleidigungen",
            situation = "Ihr Kind bekommt eine beleidigende Nachricht. Was ist eine sinnvolle Unterstützung?",
            options = listOf(
                QuizOption("A", "Zurückbeleidigen."),
                QuizOption("B", "Die Situation gemeinsam einordnen, die Nachricht gegebenenfalls sichern und Hilfe organisieren."),
                QuizOption("C", "Die Nachricht an alle Freunde schicken."),
                QuizOption("D", "Die andere Person persönlich aufsuchen.")
            ),
            correctIndex = 1,
            explanation = "Eltern können helfen, ruhig zu bleiben, Belege zu sichern und passende weitere Schritte zu finden."
        )
    ),
    parentTips = listOf(
        "Feste nachrichtenfreie Zeiten im Familienalltag vereinbaren.",
        "Ermutigen, unangenehme Nachrichten zu zeigen.",
        "Ruhe bewahren und Belege sichern."
    )
)

internal val whatsappModule = QuizModule(
    category = QuizCategory.WHATSAPP,
    title = "WhatsApp",
    childIntroText = "In WhatsApp kannst du mit Freunden und Gruppen schreiben. Hier lernst du die wichtigsten Regeln.",
    childQuestions = listOf(
        QuizQuestion(
            id = "c_wa_1",
            title = "WhatsApp-Gruppe",
            situation = "Was ist eine WhatsApp-Gruppe?",
            options = listOf(
                QuizOption("A", "Ein Chat mit mehreren Personen."),
                QuizOption("B", "Ein Spiel."),
                QuizOption("C", "Eine Telefonnummer."),
                QuizOption("D", "Ein Fotoalbum.")
            ),
            correctIndex = 0,
            explanation = "In einer Gruppe können mehrere Personen gemeinsam Nachrichten, Bilder oder andere Inhalte austauschen."
        ),
        QuizQuestion(
            id = "c_wa_2",
            title = "Fremde Gruppe",
            situation = "Du wirst zu einer WhatsApp-Gruppe hinzugefügt, in der du niemanden kennst. Was machst du?",
            options = listOf(
                QuizOption("A", "Du erzählst sofort allen deine Adresse."),
                QuizOption("B", "Du bleibst einfach in der Gruppe."),
                QuizOption("C", "Du fragst einen Erwachsenen, was du tun solltest."),
                QuizOption("D", "Du schickst allen dein Foto.")
            ),
            correctIndex = 2,
            explanation = "Wenn du die Personen nicht kennst, solltest du vorsichtig sein und eine erwachsene Vertrauensperson fragen."
        ),
        QuizQuestion(
            id = "c_wa_3",
            title = "Gemeines Foto in Gruppe",
            situation = "Jemand schickt in einer WhatsApp-Gruppe ein gemeines Foto von einem anderen Kind. Was solltest du tun?",
            options = listOf(
                QuizOption("A", "Das Foto weiterleiten."),
                QuizOption("B", "Einen Screenshot machen und das Foto an alle schicken."),
                QuizOption("C", "Das Foto nicht weiterverbreiten und einen Erwachsenen informieren."),
                QuizOption("D", "Ein noch gemeineres Foto schicken.")
            ),
            correctIndex = 2,
            explanation = "Ein gemeines Foto weiterzuverbreiten kann die Situation schlimmer machen. Hol dir Hilfe und verbreite es nicht weiter."
        )
    ),
    childSummaryPoints = listOf(
        "WhatsApp-Gruppen sind für mehrere Personen – alles kann von allen gelesen werden.",
        "In fremden Gruppen vorsichtig sein und sofort die Eltern fragen.",
        "Gemeine Bilder niemals weiterschicken, sondern Hilfe holen."
    ),
    parentIntroText = "WhatsApp ist oft der erste eigene Messenger. Gruppenchats bergen Dynamiken wie Kettenbriefe und Ausgrenzung.",
    parentFocusTopics = listOf(
        "Gruppen-Mitglieder kennen und prüfen",
        "Gemeine Inhalte stoppen statt teilen",
        "Verantwortung für das eigene Senden"
    ),
    parentQuestions = listOf(
        QuizQuestion(
            id = "p_wa_1",
            title = "Unbekannte Gruppen",
            situation = "Ihr Kind wird zu einer WhatsApp-Gruppe hinzugefügt, deren Mitglieder es nicht kennt. Was ist sinnvoll?",
            options = listOf(
                QuizOption("A", "Sofort persönliche Informationen teilen."),
                QuizOption("B", "Gemeinsam prüfen, wer die Mitglieder sind, und bei Unsicherheit Unterstützung holen."),
                QuizOption("C", "Allen ein Foto schicken."),
                QuizOption("D", "Die Gruppe an weitere Kinder empfehlen.")
            ),
            correctIndex = 1,
            explanation = "Bei unbekannten Gruppen sollte das Kind wissen, dass es nicht teilnehmen muss und Hilfe holen kann."
        ),
        QuizQuestion(
            id = "p_wa_2",
            title = "Gemeines Foto in Gruppe",
            situation = "In einer WhatsApp-Gruppe wird ein Kind mit einem peinlichen Foto verspottet. Was vermitteln Sie?",
            options = listOf(
                QuizOption("A", "Das Foto weiterleiten."),
                QuizOption("B", "Das Foto nicht weiterverbreiten und Unterstützung holen."),
                QuizOption("C", "Ein noch peinlicheres Foto zurückschicken."),
                QuizOption("D", "Die Gruppe an weitere Personen teilen.")
            ),
            correctIndex = 1,
            explanation = "Das Weiterverbreiten kann die Belastung vergrößern. Nicht weiterleiten und Hilfe holen ist sinnvoll."
        ),
        QuizQuestion(
            id = "p_wa_3",
            title = "Senden in große Gruppen",
            situation = "Ihr Kind möchte etwas in eine größere Gruppe schicken. Welche Regel ist sinnvoll?",
            options = listOf(
                QuizOption("A", "Alles Lustige darf verschickt werden."),
                QuizOption("B", "Vor dem Senden überlegen, wer es sehen kann und ob es für die Gruppe geeignet ist."),
                QuizOption("C", "Je mehr Menschen es sehen, desto besser."),
                QuizOption("D", "Nachrichten sollten grundsätzlich öffentlich sein.")
            ),
            correctIndex = 1,
            explanation = "Nicht jede Information gehört in jeden Chat. Ziel ist ein bewusster Umgang mit Empfängern und Inhalten."
        )
    ),
    parentTips = listOf(
        "Privatsphäre-Einstellungen in WhatsApp optimieren (Profilbild nur Kontakte).",
        "Regelmäßig gemeinsam über Gruppendynamiken sprechen.",
        "Ermutigen, Gruppen bei Unwohlsein zu verlassen."
    )
)

internal val sprachnachrichtenModule = QuizModule(
    category = QuizCategory.SPRACHNACHRICHTEN,
    title = "Sprachnachrichten",
    childIntroText = "Sprachnachrichten sind praktisch, wenn man nicht tippen möchte.",
    childQuestions = listOf(
        QuizQuestion(
            id = "c_vn_1",
            title = "Sprachnachricht empfangen",
            situation = "Du bekommst eine Sprachnachricht. Was kannst du machen?",
            options = listOf(
                QuizOption("A", "Du kannst sie anhören, wenn du Zeit hast."),
                QuizOption("B", "Du musst sofort antworten."),
                QuizOption("C", "Du musst sie an alle weiterleiten."),
                QuizOption("D", "Du musst sofort anrufen.")
            ),
            correctIndex = 0,
            explanation = "Du darfst selbst entscheiden, wann du eine Sprachnachricht anhörst und beantwortest."
        ),
        QuizQuestion(
            id = "c_vn_2",
            title = "Aufnahme in der Umgebung",
            situation = "Du möchtest eine Sprachnachricht aufnehmen. Neben dir sitzen viele andere Kinder. Was solltest du bedenken?",
            options = listOf(
                QuizOption("A", "Laut hineinrufen."),
                QuizOption("B", "Darauf achten, dass andere nicht unfreiwillig mit aufgenommen werden."),
                QuizOption("C", "Alle Kinder aufnehmen."),
                QuizOption("D", "Die Nachricht möglichst laut abspielen.")
            ),
            correctIndex = 1,
            explanation = "Achte auf die Privatsphäre anderer. Andere Personen sollten nicht einfach Teil deiner Aufnahme werden."
        )
    ),
    childSummaryPoints = listOf(
        "Du bestimmst, wann du Sprachnachrichten abhörst.",
        "Beim Aufnehmen darauf achten, wer in der Nähe ist.",
        "Nicht laut im Bus oder in der Öffentlichkeit abhören."
    ),
    parentIntroText = "Sprachnachrichten sind bei Kindern sehr beliebt, können aber die Privatsphäre von Umstehenden verletzen.",
    parentFocusTopics = listOf(
        "Privatsphäre bei Umgebungsgeräuschen",
        "Kopfhörer nutzen im öffentlichen Raum",
        "Angemessene Länge und Höflichkeit"
    ),
    parentQuestions = listOf(
        QuizQuestion(
            id = "p_vn_1",
            title = "Keine Sofortpflicht",
            situation = "Ihr Kind bekommt eine Sprachnachricht und möchte erst später zuhören. Was ist sinnvoll?",
            options = listOf(
                QuizOption("A", "Es muss sofort antworten."),
                QuizOption("B", "Es darf die Nachricht anhören, wenn es Zeit und Ruhe dafür hat."),
                QuizOption("C", "Es muss die Nachricht weiterleiten."),
                QuizOption("D", "Es muss sofort zurückrufen.")
            ),
            correctIndex = 1,
            explanation = "Auch Sprachnachrichten erzeugen keine Pflicht, sofort zu reagieren."
        ),
        QuizQuestion(
            id = "p_vn_2",
            title = "Aufnahme in Gegenwart anderer",
            situation = "Ihr Kind nimmt eine Sprachnachricht auf, während andere Kinder daneben sitzen. Was sollte es beachten?",
            options = listOf(
                QuizOption("A", "Andere dürfen automatisch mit aufgenommen werden."),
                QuizOption("B", "Darauf achten, dass andere nicht unbeabsichtigt Teil der Aufnahme werden."),
                QuizOption("C", "Möglichst laut sprechen."),
                QuizOption("D", "Die Aufnahme öffentlich teilen.")
            ),
            correctIndex = 1,
            explanation = "Bei Audioaufnahmen sollte die Privatsphäre anderer berücksichtigt werden."
        )
    ),
    parentTips = listOf(
        "Kind anregen, Kopfhörer für Sprachnachrichten zu nutzen.",
        "Darauf hinweisen, dass auch Gesprochenes gespeichert bleibt.",
        "Höflicher Umgangston gilt auch für gesprochene Nachrichten."
    )
)
