package com.example.telecom

import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.content.Context
import android.content.Intent
import android.os.Build
import android.telecom.Call
import android.telecom.CallAudioState
import android.telecom.InCallService
import android.util.Log
import androidx.core.app.NotificationCompat
import com.example.MainActivity

private const val TAG = "TedokiInCallService"
private const val INCOMING_CHANNEL_ID = "tedoki_incoming_call"
private const val INCOMING_NOTIFICATION_ID = 4711

/**
 * Android Telecom InCallService implementation for TEDOKI Kids.
 * Receives real telephony call events from Android OS,
 * and synchronizes with CallManager and the simplified call UI.
 */
class TedokiInCallService : InCallService() {

    override fun onCreate() {
        super.onCreate()
        Log.d(TAG, "onCreate: InCallService created")
        CallManager.registerService(this)
    }

    override fun onBind(intent: Intent?): android.os.IBinder? {
        Log.d(TAG, "onBind: Telecom binding to InCallService")
        CallManager.registerService(this)
        return super.onBind(intent)
    }

    override fun onCallAdded(call: Call) {
        super.onCallAdded(call)
        Log.d(TAG, "onCallAdded: call state=${call.state}")
        CallManager.onCallAdded(call)

        // Eingehender Anruf: Vollbild-Benachrichtigung. Das ist der offizielle Weg, wie Android
        // eine Anruf-Ansicht auch bei ausgeschaltetem/gesperrtem Bildschirm nach vorne holt.
        if (call.state == Call.STATE_RINGING) {
            showIncomingCallNotification(call)
            call.registerCallback(object : Call.Callback() {
                override fun onStateChanged(c: Call, state: Int) {
                    if (state != Call.STATE_RINGING) cancelIncomingCallNotification()
                }
            })
        }

        // Bring the simplified call screen to the foreground (klappt, wenn der Bildschirm an ist)
        try {
            startActivity(callScreenIntent())
        } catch (e: Exception) {
            Log.w(TAG, "Could not start call screen directly, relying on full-screen notification", e)
        }
    }

    private fun callScreenIntent(): Intent = Intent(this, MainActivity::class.java).apply {
        flags = Intent.FLAG_ACTIVITY_NEW_TASK or
                Intent.FLAG_ACTIVITY_SINGLE_TOP or
                Intent.FLAG_ACTIVITY_REORDER_TO_FRONT
        putExtra("EXTRA_NAVIGATE_TO_CALL", true)
    }

    private fun showIncomingCallNotification(call: Call) {
        try {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
                val channel = NotificationChannel(
                    INCOMING_CHANNEL_ID,
                    "Eingehende Anrufe",
                    NotificationManager.IMPORTANCE_HIGH
                ).apply {
                    description = "Zeigt eingehende Anrufe im Vollbild"
                    setSound(null, null) // Klingelton spielt Android selbst
                }
                nm.createNotificationChannel(channel)
            }
            val pending = PendingIntent.getActivity(
                this, 1, callScreenIntent(),
                PendingIntent.FLAG_UPDATE_CURRENT or PendingIntent.FLAG_IMMUTABLE
            )
            val caller = call.details?.handle?.schemeSpecificPart ?: ""
            val notification = NotificationCompat.Builder(this, INCOMING_CHANNEL_ID)
                .setSmallIcon(android.R.drawable.sym_call_incoming)
                .setContentTitle("Anruf")
                .setContentText(caller)
                .setPriority(NotificationCompat.PRIORITY_MAX)
                .setCategory(NotificationCompat.CATEGORY_CALL)
                .setOngoing(true)
                .setContentIntent(pending)
                .setFullScreenIntent(pending, true)
                .build()
            nm.notify(INCOMING_NOTIFICATION_ID, notification)
        } catch (e: Exception) {
            Log.e(TAG, "Could not show incoming call notification", e)
        }
    }

    private fun cancelIncomingCallNotification() {
        try {
            val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
            nm.cancel(INCOMING_NOTIFICATION_ID)
        } catch (ignored: Exception) {}
    }

    override fun onCallRemoved(call: Call) {
        super.onCallRemoved(call)
        Log.d(TAG, "onCallRemoved: call state=${call.state}")
        cancelIncomingCallNotification()
        CallManager.onCallRemoved(call)
    }

    override fun onCallAudioStateChanged(audioState: CallAudioState) {
        super.onCallAudioStateChanged(audioState)
        Log.d(TAG, "onCallAudioStateChanged: muted=${audioState.isMuted}, route=${audioState.route}")
        CallManager.onAudioStateChanged(audioState)
    }

    override fun onBringToForeground(showDialpad: Boolean) {
        super.onBringToForeground(showDialpad)
        val intent = Intent(this, MainActivity::class.java).apply {
            flags = Intent.FLAG_ACTIVITY_NEW_TASK or
                    Intent.FLAG_ACTIVITY_SINGLE_TOP or
                    Intent.FLAG_ACTIVITY_REORDER_TO_FRONT
            putExtra("EXTRA_NAVIGATE_TO_CALL", true)
        }
        startActivity(intent)
    }

    override fun onDestroy() {
        super.onDestroy()
        Log.d(TAG, "onDestroy")
        CallManager.unregisterService()
    }
}
