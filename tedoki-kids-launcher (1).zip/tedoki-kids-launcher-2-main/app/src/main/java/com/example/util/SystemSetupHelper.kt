package com.example.util

import android.Manifest
import android.app.NotificationManager
import android.app.admin.DevicePolicyManager
import android.app.role.RoleManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.location.LocationManager
import android.net.Uri
import android.os.Build
import android.provider.Settings
import androidx.core.content.ContextCompat
import androidx.core.location.LocationManagerCompat
import com.example.sms.SmsRepository
import com.example.telecom.CallManager

/**
 * Alles, was die Einrichtung über die Android-Systemeinstellungen wissen muss:
 * Prüfen ("ist das schon erledigt?") und die passende Systemseite öffnen.
 *
 * Wichtig: Eine normale App darf Systemeinstellungen nicht selbst ändern.
 * Wir können nur prüfen und die richtige Seite öffnen – das Antippen machen die Eltern.
 */
object SystemSetupHelper {

    enum class Item {
        HOME,               // TEDOKI als Startbildschirm
        DIALER,             // TEDOKI als Telefon-App
        SMS,                // TEDOKI als SMS-App
        PERMISSIONS,        // Kontakte, Kamera, Standort, Benachrichtigungen …
        FULL_SCREEN_CALLS,  // Anrufe im Vollbild auch bei gesperrtem Bildschirm (Android 14+)
        LOCATION_ON,        // Standortdienst eingeschaltet (für SOS-SMS mit Standort)
        SYSTEM_LOCK_OFF     // Android-Bildschirmsperre entfernt (damit nur der Kinder-Sperrbildschirm kommt)
    }

    // ---------------------------------------------------------------- Prüfen

    fun isDone(
        context: Context,
        item: Item,
        permissions: List<String> = requiredPermissions(needCalls = true, needSms = true, needLocation = true)
    ): Boolean = when (item) {
        Item.HOME -> isDefaultHome(context)
        Item.DIALER -> CallManager.isDefaultDialer(context)
        Item.SMS -> SmsRepository.isDefaultSmsApp(context)
        Item.PERMISSIONS -> missingPermissions(context, permissions).isEmpty()
        Item.FULL_SCREEN_CALLS -> canUseFullScreenIntent(context)
        Item.LOCATION_ON -> isLocationEnabled(context)
        Item.SYSTEM_LOCK_OFF -> !LockscreenSecurityHelper.isAndroidSystemLockscreenEnabled(context)
    }

    fun isDefaultHome(context: Context): Boolean {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val rm = context.getSystemService(Context.ROLE_SERVICE) as? RoleManager
            if (rm != null && rm.isRoleAvailable(RoleManager.ROLE_HOME)) {
                return rm.isRoleHeld(RoleManager.ROLE_HOME)
            }
        }
        val homeIntent = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_HOME)
        val info = context.packageManager.resolveActivity(homeIntent, PackageManager.MATCH_DEFAULT_ONLY)
        return info?.activityInfo?.packageName == context.packageName
    }

    /** Laufzeit-Berechtigungen, die TEDOKI für die gewählten Funktionen braucht. */
    fun requiredPermissions(needCalls: Boolean, needSms: Boolean, needLocation: Boolean): List<String> {
        val list = mutableListOf(
            Manifest.permission.READ_CONTACTS,
            Manifest.permission.CAMERA
        )
        if (needCalls) {
            list += Manifest.permission.CALL_PHONE
            list += Manifest.permission.READ_PHONE_STATE
        }
        if (needSms) {
            list += Manifest.permission.SEND_SMS
            list += Manifest.permission.RECEIVE_SMS
            list += Manifest.permission.READ_SMS
        }
        if (needLocation) {
            list += Manifest.permission.ACCESS_FINE_LOCATION
            list += Manifest.permission.ACCESS_COARSE_LOCATION
        }
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            list += Manifest.permission.POST_NOTIFICATIONS
        }
        return list
    }

    fun missingPermissions(context: Context, permissions: List<String>): List<String> =
        permissions.filter {
            ContextCompat.checkSelfPermission(context, it) != PackageManager.PERMISSION_GRANTED
        }

    fun canUseFullScreenIntent(context: Context): Boolean {
        if (Build.VERSION.SDK_INT < 34) return true
        val nm = context.getSystemService(Context.NOTIFICATION_SERVICE) as? NotificationManager ?: return true
        return nm.canUseFullScreenIntent()
    }

    fun isLocationEnabled(context: Context): Boolean {
        val lm = context.getSystemService(Context.LOCATION_SERVICE) as? LocationManager ?: return false
        return LocationManagerCompat.isLocationEnabled(lm)
    }

    /** Android 13+ blockiert bei Apps "aus dem Internet" manche Freigaben ("Eingeschränkte Einstellung"). */
    fun mayBeRestrictedSetting(): Boolean = Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU

    // ---------------------------------------------------------------- Öffnen

    /** Intent, der per ActivityResult gestartet werden soll (Rollen-Dialoge). null = direkt mit open() öffnen. */
    fun roleRequestIntent(context: Context, item: Item): Intent? = when (item) {
        Item.HOME -> if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            val rm = context.getSystemService(Context.ROLE_SERVICE) as? RoleManager
            if (rm != null && rm.isRoleAvailable(RoleManager.ROLE_HOME)) rm.createRequestRoleIntent(RoleManager.ROLE_HOME) else null
        } else null
        Item.DIALER -> CallManager.createDefaultDialerIntent(context)
        Item.SMS -> SmsRepository.createDefaultSmsIntent(context)
        else -> null
    }

    /** Öffnet die passende Android-Einstellungsseite. Gibt false zurück, wenn gar nichts ging. */
    fun open(context: Context, item: Item): Boolean = when (item) {
        Item.HOME -> start(context, Intent(Settings.ACTION_HOME_SETTINGS))
        Item.DIALER, Item.SMS -> start(context, Intent(Settings.ACTION_MANAGE_DEFAULT_APPS_SETTINGS))
        Item.PERMISSIONS -> openAppInfo(context)
        Item.FULL_SCREEN_CALLS -> if (Build.VERSION.SDK_INT >= 34) {
            start(context, Intent(Settings.ACTION_MANAGE_APP_USE_FULL_SCREEN_INTENT, Uri.parse("package:${context.packageName}")))
        } else true
        Item.LOCATION_ON -> start(context, Intent(Settings.ACTION_LOCATION_SOURCE_SETTINGS))
        Item.SYSTEM_LOCK_OFF -> {
            // Öffnet direkt "Displaysperre auswählen" (dort "Keine" wählen). Fallback: Sicherheit.
            start(context, Intent(DevicePolicyManager.ACTION_SET_NEW_PASSWORD)) ||
                start(context, Intent(Settings.ACTION_SECURITY_SETTINGS))
        }
    }

    /** App-Info von TEDOKI – dort gibt es oben rechts (⋮) "Eingeschränkte Einstellungen zulassen". */
    fun openAppInfo(context: Context): Boolean =
        start(context, Intent(Settings.ACTION_APPLICATION_DETAILS_SETTINGS, Uri.parse("package:${context.packageName}")))

    private fun start(context: Context, intent: Intent): Boolean = try {
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
        true
    } catch (e: Exception) {
        try {
            context.startActivity(Intent(Settings.ACTION_SETTINGS).addFlags(Intent.FLAG_ACTIVITY_NEW_TASK))
            true
        } catch (ignored: Exception) {
            false
        }
    }
}
