package com.example.data.quiz

import com.example.model.quiz.QuizCategory
import com.example.model.quiz.QuizModule
import com.example.model.quiz.QuizOption
import com.example.model.quiz.QuizQuestion

internal val fotosMachenModule = QuizModule(
    category = QuizCategory.FOTOS_MACHEN,
    title = "Fotos machen & Kamera",
    childIntroText = "Mit der Kamera kannst du Fotos und Videos machen. Damit kannst du schöne Momente festhalten.",
    childQuestions = listOf(
        QuizQuestion(
            id = "c_cam_1",
            title = "Freund fotografieren",
            situation = "Du möchtest ein Foto von deinem Freund machen. Was machst du zuerst?",
            options = listOf(
                QuizOption("A", "Heimlich fotografieren."),
                QuizOption("B", "Fragen, ob du ihn fotografieren darfst."),
                QuizOption("C", "Das Foto sofort an alle schicken."),
                QuizOption("D", "Das Foto ins Internet stellen.")
            ),
            correctIndex = 1,
            explanation = "Frage die Person vorher. Jeder Mensch darf mitentscheiden, ob ein Foto von ihm gemacht und weitergegeben wird."
        ),
        QuizQuestion(
            id = "c_cam_2",
            title = "Versehentliches Foto",
            situation = "Du hast aus Versehen ein Foto gemacht, das du nicht behalten möchtest. Was kannst du machen?",
            options = listOf(
                QuizOption("A", "Es an alle schicken."),
                QuizOption("B", "Es löschen."),
                QuizOption("C", "Es posten."),
                QuizOption("D", "Die Kamera kaputtmachen.")
            ),
            correctIndex = 1,
            explanation = "Wenn du ein Foto nicht behalten möchtest, kannst du es löschen."
        ),
        QuizQuestion(
            id = "c_cam_3",
            title = "Hausnummer im Bild",
            situation = "Auf einem Foto ist neben deinem Freund auch die Hausnummer zu sehen. Du möchtest das Foto verschicken. Was solltest du bedenken?",
            options = listOf(
                QuizOption("A", "Die Hausnummer ist egal."),
                QuizOption("B", "Das Foto könnte persönliche Informationen zeigen."),
                QuizOption("C", "Eine Hausnummer darf immer ins Internet."),
                QuizOption("D", "Man sollte das Foto möglichst vielen Menschen schicken.")
            ),
            correctIndex = 1,
            explanation = "Eine Hausnummer kann etwas über den Wohnort verraten. Prüfe deshalb vor dem Verschicken, welche persönlichen Informationen auf einem Foto zu sehen sind."
        )
    ),
    childSummaryPoints = listOf(
        "Andere Menschen immer fragen, bevor du sie fotografierst.",
        "Versehentliche oder unschöne Fotos einfach löschen.",
        "Auf den Hintergrund achten: Keine Hausnummern oder Adressen mitfotografieren."
    ),
    parentIntroText = "Mit der Kamera kann Ihr Kind Fotos und Videos aufnehmen. Dabei gibt es einige wichtige Themen, die Sie gemeinsam besprechen sollten.",
    parentFocusTopics = listOf(
        "Privatsphäre anderer Menschen",
        "Standortinformationen im Bild",
        "Weitergabe von Fotos",
        "Umgang mit sensiblen Inhalten"
    ),
    parentQuestions = listOf(
        QuizQuestion(
            id = "p_cam_1",
            title = "Erlaubnis einholen",
            situation = "Ihr Kind möchte ein anderes Kind fotografieren. Was sollten Sie vermitteln?",
            options = listOf(
                QuizOption("A", "Fotografieren ist immer erlaubt."),
                QuizOption("B", "Vorher fragen, ob die Person fotografiert werden möchte."),
                QuizOption("C", "Heimliche Fotos sind besonders lustig."),
                QuizOption("D", "Das Foto sollte sofort veröffentlicht werden.")
            ),
            correctIndex = 1,
            explanation = "Das Fragen respektiert die andere Person und schafft eine wichtige Grundlage für einen verantwortungsvollen Umgang mit Bildern."
        ),
        QuizQuestion(
            id = "p_cam_2",
            title = "Aussortieren und Löschen",
            situation = "Ihr Kind hat versehentlich ein Foto gemacht, das es nicht behalten möchte. Was können Sie zeigen?",
            options = listOf(
                QuizOption("A", "Das Foto an andere schicken."),
                QuizOption("B", "Das Foto löschen."),
                QuizOption("C", "Das Foto veröffentlichen."),
                QuizOption("D", "Die Kamera-App löschen.")
            ),
            correctIndex = 1,
            explanation = "Ein Foto muss nicht behalten werden. Das Kind kann lernen, nicht benötigte Aufnahmen zu löschen."
        ),
        QuizQuestion(
            id = "p_cam_3",
            title = "Hintergrunddetails",
            situation = "Auf einem Foto sind eine Hausnummer und weitere persönliche Informationen zu erkennen. Was sollten Sie besprechen?",
            options = listOf(
                QuizOption("A", "Solche Informationen sind egal."),
                QuizOption("B", "Vor dem Teilen prüfen, welche persönlichen Informationen das Foto verrät."),
                QuizOption("C", "Das Foto möglichst öffentlich posten."),
                QuizOption("D", "Die Hausnummer in den Beitrag schreiben.")
            ),
            correctIndex = 1,
            explanation = "Fotos können neben dem eigentlichen Motiv weitere Informationen über Personen und Orte enthalten."
        )
    ),
    parentTips = listOf(
        "Standortinformationen bei Fotos prüfen (Geotagging).",
        "Regeln zur Weitergabe von Familienbildern besprechen.",
        "Sensibler Umgang mit Fotos fremder Personen."
    )
)

internal val fotosVonAnderenModule = QuizModule(
    category = QuizCategory.FOTOS_VON_ANDEREN,
    title = "Fotos von anderen",
    childIntroText = "Bilder von anderen Menschen sind privat. Lerne, wie du respektvoll damit umgehst.",
    childQuestions = listOf(
        QuizQuestion(
            id = "c_oth_1",
            title = "Lustiges Foto teilen",
            situation = "Du hast ein lustiges Foto von deinem Freund gemacht. Darfst du es einfach in eine WhatsApp-Gruppe schicken?",
            options = listOf(
                QuizOption("A", "Ja, immer."),
                QuizOption("B", "Nur wenn niemand das Foto sehen kann."),
                QuizOption("C", "Du solltest zuerst fragen, ob das okay ist."),
                QuizOption("D", "Ja, wenn das Foto lustig ist.")
            ),
            correctIndex = 2,
            explanation = "Auch ein lustiges Foto sollte nicht einfach ohne Zustimmung weitergegeben werden."
        ),
        QuizQuestion(
            id = "c_oth_2",
            title = "Bitte nicht weiterschicken",
            situation = "Deine Freundin sagt: „Bitte schick dieses Foto nicht weiter.“ Was machst du?",
            options = listOf(
                QuizOption("A", "Trotzdem weiterschicken."),
                QuizOption("B", "Nur an eine Person schicken."),
                QuizOption("C", "Das Foto nicht weitergeben."),
                QuizOption("D", "Es ins Internet stellen.")
            ),
            correctIndex = 2,
            explanation = "Wenn jemand ausdrücklich sagt, dass ein Foto nicht weitergegeben werden soll, respektierst du diesen Wunsch."
        )
    ),
    childSummaryPoints = listOf(
        "Auch lustige Bilder nicht ohne Zustimmung verschicken.",
        "Wenn jemand 'Nein' sagt: Wunsch immer respektieren.",
        "Das Recht am eigenen Bild gilt für alle."
    ),
    parentIntroText = "Das Recht am eigenen Bild ist eine zentrale Medienkompetenz für Kinder und Jugendliche.",
    parentFocusTopics = listOf(
        "Recht am eigenen Bild verstehen",
        "Respekt vor den Grenzen anderer",
        "Gemeinsames Abwägen vor Veröffentlichungen"
    ),
    parentQuestions = listOf(
        QuizQuestion(
            id = "p_oth_1",
            title = "Bilder in Gruppen teilen",
            situation = "Ihr Kind möchte ein lustiges Foto von einem Freund in eine WhatsApp-Gruppe schicken. Was ist sinnvoll?",
            options = listOf(
                QuizOption("A", "Lustige Fotos dürfen immer weitergegeben werden."),
                QuizOption("B", "Prüfen, ob die abgebildete Person mit dem Teilen einverstanden ist."),
                QuizOption("C", "In Gruppen gelten keine Regeln."),
                QuizOption("D", "Es reicht, wenn mindestens fünf Personen das Foto lustig finden.")
            ),
            correctIndex = 1,
            explanation = "Auch in privaten Gruppen sollte der Umgang mit Bildern anderer Menschen respektvoll sein."
        ),
        QuizQuestion(
            id = "p_oth_2",
            title = "Grenzen respektieren",
            situation = "Ein anderes Kind bittet darum, ein Foto nicht weiterzugeben. Was sollte Ihr Kind tun?",
            options = listOf(
                QuizOption("A", "Die Bitte ignorieren."),
                QuizOption("B", "Das Foto nicht weitergeben."),
                QuizOption("C", "Das Foto an eine Person schicken."),
                QuizOption("D", "Das Foto öffentlich posten.")
            ),
            correctIndex = 1,
            explanation = "Die ausdrückliche Bitte, ein Foto nicht weiterzugeben, sollte respektiert werden."
        ),
        QuizQuestion(
            id = "p_oth_3",
            title = "Gruppenfotos veröffentlichen",
            situation = "Ihr Kind möchte ein Foto veröffentlichen, auf dem mehrere Kinder zu sehen sind. Was ist sinnvoll?",
            options = listOf(
                QuizOption("A", "Sofort veröffentlichen."),
                QuizOption("B", "Gemeinsam prüfen, ob die Veröffentlichung für die abgebildeten Personen in Ordnung ist."),
                QuizOption("C", "Nur den Beitragstext ändern."),
                QuizOption("D", "Das Foto zusätzlich an unbekannte Personen schicken.")
            ),
            correctIndex = 1,
            explanation = "Bei Bildern mit anderen Personen sollte auch deren Situation und Privatsphäre berücksichtigt werden."
        )
    ),
    parentTips = listOf(
        "Vorbild sein: Selbst nicht ungefragt Bilder der Kinder posten.",
        "Mit dem Kind die Gefühle der abgebildeten Person besprechen.",
        "Eindeutige Familienregeln für das Teilen von Fotos vereinbaren."
    )
)
