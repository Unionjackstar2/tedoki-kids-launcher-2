package com.example.ui.home

import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.geometry.Offset
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.window.Dialog
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.foundation.Canvas
import androidx.compose.animation.core.*
import kotlinx.coroutines.isActive
import androidx.compose.runtime.withFrameMillis
import kotlin.random.Random
import com.example.ui.theme.AssistiveBlue
import androidx.compose.ui.graphics.drawscope.rotate
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.data.quiz.PedagogyPreferences
import com.example.model.ButtonType
import com.example.model.LauncherButton
import com.example.model.quiz.AppPedagogyStatus
import com.example.model.quiz.QuizCategory
import com.example.ui.theme.AssistiveBackground
import com.example.ui.theme.AssistiveBorder
import com.example.ui.theme.AssistiveGreen
import com.example.ui.theme.AssistiveSurface
import com.example.ui.theme.AssistiveTextMuted
import com.example.ui.theme.AssistiveTextPrimary
import com.example.ui.theme.AssistiveTextSecondary

@Composable
internal fun ChildAvatarExplanationModal(
    childName: String,
    childAvatar: String,
    buttons: List<LauncherButton>,
    pedagogyStatuses: Map<String, AppPedagogyStatus>,
    onDismiss: () -> Unit
) {
    val avatarPreset = com.example.ui.setup.PRESET_AVATARS.find { it.id == childAvatar }
    val isCustomPhoto = childAvatar.startsWith("content://") || childAvatar.startsWith("file://")

    // Determine unlocked features from buttons and pedagogyStatuses
    val unlockedItems = remember(buttons, pedagogyStatuses) {
        val list = mutableListOf<UnlockedFeatureItem>()
        val seenKeys = mutableSetOf<String>()

        for (btn in buttons) {
            val appKey = PedagogyPreferences.resolveAppKey(btn)
            val quizCat = PedagogyPreferences.resolveQuizCategory(btn)
            val isUnlocked = if (quizCat != null) {
                pedagogyStatuses[appKey]?.isFullyUnlocked() == true
            } else {
                true
            }

            if (isUnlocked) {
                val uniqueKey = when (btn.type) {
                    ButtonType.CAMERA -> "camera"
                    ButtonType.PHOTOS -> "photos"
                    ButtonType.CALL -> "call_${btn.title}"
                    ButtonType.BROWSER -> "browser"
                    ButtonType.SMS -> "sms"
                    ButtonType.APP -> "app_${btn.packageName ?: btn.id}"
                }
                if (!seenKeys.contains(uniqueKey)) {
                    seenKeys.add(uniqueKey)
                    val item = when (btn.type) {
                        ButtonType.CAMERA -> UnlockedFeatureItem(
                            id = uniqueKey,
                            title = "Kamera",
                            emoji = "📸",
                            colorHex = 0xFF2563EB,
                            explanation = "Du darfst tolle Fotos machen! Frage Freunde vorher um Erlaubnis."
                        )
                        ButtonType.PHOTOS -> UnlockedFeatureItem(
                            id = uniqueKey,
                            title = "Fotos & Galerie",
                            emoji = "🖼️",
                            colorHex = 0xFFDB2777,
                            explanation = "Hier kannst du deine eigenen Bilder und Erinnerungen anschauen."
                        )
                        ButtonType.CALL -> UnlockedFeatureItem(
                            id = uniqueKey,
                            title = "Anrufen: ${btn.title}",
                            emoji = "📞",
                            colorHex = 0xFF059669,
                            explanation = "Du kannst ${btn.title} direkt anrufen. Sag Bescheid, wenn du Hilfe brauchst!"
                        )
                        ButtonType.BROWSER -> UnlockedFeatureItem(
                            id = uniqueKey,
                            title = "Sicheres Internet",
                            emoji = "🌐",
                            colorHex = 0xFF0284C7,
                            explanation = "Entdecke geprüfte Kinderseiten wie Die Maus, KiKA und FragFINN."
                        )
                        ButtonType.SMS -> UnlockedFeatureItem(
                            id = uniqueKey,
                            title = "SMS Nachrichten",
                            emoji = "💬",
                            colorHex = 0xFF6366F1,
                            explanation = "Schreibe und empfange SMS mit deinen Kontakten."
                        )
                        ButtonType.APP -> {
                            when (quizCat) {
                                QuizCategory.WHATSAPP -> UnlockedFeatureItem(
                                    id = uniqueKey,
                                    title = "WhatsApp / Chat",
                                    emoji = "💬",
                                    colorHex = 0xFF25D366,
                                    explanation = "Schreibe liebe Nachrichten an Familie und halte Passwörter geheim."
                                )
                                QuizCategory.NACHRICHTEN, QuizCategory.SPRACHNACHRICHTEN -> UnlockedFeatureItem(
                                    id = uniqueKey,
                                    title = btn.title,
                                    emoji = "💬",
                                    colorHex = 0xFF6366F1,
                                    explanation = "Freundlich chatten und bei komischen Nachrichten den Eltern Bescheid sagen."
                                )
                                QuizCategory.INTERNET_SURFEN -> UnlockedFeatureItem(
                                    id = uniqueKey,
                                    title = btn.title,
                                    emoji = "🌐",
                                    colorHex = 0xFF0284C7,
                                    explanation = "Sicher im Internet surfen und auf geprüften Webseiten bleiben."
                                )
                                else -> UnlockedFeatureItem(
                                    id = uniqueKey,
                                    title = btn.title,
                                    emoji = "📱",
                                    colorHex = 0xFF4F46E5,
                                    explanation = "Freigeschaltete App. Nutze sie achtsam und halte die vereinbarten Zeiten ein."
                                )
                            }
                        }
                    }
                    list.add(item)
                }
            }
        }
        list
    }

    // Count how many features are currently locked
    val lockedCount = remember(buttons, pedagogyStatuses) {
        buttons.count { btn ->
            val appKey = PedagogyPreferences.resolveAppKey(btn)
            val quizCat = PedagogyPreferences.resolveQuizCategory(btn)
            quizCat != null && pedagogyStatuses[appKey]?.isFullyUnlocked() != true
        }
    }

    Dialog(
        onDismissRequest = onDismiss
    ) {
        Card(
            shape = RoundedCornerShape(24.dp),
            colors = CardDefaults.cardColors(containerColor = AssistiveSurface),
            border = BorderStroke(1.5.dp, AssistiveBorder),
            elevation = CardDefaults.cardElevation(defaultElevation = 8.dp),
            modifier = Modifier
                .fillMaxWidth()
                .padding(horizontal = 4.dp)
                .testTag("child_avatar_modal")
        ) {
            Column(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(18.dp),
                horizontalAlignment = Alignment.CenterHorizontally
            ) {
                // Top Header Row with Avatar, Greeting & Big Close Button (X)
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(12.dp),
                        modifier = Modifier.weight(1f)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(48.dp)
                                .clip(CircleShape)
                                .background(
                                    if (isCustomPhoto) Color.Transparent
                                    else Color(avatarPreset?.bgHex ?: 0xFF3B82F6)
                                )
                                .border(1.5.dp, AssistiveBorder, CircleShape),
                            contentAlignment = Alignment.Center
                        ) {
                            if (isCustomPhoto) {
                                AsyncImage(
                                    model = childAvatar,
                                    contentDescription = "Avatar",
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier.fillMaxSize().clip(CircleShape)
                                )
                            } else {
                                Text(text = avatarPreset?.emoji ?: "🦁", fontSize = 26.sp)
                            }
                        }

                        Column {
                            Text(
                                text = "Hallo ${childName.ifBlank { "Entdecker" }}! 🌟",
                                fontSize = 17.sp,
                                fontWeight = FontWeight.Bold,
                                color = AssistiveTextPrimary
                            )
                            Text(
                                text = "Deine freigeschalteten Apps:",
                                fontSize = 13.sp,
                                color = AssistiveTextSecondary
                            )
                        }
                    }

                    // Big X Close Button
                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(AssistiveBackground)
                            .border(1.dp, AssistiveBorder, CircleShape)
                            .testTag("close_avatar_modal_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Schließen",
                            tint = AssistiveTextPrimary,
                            modifier = Modifier.size(24.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(14.dp))

                // Content: List of unlocked items or empty state
                if (unlockedItems.isEmpty()) {
                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = AssistiveBackground),
                        border = BorderStroke(1.dp, AssistiveBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Row(
                            modifier = Modifier.padding(14.dp),
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(12.dp)
                        ) {
                            Text(text = "🌱", fontSize = 32.sp)
                            Column(modifier = Modifier.weight(1f)) {
                                Text(
                                    text = "Noch keine Apps freigeschaltet",
                                    fontSize = 14.sp,
                                    fontWeight = FontWeight.Bold,
                                    color = AssistiveTextPrimary
                                )
                                Spacer(modifier = Modifier.height(2.dp))
                                Text(
                                    text = "Tippe auf eine Kachel auf deinem Homescreen, um gemeinsam mit deinen Eltern das Quiz zu starten!",
                                    fontSize = 12.sp,
                                    color = AssistiveTextSecondary,
                                    lineHeight = 16.sp
                                )
                            }
                        }
                    }
                } else {
                    Column(
                        modifier = Modifier.fillMaxWidth(),
                        verticalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        unlockedItems.forEach { item ->
                            Surface(
                                shape = RoundedCornerShape(14.dp),
                                color = AssistiveBackground,
                                border = BorderStroke(1.dp, AssistiveBorder),
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Row(
                                    modifier = Modifier.padding(10.dp),
                                    verticalAlignment = Alignment.CenterVertically,
                                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                                ) {
                                    Box(
                                        modifier = Modifier
                                            .size(34.dp)
                                            .clip(CircleShape)
                                            .background(Color(item.colorHex)),
                                        contentAlignment = Alignment.Center
                                    ) {
                                        Text(text = item.emoji, fontSize = 18.sp)
                                    }

                                    Column(modifier = Modifier.weight(1f)) {
                                        Text(
                                            text = item.title,
                                            fontSize = 13.sp,
                                            fontWeight = FontWeight.Bold,
                                            color = AssistiveTextPrimary
                                        )
                                        Text(
                                            text = item.explanation,
                                            fontSize = 11.sp,
                                            color = AssistiveTextSecondary,
                                            lineHeight = 15.sp
                                        )
                                    }
                                }
                            }
                        }
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // Footer hint
                if (lockedCount > 0) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Icon(
                            imageVector = Icons.Default.Lock,
                            contentDescription = null,
                            tint = Color(0xFF64748B),
                            modifier = Modifier.size(14.dp)
                        )
                        Text(
                            text = "Noch $lockedCount Funktion(en) mit Eltern per Quiz freischaltbar",
                            fontSize = 11.sp,
                            fontWeight = FontWeight.Medium,
                            color = AssistiveTextMuted
                        )
                    }
                } else {
                    Text(
                        text = "Super gemacht! Alle deine Funktionen sind freigeschaltet. 🚀",
                        fontSize = 11.sp,
                        fontWeight = FontWeight.Medium,
                        color = AssistiveGreen
                    )
                }
            }
        }
    }
}

data class ConfettiParticle(
    val xFraction: Float,
    var y: Float,
    val size: Float,
    val color: Color,
    val speed: Float,
    val rotation: Float,
    val rotSpeed: Float
)

@Composable
fun CelebrationModal(
    message: String,
    onDismiss: () -> Unit
) {
    Dialog(
        onDismissRequest = onDismiss,
        properties = androidx.compose.ui.window.DialogProperties(
            usePlatformDefaultWidth = false,
            dismissOnBackPress = true,
            dismissOnClickOutside = false
        )
    ) {
        Box(
            modifier = Modifier
                .fillMaxSize()
                .background(Color.Black.copy(alpha = 0.65f))
        ) {
            // Live Confetti Canvas Particle System
            ConfettiEffect()

            // Main Content Card
            Card(
                shape = RoundedCornerShape(28.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(2.dp, AssistiveBorder),
                modifier = Modifier
                    .fillMaxWidth(0.85f)
                    .align(Alignment.Center)
            ) {
                Box(modifier = Modifier.fillMaxWidth()) {
                    // Close "X" Button top right
                    IconButton(
                        onClick = onDismiss,
                        modifier = Modifier
                            .align(Alignment.TopEnd)
                            .padding(12.dp)
                            .testTag("celebration_close_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Schließen",
                            tint = AssistiveTextSecondary,
                            modifier = Modifier.size(26.dp)
                        )
                    }

                    Column(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(horizontal = 24.dp, vertical = 32.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(18.dp)
                    ) {
                        // High-fidelity Reward Badge / Icon
                        Box(
                            modifier = Modifier
                                .size(84.dp)
                                .clip(CircleShape)
                                .background(Color(0xFFFEF3C7)),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(text = "🎉", fontSize = 48.sp)
                        }

                        Text(
                            text = "Super!",
                            fontSize = 28.sp,
                            fontWeight = FontWeight.Black,
                            color = AssistiveTextPrimary,
                            textAlign = TextAlign.Center
                        )

                        Text(
                            text = "Du hast die neue Funktion freigeschaltet!",
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = AssistiveBlue,
                            textAlign = TextAlign.Center,
                            lineHeight = 24.sp
                        )

                        // Custom message explaining the unlocked app
                        val cleanMessage = message.replace(" wurde freigeschaltet. Viel Spaß und denke an das, was du gelernt hast!", "")
                        Text(
                            text = "Du kannst jetzt die Funktion \"$cleanMessage\" frei nutzen.",
                            fontSize = 15.sp,
                            color = AssistiveTextSecondary,
                            textAlign = TextAlign.Center,
                            lineHeight = 20.sp,
                            modifier = Modifier.padding(horizontal = 8.dp)
                        )

                        Spacer(modifier = Modifier.height(8.dp))

                        Button(
                            onClick = onDismiss,
                            shape = RoundedCornerShape(16.dp),
                            colors = ButtonDefaults.buttonColors(containerColor = AssistiveBlue),
                            modifier = Modifier.fillMaxWidth(0.8f)
                        ) {
                            Text(
                                text = "Los geht's!",
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Bold,
                                color = Color.White
                            )
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun ConfettiEffect() {
    val density = androidx.compose.ui.platform.LocalDensity.current
    val sizeBase = remember { with(density) { 14.dp.toPx() } }
    
    val particles = remember {
        val list = mutableListOf<ConfettiParticle>()
        val colors = listOf(
            Color(0xFFFFC107), // Yellow
            Color(0xFFFF5722), // Orange
            Color(0xFFE91E63), // Pink
            Color(0xFF00BCD4), // Cyan
            Color(0xFF4CAF50), // Green
            Color(0xFF9C27B0)  // Purple
        )
        for (i in 0..65) {
            list.add(
                ConfettiParticle(
                    xFraction = Random.nextFloat(),
                    y = -Random.nextFloat() * 1500f,
                    size = Random.nextFloat() * sizeBase + sizeBase / 2,
                    color = colors.random(),
                    speed = Random.nextFloat() * 8f + 5f,
                    rotation = Random.nextFloat() * 360f,
                    rotSpeed = Random.nextFloat() * 5f - 2.5f
                )
            )
        }
        list
    }

    var frameState by remember { mutableStateOf(0L) }

    LaunchedEffect(Unit) {
        while (isActive) {
            withFrameMillis { time ->
                frameState = time
                for (p in particles) {
                    p.y += p.speed
                    if (p.y > 2500f) {
                        p.y = -50f
                    }
                }
            }
        }
    }

    Canvas(modifier = Modifier.fillMaxSize()) {
        val redraw = frameState
        for (p in particles) {
            val drawX = p.xFraction * size.width
            val drawY = p.y
            if (drawY in -100f..size.height) {
                rotate(
                    degrees = p.rotation + (drawY * p.rotSpeed),
                    pivot = androidx.compose.ui.geometry.Offset(drawX, drawY)
                ) {
                    drawRect(
                        color = p.color,
                        topLeft = androidx.compose.ui.geometry.Offset(drawX - p.size / 2, drawY - p.size / 2),
                        size = androidx.compose.ui.geometry.Size(p.size, p.size / 2)
                    )
                }
            }
        }
    }
}
