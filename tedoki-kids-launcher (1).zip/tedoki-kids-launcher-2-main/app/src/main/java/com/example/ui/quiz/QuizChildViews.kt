package com.example.ui.quiz

import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.PriorityHigh
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.quiz.QuizCategory
import com.example.model.quiz.QuizOption
import com.example.ui.theme.AssistiveAmber
import com.example.ui.theme.AssistiveAmberLight
import com.example.ui.theme.AssistiveBackground
import com.example.ui.theme.AssistiveBlue
import com.example.ui.theme.AssistiveBlueLight
import com.example.ui.theme.AssistiveBorder
import com.example.ui.theme.AssistiveGreen
import com.example.ui.theme.AssistiveGreenLight
import com.example.ui.theme.AssistiveSurface
import com.example.ui.theme.AssistiveTextMuted
import com.example.ui.theme.AssistiveTextPrimary
import com.example.ui.theme.AssistiveTextSecondary

// -------------------------------------------------------------
// Screen Composable Views
// -------------------------------------------------------------

@Composable
internal fun ChildIntroView(
    appName: String,
    category: QuizCategory,
    icon: ImageVector,
    introText: String,
    isReview: Boolean,
    onStart: () -> Unit
) {
    val introComic = when (category) {
        QuizCategory.ANRUFEN -> ComicType.INTRO_CALL
        QuizCategory.NACHRICHTEN -> ComicType.INTRO_MESSAGES
        QuizCategory.FOTOS_MACHEN -> ComicType.INTRO_CAMERA
        QuizCategory.FOTOS_VON_ANDEREN -> ComicType.INTRO_PHOTOS
        QuizCategory.INTERNET_SURFEN -> ComicType.INTRO_SURF
        QuizCategory.WHATSAPP -> ComicType.INTRO_WHATSAPP
        QuizCategory.UNBEKANNTE_NUMMERN -> ComicType.INTRO_CALL
        QuizCategory.BEVOR_VERSCHICKEN -> ComicType.INTRO_PHOTOS
        QuizCategory.VIDEOS, QuizCategory.SPIELE -> ComicType.INTRO_SURF
        else -> ComicType.INTRO_CAMERA
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.fillMaxWidth()
        ) {
            Spacer(modifier = Modifier.height(10.dp))

            Box(
                modifier = Modifier
                    .size(68.dp)
                    .clip(CircleShape)
                    .background(AssistiveBlue),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = appName,
                    tint = Color.White,
                    modifier = Modifier.size(38.dp)
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = appName,
                fontSize = 26.sp,
                fontWeight = FontWeight.Bold,
                color = AssistiveTextPrimary
            )

            Spacer(modifier = Modifier.height(12.dp))

            // Comic Illustration: Category-specific intro illustration
            ComicIllustrationCard(
                type = introComic,
                modifier = Modifier.padding(horizontal = 4.dp)
            )

            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = introText,
                fontSize = 15.sp,
                color = AssistiveTextSecondary,
                textAlign = TextAlign.Center,
                lineHeight = 22.sp,
                modifier = Modifier.padding(horizontal = 8.dp)
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Yellow Info Callout
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = AssistiveAmberLight),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Box(
                        modifier = Modifier
                            .size(34.dp)
                            .clip(CircleShape)
                            .background(AssistiveAmber),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.PriorityHigh,
                            contentDescription = "Wichtig",
                            tint = Color.White,
                            modifier = Modifier.size(20.dp)
                        )
                    }

                    Spacer(modifier = Modifier.width(12.dp))

                    Text(
                        text = if (isReview) {
                            "Wir schauen heute noch einmal gemeinsam, was du über $appName weißt."
                        } else {
                            "Bevor du $appName benutzen kannst, schauen wir uns gemeinsam an, was dabei wichtig ist."
                        },
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Medium,
                        color = Color(0xFF78350F),
                        lineHeight = 20.sp
                    )
                }
            }
        }

        Button(
            onClick = onStart,
            shape = RoundedCornerShape(16.dp),
            colors = ButtonDefaults.buttonColors(containerColor = AssistiveBlue),
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp)
                .padding(top = 16.dp)
                .testTag("quiz_start_button")
        ) {
            Text(
                text = "Los geht\'s!",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
        }
    }
}

@Composable
internal fun QuestionView(
    stepTitle: String,
    questionTitle: String,
    situationText: String,
    questionId: String? = null,
    comicType: ComicType? = null,
    options: List<QuizOption>,
    selectedIndex: Int?,
    onOptionSelected: (Int) -> Unit,
    onNext: () -> Unit,
    onSpeakSituation: (() -> Unit)? = null,
    onSpeakOption: ((QuizOption) -> Unit)? = null
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Step pill
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .background(AssistiveGreenLight)
                    .padding(horizontal = 14.dp, vertical = 6.dp)
            ) {
                Text(
                    text = stepTitle,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = AssistiveGreen
                )
            }

            Spacer(modifier = Modifier.height(10.dp))

            Row(
                modifier = Modifier.fillMaxWidth().padding(horizontal = 8.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.Center
            ) {
                Text(
                    text = questionTitle,
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = AssistiveTextPrimary,
                    textAlign = TextAlign.Center,
                    modifier = Modifier.weight(1f, fill = false)
                )
            }

            // Comic Illustration matching question topic
            Spacer(modifier = Modifier.height(10.dp))
            ComicIllustrationCard(
                type = comicType ?: ComicType.QUESTION_ASK_PHOTO,
                questionId = questionId,
                modifier = Modifier.padding(horizontal = 4.dp)
            )

                Spacer(modifier = Modifier.height(10.dp))

                // Situation card with on-demand audio read-aloud button
                Card(
                    shape = RoundedCornerShape(16.dp),
                    colors = CardDefaults.cardColors(containerColor = AssistiveSurface),
                    elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                    modifier = Modifier.fillMaxWidth()
                ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    if (onSpeakSituation != null) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Situation",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = AssistiveTextMuted
                            )
                            IconButton(
                                onClick = onSpeakSituation,
                                modifier = Modifier
                                    .size(32.dp)
                                    .testTag("quiz_speak_situation_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.VolumeUp,
                                    contentDescription = "Frage und Situation vorlesen",
                                    tint = AssistiveBlue,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(4.dp))
                    }
                    Text(
                        text = situationText,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Medium,
                        color = AssistiveTextPrimary,
                        lineHeight = 22.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Options
            options.forEachIndexed { index, option ->
                val isSelected = selectedIndex == index
                val borderCol = if (isSelected) AssistiveBlue else AssistiveBorder
                val bgCol = if (isSelected) AssistiveBlueLight else AssistiveSurface

                Card(
                    shape = RoundedCornerShape(14.dp),
                    colors = CardDefaults.cardColors(containerColor = bgCol),
                    border = androidx.compose.foundation.BorderStroke(2.dp, borderCol),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 5.dp)
                        .clip(RoundedCornerShape(14.dp))
                        .clickable { onOptionSelected(index) }
                        .testTag("option_${option.id}")
                ) {
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(14.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Box(
                            modifier = Modifier
                                .size(32.dp)
                                .clip(CircleShape)
                                .background(if (isSelected) AssistiveBlue else AssistiveBackground),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(
                                text = option.id,
                                fontSize = 15.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isSelected) Color.White else AssistiveTextPrimary
                            )
                        }

                        Spacer(modifier = Modifier.width(12.dp))

                        Text(
                            text = option.text,
                            fontSize = 15.sp,
                            fontWeight = if (isSelected) FontWeight.SemiBold else FontWeight.Normal,
                            color = AssistiveTextPrimary,
                            lineHeight = 21.sp,
                            modifier = Modifier.weight(1f)
                        )

                        if (onSpeakOption != null) {
                            IconButton(
                                onClick = { onSpeakOption(option) },
                                modifier = Modifier
                                    .size(36.dp)
                                    .testTag("quiz_speak_option_${option.id}")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.VolumeUp,
                                    contentDescription = "Option ${option.id} vorlesen",
                                    tint = if (isSelected) AssistiveBlue else AssistiveTextMuted,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                    }
                }
            }
        }

        Button(
            onClick = onNext,
            enabled = selectedIndex != null,
            shape = RoundedCornerShape(16.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = AssistiveBlue,
                disabledContainerColor = AssistiveBorder
            ),
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp)
                .padding(top = 16.dp)
                .testTag("quiz_next_button")
        ) {
            Text(
                text = "Weiter",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
        }
    }
}

@Composable
internal fun FeedbackView(
    stepTitle: String,
    isCorrect: Boolean,
    explanationText: String,
    questionId: String? = null,
    onNext: () -> Unit,
    onSpeakExplanation: (() -> Unit)? = null
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Box(
                modifier = Modifier
                    .clip(RoundedCornerShape(12.dp))
                    .background(if (isCorrect) AssistiveGreenLight else AssistiveAmberLight)
                    .padding(horizontal = 14.dp, vertical = 6.dp)
            ) {
                Text(
                    text = stepTitle,
                    fontSize = 14.sp,
                    fontWeight = FontWeight.Bold,
                    color = if (isCorrect) AssistiveGreen else AssistiveAmber
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Comic Illustration matching question topic
            ComicIllustrationCard(
                type = if (isCorrect) ComicType.FEEDBACK_SUCCESS else ComicType.FEEDBACK_RETRY,
                questionId = if (isCorrect) questionId else null,
                modifier = Modifier.padding(horizontal = 4.dp)
            )

            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = if (isCorrect) "Genau richtig!" else "Nochmal überlegen!",
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                color = if (isCorrect) AssistiveGreen else AssistiveAmber
            )

            Spacer(modifier = Modifier.height(14.dp))

            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = AssistiveSurface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    if (onSpeakExplanation != null) {
                        Row(
                            modifier = Modifier.fillMaxWidth(),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Text(
                                text = "Erklärung",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = AssistiveTextMuted
                            )
                            IconButton(
                                onClick = onSpeakExplanation,
                                modifier = Modifier
                                    .size(32.dp)
                                    .testTag("quiz_speak_feedback_button")
                            ) {
                                Icon(
                                    imageVector = Icons.Default.VolumeUp,
                                    contentDescription = "Erklärung vorlesen",
                                    tint = if (isCorrect) AssistiveGreen else AssistiveAmber,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                    }
                    Text(
                        text = explanationText,
                        fontSize = 16.sp,
                        fontWeight = FontWeight.Normal,
                        color = AssistiveTextPrimary,
                        lineHeight = 24.sp
                    )
                }
            }
        }

        Button(
            onClick = onNext,
            shape = RoundedCornerShape(16.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = if (isCorrect) AssistiveBlue else AssistiveAmber
            ),
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp)
                .padding(top = 16.dp)
                .testTag("quiz_feedback_next_button")
        ) {
            Text(
                text = if (isCorrect) "Weiter" else "Nochmal versuchen",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
        }
    }
}

@Composable
internal fun ChildSummaryView(
    summaryPoints: List<String>,
    onNext: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(modifier = Modifier.height(12.dp))

            Text(
                text = "Das hast du gelernt",
                fontSize = 26.sp,
                fontWeight = FontWeight.Bold,
                color = AssistiveTextPrimary
            )

            Spacer(modifier = Modifier.height(12.dp))

            ComicIllustrationCard(
                type = ComicType.FEEDBACK_SUCCESS,
                modifier = Modifier.padding(horizontal = 4.dp)
            )

            Spacer(modifier = Modifier.height(16.dp))

            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = AssistiveSurface),
                elevation = CardDefaults.cardElevation(defaultElevation = 2.dp),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(
                    modifier = Modifier.padding(18.dp)
                ) {
                    summaryPoints.forEach { point ->
                        Row(
                            modifier = Modifier
                                .fillMaxWidth()
                                .padding(vertical = 10.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(32.dp)
                                    .clip(CircleShape)
                                    .background(AssistiveGreenLight),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Check,
                                    contentDescription = "Gelernt",
                                    tint = AssistiveGreen,
                                    modifier = Modifier.size(20.dp)
                                )
                            }

                            Spacer(modifier = Modifier.width(14.dp))

                            Text(
                                text = point,
                                fontSize = 16.sp,
                                fontWeight = FontWeight.Medium,
                                color = AssistiveTextPrimary,
                                lineHeight = 22.sp,
                                modifier = Modifier.weight(1f)
                            )
                        }
                    }
                }
            }
        }

        Button(
            onClick = onNext,
            shape = RoundedCornerShape(16.dp),
            colors = ButtonDefaults.buttonColors(containerColor = AssistiveBlue),
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp)
                .padding(top = 16.dp)
                .testTag("child_summary_next_button")
        ) {
            Text(
                text = "Weiter",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
        }
    }
}

@Composable
internal fun HandoffToParentView(
    appName: String,
    onProceed: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState()),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = "Jetzt sind deine Eltern dran",
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                color = AssistiveTextPrimary,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(12.dp))

            ComicIllustrationCard(
                type = ComicType.PARENT_DISCUSSION,
                modifier = Modifier.padding(horizontal = 4.dp)
            )

            Spacer(modifier = Modifier.height(16.dp))

            Text(
                text = "Deine Eltern beantworten ein paar Fragen, um $appName für dich freizugeben. Sie erfahren dabei auch, worauf sie achten sollten.",
                fontSize = 16.sp,
                color = AssistiveTextSecondary,
                textAlign = TextAlign.Center,
                lineHeight = 24.sp,
                modifier = Modifier.padding(horizontal = 12.dp)
            )
        }

        Button(
            onClick = onProceed,
            shape = RoundedCornerShape(16.dp),
            colors = ButtonDefaults.buttonColors(containerColor = AssistiveBlue),
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp)
                .padding(top = 16.dp)
                .testTag("handoff_to_parent_button")
        ) {
            Text(
                text = "Weiter zu den Eltern",
                fontSize = 18.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
        }
    }
}
