package com.example.data.quiz

import com.example.model.quiz.QuizCategory
import com.example.model.quiz.QuizModule
import com.example.model.quiz.QuizOption
import com.example.model.quiz.QuizQuestion

internal val blockierenModule = QuizModule(
    category = QuizCategory.BLOCKIEREN,
    title = "Blockieren & Schutz",
    childIntroText = "Wenn dich jemand nervt oder ärgert, kannst du die Person blockieren.",
    childQuestions = listOf(
        QuizQuestion(
            id = "c_blk_1",
            title = "Unerwünschte Nachrichten",
            situation = "Jemand schreibt dir immer wieder Nachrichten, obwohl du das nicht möchtest. Was kannst du machen?",
            options = listOf(
                QuizOption("A", "Die Person ebenfalls beleidigen."),
                QuizOption("B", "Die Person blockieren und Hilfe holen."),
                QuizOption("C", "Deine Adresse schicken."),
                QuizOption("D", "Die Nachrichten an alle weiterleiten.")
            ),
            correctIndex = 1,
            explanation = "Du musst unerwünschte Nachrichten nicht aushalten. Blockieren und Hilfe holen sind mögliche Schritte."
        ),
        QuizQuestion(
            id = "c_blk_2",
            title = "Was bewirkt Blockieren?",
            situation = "Was passiert grundsätzlich, wenn du jemanden bei WhatsApp blockierst?",
            options = listOf(
                QuizOption("A", "Die Person bekommt automatisch dein Passwort."),
                QuizOption("B", "Die Person kann dir über WhatsApp nicht mehr normal schreiben oder dich dort anrufen."),
                QuizOption("C", "Dein Handy geht aus."),
                QuizOption("D", "Alle deine Fotos werden gelöscht.")
            ),
            correctIndex = 1,
            explanation = "Durch das Blockieren wird die direkte Kommunikation über WhatsApp eingeschränkt. Dein Handy oder deine Fotos werden dadurch nicht gelöscht."
        )
    ),
    childSummaryPoints = listOf(
        "Du musst keine gemeinen Nachrichten ertragen.",
        "Blockieren schützt dich vor Anrufen und Texten der Person.",
        "Immer mit einem Erwachsenen sprechen, wenn etwas unangenehm ist."
    ),
    parentIntroText = "Die Blockieren-Funktion ist ein wirksames Werkzeug für Kinder, um Grenzen im digitalen Raum zu setzen.",
    parentFocusTopics = listOf(
        "Blockieren als Schutzmechanismus",
        "Situation gemeinsam analysieren",
        "Keine Angst vor Konsequenzen machen"
    ),
    parentQuestions = listOf(
        QuizQuestion(
            id = "p_blk_1",
            title = "Unerwünschte Nachrichten begleiten",
            situation = "Ihr Kind bekommt wiederholt unerwünschte Nachrichten. Was können Sie vermitteln?",
            options = listOf(
                QuizOption("A", "Zurückbeleidigen."),
                QuizOption("B", "Die Person gegebenenfalls blockieren und gemeinsam überlegen, ob weitere Hilfe nötig ist."),
                QuizOption("C", "Die Nachrichten weiterleiten."),
                QuizOption("D", "Die eigene Adresse schicken.")
            ),
            correctIndex = 1,
            explanation = "Blockieren kann die direkte Kommunikation unterbrechen. Bei belastenden Situationen sollte gemeinsam über weitere Hilfe gesprochen werden."
        ),
        QuizQuestion(
            id = "p_blk_2",
            title = "Funktion erklären",
            situation = "Ihr Kind möchte eine Person blockieren, weil diese wiederholt unangenehme Nachrichten schickt. Wie reagieren Sie sinnvoll?",
            options = listOf(
                QuizOption("A", "Kinder dürfen niemals blockieren."),
                QuizOption("B", "Gemeinsam die Situation anschauen und erklären, wie die Funktion funktioniert."),
                QuizOption("C", "Die Nachrichten an alle Freunde schicken."),
                QuizOption("D", "Das Kind soll die Person zuerst provozieren.")
            ),
            correctIndex = 1,
            explanation = "Eltern können das Kind unterstützen, eine passende Grenze zu setzen und die Funktion bewusst zu nutzen."
        )
    ),
    parentTips = listOf(
        "Kind zeigen, wie Blockieren in verschiedenen Apps funktioniert.",
        "Signalisieren, dass das Kind bei Problemen nicht bestraft wird.",
        "Bei schwerwiegendem Cybermobbing Beweise sichern und Schule einbinden."
    )
)

internal val persoenlicheDatenModule = QuizModule(
    category = QuizCategory.PERSOENLICHE_DATEN,
    title = "Persönliche Daten",
    childIntroText = "Deine persönlichen Daten wie Adresse und Schule gehören nur dir.",
    childQuestions = listOf(
        QuizQuestion(
            id = "c_dat_1",
            title = "Schützenswerte Informationen",
            situation = "Welche Information solltest du einer unbekannten Person im Internet nicht einfach geben?",
            options = listOf(
                QuizOption("A", "Deine Lieblingsfarbe."),
                QuizOption("B", "Deine Adresse."),
                QuizOption("C", "Dein Lieblingsessen."),
                QuizOption("D", "Deinen Lieblingssport.")
            ),
            correctIndex = 1,
            explanation = "Deine Adresse gehört zu deinen persönlichen Informationen und sollte nicht einfach an fremde Personen gegeben werden."
        ),
        QuizQuestion(
            id = "c_dat_2",
            title = "Ausfrageversuch",
            situation = "Jemand schreibt dir: „Wie heißt du, wo wohnst du und auf welche Schule gehst du?“ Was machst du?",
            options = listOf(
                QuizOption("A", "Ich beantworte alles."),
                QuizOption("B", "Ich schicke ein Foto von meinem Ausweis."),
                QuizOption("C", "Ich gebe die Informationen nicht heraus und frage einen Erwachsenen."),
                QuizOption("D", "Ich schicke meine Adresse, aber nicht meinen Namen.")
            ),
            correctIndex = 2,
            explanation = "Wenn eine unbekannte Person viele persönliche Informationen möchte, gib sie nicht heraus und hole dir Unterstützung."
        )
    ),
    childSummaryPoints = listOf(
        "Adresse, Nachname und Schule sind geheim.",
        "Fremden im Netz niemals Fotos oder Standortdaten geben.",
        "Wenn jemand viele Fragen stellt: Sofort Mama oder Papa holen."
    ),
    parentIntroText = "Datenschutz fängt im Kindesalter an. Vermitteln Sie, warum private Daten im Netz geschützt werden müssen.",
    parentFocusTopics = listOf(
        "Wohnort und Schule schützen",
        "Vertrauensvolle Ansprechperson sein",
        "Sensibilisierung für Social Engineering"
    ),
    parentQuestions = listOf(
        QuizQuestion(
            id = "p_dat_1",
            title = "Besonders schützenswerte Daten",
            situation = "Welche Information sollten Eltern als besonders schützenswert erklären?",
            options = listOf(
                QuizOption("A", "Lieblingsfarbe."),
                QuizOption("B", "Wohnadresse."),
                QuizOption("C", "Lieblingsessen."),
                QuizOption("D", "Lieblingssport.")
            ),
            correctIndex = 1,
            explanation = "Eine Wohnadresse ist eine persönliche Information und sollte nicht einfach an unbekannte Personen weitergegeben werden."
        ),
        QuizQuestion(
            id = "p_dat_2",
            title = "Ausfrage-Situationen",
            situation = "Eine unbekannte Person fragt Ihr Kind nach Name, Schule und Wohnort. Was ist eine gute Regel?",
            options = listOf(
                QuizOption("A", "Alles angeben, wenn die Person freundlich ist."),
                QuizOption("B", "Keine persönlichen Angaben herausgeben und eine erwachsene Vertrauensperson einbeziehen."),
                QuizOption("C", "Nur den Wohnort nennen."),
                QuizOption("D", "Ein Foto des Ausweises schicken.")
            ),
            correctIndex = 1,
            explanation = "Unbekannte Personen müssen nicht wissen, wo ein Kind wohnt oder zur Schule geht."
        ),
        QuizQuestion(
            id = "p_dat_3",
            title = "Hilfreiche Haltung",
            situation = "Welche Haltung ist beim Datenschutz für Kinder besonders hilfreich?",
            options = listOf(
                QuizOption("A", "Kinder müssen alles allein wissen."),
                QuizOption("B", "Kinder sollen wissen, dass sie bei Unsicherheit jederzeit eine Vertrauensperson fragen können."),
                QuizOption("C", "Persönliche Daten sind im Internet egal."),
                QuizOption("D", "Datenschutz ist nur für Erwachsene wichtig.")
            ),
            correctIndex = 1,
            explanation = "Eine verlässliche Ansprechperson gibt Kindern Sicherheit, wenn sie eine Situation nicht einschätzen können."
        )
    ),
    parentTips = listOf(
        "Keine Klarnamen und Geburtsdaten in Profilen eintragen.",
        "Regelmäßig prüfen, welche Daten Apps abfragen.",
        "Echtes Vertrauen aufbauen, damit das Kind Unsicherheiten anspricht."
    )
)

internal val bevorVerschickenModule = QuizModule(
    category = QuizCategory.BEVOR_VERSCHICKEN,
    title = "Bevor ich etwas verschicke",
    childIntroText = "Bevor du auf 'Senden' tippst, denke kurz nach. Ein verschicktes Foto kann man nicht einfach zurückholen.",
    childQuestions = listOf(
        QuizQuestion(
            id = "c_snd_1",
            title = "Kurzer Check vor dem Senden",
            situation = "Du möchtest ein Foto verschicken. Was solltest du vorher machen?",
            options = listOf(
                QuizOption("A", "Sofort auf „Senden“ drücken."),
                QuizOption("B", "Prüfen, ob das richtige Foto ausgewählt ist und ob du es verschicken darfst."),
                QuizOption("C", "Das Foto zuerst an zehn Personen schicken."),
                QuizOption("D", "Das Handy weglegen und nichts mehr machen.")
            ),
            correctIndex = 1,
            explanation = "Schau vor dem Senden noch einmal genau hin: Ist es das richtige Foto und ist es in Ordnung, es an diese Person zu schicken?"
        ),
        QuizQuestion(
            id = "c_snd_2",
            title = "Lustiges Bild weiterleiten",
            situation = "Du bekommst ein lustiges Bild und möchtest es an deine Freunde weiterleiten. Was solltest du überlegen?",
            options = listOf(
                QuizOption("A", "Ist das Bild für andere vielleicht unangenehm oder privat?"),
                QuizOption("B", "Wie schnell kann ich es verschicken?"),
                QuizOption("C", "Wie viele Menschen kann ich damit erreichen?"),
                QuizOption("D", "Ob ich noch mehr Bilder finde.")
            ),
            correctIndex = 0,
            explanation = "Vor dem Weiterleiten solltest du überlegen, ob das Bild privat, unangenehm oder verletzend sein könnte."
        )
    ),
    childSummaryPoints = listOf(
        "Einmal verschickt, ist ein Bild im Netz kaum wieder löschbar.",
        "Kurz überlegen: Ist das Bild für andere peinlich oder verletzend?",
        "Bei Unsicherheit lieber einmal mehr die Eltern fragen."
    ),
    parentIntroText = "Die 'Denk-Pause' vor dem Absenden ist eine der wichtigsten Schutzgewohnheiten in der Mediennutzung.",
    parentFocusTopics = listOf(
        "Impulsives Senden vermeiden",
        "Empathie für den Empfänger stärken",
        "Unterstützung bei der Bildauswahl"
    ),
    parentQuestions = listOf(
        QuizQuestion(
            id = "p_snd_1",
            title = "Check vor dem Senden",
            situation = "Ihr Kind möchte ein Foto verschicken. Welche Regel ist sinnvoll?",
            options = listOf(
                QuizOption("A", "Möglichst schnell auf Senden drücken."),
                QuizOption("B", "Prüfen, ob es das richtige Foto ist und ob es an diese Person geschickt werden darf."),
                QuizOption("C", "Das Foto zuerst an viele Personen schicken."),
                QuizOption("D", "Fotos grundsätzlich öffentlich teilen.")
            ),
            correctIndex = 1,
            explanation = "Ein kurzer Check vor dem Senden kann verhindern, dass ein falsches oder ungeeignetes Bild weitergegeben wird."
        ),
        QuizQuestion(
            id = "p_snd_2",
            title = "Empathie bei Humor",
            situation = "Ihr Kind möchte ein lustiges Bild weiterleiten. Was sollten Sie fördern?",
            options = listOf(
                QuizOption("A", "Möglichst viele Menschen erreichen."),
                QuizOption("B", "Prüfen, ob das Bild privat, unangenehm oder verletzend sein könnte."),
                QuizOption("C", "Bilder immer weiterleiten, wenn sie lustig sind."),
                QuizOption("D", "Nur die Dateigröße prüfen.")
            ),
            correctIndex = 1,
            explanation = "Humor ist nicht für alle gleich. Vor dem Weiterleiten sollte geprüft werden, ob andere dadurch verletzt oder bloßgestellt werden."
        ),
        QuizQuestion(
            id = "p_snd_3",
            title = "Gemeinsam entscheiden",
            situation = "Ihr Kind fragt: „Darf ich dieses Foto schicken?“ Was ist eine gute Elternreaktion?",
            options = listOf(
                QuizOption("A", "Immer sofort Ja sagen."),
                QuizOption("B", "Gemeinsam anschauen, an wen es gehen soll, wer darauf zu sehen ist und welche Informationen das Bild enthält."),
                QuizOption("C", "Immer Nein sagen."),
                QuizOption("D", "Nur prüfen, ob das Foto scharf ist.")
            ),
            correctIndex = 1,
            explanation = "Gemeinsames Prüfen stärkt die Medienkompetenz und hilft dem Kind, eigene Entscheidungen zunehmend selbst zu treffen."
        )
    ),
    parentTips = listOf(
        "Gemeinsam ein Stopp-Signal vor dem Absenden üben.",
        "Echtes Interesse an den Lieblings-Memes des Kindes zeigen.",
        "Offen über die Gefühle anderer sprechen."
    )
)

internal val internetSurfenModule = QuizModule(
    category = QuizCategory.INTERNET_SURFEN,
    title = "Sicheres Surfen & Internet",
    childIntroText = "Im Internet gibt es tolle Seiten zum Lernen, Spielen und Entdecken. Hier lernst du wichtige Regeln für sicheres Surfen.",
    childQuestions = listOf(
        QuizQuestion(
            id = "c_surf_1",
            title = "Unheimliche oder gruselige Inhalte",
            situation = "Du tippst auf eine Seite und plötzlich siehst du ein Bild oder Video, das dir Angst macht oder eklig ist. Was machst du?",
            options = listOf(
                QuizOption("A", "Du drückst auf Weiter und schaust es dir ganz genau an."),
                QuizOption("B", "Du schließt sofort den Browser oder legst das Handy hin und sagst deinen Eltern Bescheid."),
                QuizOption("C", "Du schickst den Link an deine Schulfreunde."),
                QuizOption("D", "Du versteckst dein Handy unter dem Kissen und sagst niemandem etwas.")
            ),
            correctIndex = 1,
            explanation = "Wenn dir etwas im Internet Angst macht oder unangenehm ist: Sofort wegklicken und deinen Eltern Bescheid sagen. Du bekommst dafür niemals Ärger!"
        ),
        QuizQuestion(
            id = "c_surf_2",
            title = "Geheimnisse & persönliche Daten",
            situation = "Auf einer Webseite steht: 'Gib deinen Namen, deine Telefonnummer und deine Adresse ein, um tolle Sticker zu gewinnen!' Was tust du?",
            options = listOf(
                QuizOption("A", "Du tippst sofort deine echte Adresse und Telefonnummer ein."),
                QuizOption("B", "Du gibst die Adresse von deinem Nachbarn ein."),
                QuizOption("C", "Du fragst zuerst deine Eltern, bevor du irgendwo deinen Namen oder deine Adresse eingibst."),
                QuizOption("D", "Du tippst das Passwort deiner Eltern ein.")
            ),
            correctIndex = 2,
            explanation = "Niemals deinen echten Namen, deine Adresse oder Telefonnummer im Internet eingeben, ohne dass deine Eltern es ausdrücklich erlauben."
        ),
        QuizQuestion(
            id = "c_surf_3",
            title = "Werbung & Gewinnspiele",
            situation = "Plötzlich blinkt ein großes rotes Fenster: 'Herzlichen Glückwunsch! Du hast ein neues Smartphone gewonnen! Klicke hier!' Was bedeutet das?",
            options = listOf(
                QuizOption("A", "Das ist eine Werbefalle – am besten das Fenster schließen und nicht draufklicken."),
                QuizOption("B", "Ein echtes Geschenk, du musst so schnell wie möglich draufklicken."),
                QuizOption("C", "Eine wichtige Nachricht von deiner Schule."),
                QuizOption("D", "Das Handy schenkt dir etwas Schönes.")
            ),
            correctIndex = 0,
            explanation = "Im Internet verschenkt niemand einfach so teure Geräte. Solche bunten, blinkenden Pop-ups sind fast immer Werbung oder Abofallen."
        ),
        QuizQuestion(
            id = "c_surf_4",
            title = "Nachrichten von Fremden",
            situation = "In einem Online-Spiel oder auf einer Kinderseite schreibt dir jemand: 'Wie heißt du wirklich und wo wohnst du? Wollen wir uns treffen?' Wie reagierst du?",
            options = listOf(
                QuizOption("A", "Du sagst deinen Wohnort und verabredest dich heimlich."),
                QuizOption("B", "Du antwortest gar nicht, verrätst nichts über dich und zeigst die Nachricht sofort deinen Eltern."),
                QuizOption("C", "Du schickst ein Foto von deinem Kinderzimmer."),
                QuizOption("D", "Du lädst die Person zu dir nach Hause ein.")
            ),
            correctIndex = 1,
            explanation = "Im Internet weiß man nie, wer wirklich am anderen Ende sitzt. Verrate niemals private Infos und sag immer sofort deinen Eltern Bescheid."
        )
    ),
    childSummaryPoints = listOf(
        "Bei komischen oder gruseligen Inhalten: Browser schließen und direkt den Eltern Bescheid sagen.",
        "Echte Namen, Adressen und Telefonnummern bleiben privat und geheim.",
        "Blinkende Gewinnspiele ('Du hast gewonnen!') sind Werbung und niemals anzuklicken.",
        "Niemals mit fremden Personen im Internet verabreden oder private Geheimnisse teilen."
    ),
    parentIntroText = "Das Internet bietet enorme Chancen, erfordert aber bei Kindern klare Schutzräume, Vereinbarungen und eine vertrauensvolle Begleitung.",
    parentFocusTopics = listOf(
        "Geschützte Einstiegsräume (Walled Garden) nutzen",
        "Vertrauensvolle Fehlerkultur etablieren",
        "Feste Surf-Zeiten und klare Absprachen",
        "Quellenkritik und Werbekompetenz fördern"
    ),
    parentQuestions = listOf(
        QuizQuestion(
            id = "p_surf_1",
            title = "Sicherer Einstieg & Walled Garden",
            situation = "Ihr Kind unternimmt die ersten Schritte im Internet. Was ist medienpädagogisch die empfehlenswerteste Methode?",
            options = listOf(
                QuizOption("A", "Ein geschützter Raum ('Walled Garden') mit vorab freigegebenen Kinderseiten und Whitelisting."),
                QuizOption("B", "Dem Kind direkt unbeschränkten Zugriff auf globale Suchmaschinen und soziale Netzwerke geben."),
                QuizOption("C", "Das Internet bis zum 18. Lebensjahr komplett verbieten."),
                QuizOption("D", "Das Kind ohne vorherige Absprachen allein im offenen Netz surfen lassen.")
            ),
            correctIndex = 0,
            explanation = "Medienexperten (klicksafe, Schau Hin!) empfehlen für Grundschulkinder geprüfte Whitelists und kindgerechte Portale, um Reizüberflutung und ungeeignete Inhalte zu vermeiden."
        ),
        QuizQuestion(
            id = "p_surf_2",
            title = "Reaktion bei verstörenden Inhalten",
            situation = "Ihr Kind kommt zu Ihnen und erzählt aufgelöst, dass es beim Surfen ein unheimliches oder verstörendes Bild gesehen hat. Wie reagieren Sie am besten?",
            options = listOf(
                QuizOption("A", "Mit Schimpfen und sofortigem Handy-Entzug, damit das Kind lernt, vorsichtiger zu sein."),
                QuizOption("B", "Ruhig bleiben, das Kind dafür loben, dass es Vertrauen hat und Bescheid gesagt hat, und gemeinsam darüber sprechen."),
                QuizOption("C", "Das Thema ignorieren und so tun, als wäre nichts passiert."),
                QuizOption("D", "Das Gerät sofort wegsperren und dem Kind Vorwürfe machen.")
            ),
            correctIndex = 1,
            explanation = "Bestrafung führt dazu, dass Kinder künftige Vorfälle verheimlichen. Lob für das Anvertrauen stärkt das Vertrauensverhältnis nachhaltig."
        ),
        QuizQuestion(
            id = "p_surf_3",
            title = "Feste Zeitfenster & Absprachen",
            situation = "Wie unterstützen Sie Ihr Kind dabei, beim Surfen nicht das Zeitgefühl zu verlieren?",
            options = listOf(
                QuizOption("A", "Das Kind unbegrenzt surfen lassen, bis der Akku leer ist."),
                QuizOption("B", "Vorab feste, überschaubare Zeiten (z. B. 20–30 Minuten) und ein konkretes Ziel vereinbaren und einen Wecker nutzen."),
                QuizOption("C", "Jede Minute des Surfens per Videoüberwachung filmen."),
                QuizOption("D", "Nur nachts surfen erlauben.")
            ),
            correctIndex = 1,
            explanation = "Klare, vorab vereinbarte Zeitbudgets mit akustischem Signal (z. B. Wecker) helfen Kindern, ein eigenes Zeitgefühl zu entwickeln, ohne ständigen Streit."
        ),
        QuizQuestion(
            id = "p_surf_4",
            title = "Kritisches Hinterfragen von Inhalten",
            situation = "Ihr Kind stößt auf eine Webseite mit reißerischer Überschrift. Welche Kompetenz sollten Sie fördern?",
            options = listOf(
                QuizOption("A", "Alles bedingungslos glauben, was im Internet steht."),
                QuizOption("B", "Gemeinsam hinterfragen: Wer hat das geschrieben? Will die Seite etwas verkaufen oder informieren?"),
                QuizOption("C", "Sofort alle Texte ausdrucken."),
                QuizOption("D", "Webseiten nur nach den buntesten Farben bewerten.")
            ),
            correctIndex = 1,
            explanation = "Quellenkritik ist eine Kernkompetenz: Kinder lernen am besten im Dialog, Inhalte und Werbung kritisch zu hinterfragen."
        )
    ),
    parentTips = listOf(
        "Gemeinsam surfen: Begleiten Sie Ihr Kind besonders anfangs aktiv bei Entdeckungsreisen im Web.",
        "Fehlerkultur etablieren: Betonen Sie regelmäßig, dass Ihr Kind nie Ärger bekommt, wenn es auf eine unangenehme Seite stößt und Bescheid sagt.",
        "Kindersuchmaschinen nutzen: Zeigen Sie Seiten wie fragfinn.de, blindekuh.de oder die KiKa-Mediathek."
    )
)
