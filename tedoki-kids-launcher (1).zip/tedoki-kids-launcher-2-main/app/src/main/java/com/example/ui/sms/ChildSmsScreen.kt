package com.example.ui.sms

import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.foundation.layout.windowInsetsPadding
import com.example.ui.components.launcherSafe
import android.Manifest
import android.content.pm.PackageManager
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.material.icons.automirrored.filled.Send
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Message
import androidx.compose.material3.Button
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.rememberCoroutineScope
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.core.content.ContextCompat
import com.example.model.LauncherSettings
import com.example.sms.SmsRepository
import com.example.ui.theme.AssistiveBackground
import kotlinx.coroutines.launch

data class SmsContactTarget(
    val title: String,
    val phoneNumber: String,
    val photoUri: String? = null,
    val colorHex: Long = 0xFF2563EB
)

/**
 * Child-friendly SMS screen with two clear steps:
 * 1. Contact selection window ("vorhandenen Kontakt auswählen")
 * 2. Chat / Compose & Send window ("nächste Fenster zum schreiben und absenden Button")
 */
@Composable
fun ChildSmsScreen(
    settings: LauncherSettings,
    onBack: () -> Unit
) {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()

    // Initialize SMS repository
    LaunchedEffect(Unit) {
        SmsRepository.init(context)
    }

    val allMessages by SmsRepository.messagesFlow.collectAsState()
    var selectedContact by remember { mutableStateOf<SmsContactTarget?>(null) }
    var isDefaultSmsApp by remember { mutableStateOf(SmsRepository.isDefaultSmsApp(context)) }

    // Role launcher for default SMS role
    val roleLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.StartActivityForResult()
    ) {
        isDefaultSmsApp = SmsRepository.isDefaultSmsApp(context)
    }

    // Permission launcher for SMS permissions
    val smsPermissionsLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.RequestMultiplePermissions()
    ) { _ -> }

    LaunchedEffect(Unit) {
        val hasSend = ContextCompat.checkSelfPermission(context, Manifest.permission.SEND_SMS) == PackageManager.PERMISSION_GRANTED
        val hasReceive = ContextCompat.checkSelfPermission(context, Manifest.permission.RECEIVE_SMS) == PackageManager.PERMISSION_GRANTED
        val hasRead = ContextCompat.checkSelfPermission(context, Manifest.permission.READ_SMS) == PackageManager.PERMISSION_GRANTED

        if (!hasSend || !hasReceive || !hasRead) {
            smsPermissionsLauncher.launch(
                arrayOf(
                    Manifest.permission.SEND_SMS,
                    Manifest.permission.RECEIVE_SMS,
                    Manifest.permission.READ_SMS
                )
            )
        }
    }

    BackHandler {
        if (selectedContact != null) {
            selectedContact = null
        } else {
            onBack()
        }
    }

    // Available contacts from settings + any contact in message history
    val availableContacts = remember(settings.contacts, allMessages) {
        val list = mutableListOf<SmsContactTarget>()
        val seenNumbers = mutableSetOf<String>()

        // 1. Load from parent-configured contacts list
        settings.contacts.forEach { contact ->
            val clean = contact.phoneNumber.trim()
            if (!seenNumbers.contains(clean)) {
                seenNumbers.add(clean)
                list.add(
                    SmsContactTarget(
                        title = contact.name,
                        phoneNumber = clean,
                        photoUri = contact.photoUri,
                        colorHex = contact.colorHex
                    )
                )
            }
        }

        // 2. Add sample/emergency numbers if empty
        if (list.isEmpty()) {
            list.add(
                SmsContactTarget(
                    title = "Mama",
                    phoneNumber = "555-0101",
                    colorHex = 0xFF059669
                )
            )
            list.add(
                SmsContactTarget(
                    title = "Papa",
                    phoneNumber = "555-0102",
                    colorHex = 0xFF2563EB
                )
            )
        }

        // 3. Any other phone number in message history
        allMessages.forEach { msg ->
            val clean = msg.phoneNumber.trim()
            if (clean.isNotBlank() && list.none { SmsRepository.isSamePhoneNumber(it.phoneNumber, clean) }) {
                list.add(
                    SmsContactTarget(
                        title = msg.senderName ?: clean,
                        phoneNumber = clean,
                        colorHex = 0xFF7C3AED
                    )
                )
            }
        }

        list
    }

    val parentConfiguredNumbers = remember(settings.contacts) {
        settings.contacts.map { it.phoneNumber.trim() }.toSet()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(AssistiveBackground)
            .windowInsetsPadding(WindowInsets.launcherSafe)
    ) {
        Column(
            modifier = Modifier.fillMaxSize()
        ) {
            if (selectedContact == null) {
                // STEP 1: Select Contact Screen
                SmsContactSelectionView(
                    contacts = availableContacts,
                    allMessages = allMessages,
                    parentConfiguredNumbers = parentConfiguredNumbers,
                    onSelectContact = { contact -> selectedContact = contact },
                    onBack = onBack
                )
            } else {
                // STEP 2: Chat & Send Message Screen
                SmsChatView(
                    contact = selectedContact!!,
                    allMessages = allMessages,
                    onSendMessage = { body ->
                        SmsRepository.sendMessage(
                            context = context,
                            phoneNumber = selectedContact!!.phoneNumber,
                            body = body,
                            senderName = selectedContact!!.title
                        )
                    },
                    onBackToContacts = { selectedContact = null }
                )
            }
        }
    }
}
