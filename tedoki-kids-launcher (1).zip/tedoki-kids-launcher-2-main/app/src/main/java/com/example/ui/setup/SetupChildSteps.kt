package com.example.ui.setup

import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyRow
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Upload
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.ui.theme.AssistiveBlue
import com.example.ui.theme.AssistiveBlueLight
import com.example.ui.theme.AssistiveBorder
import com.example.ui.theme.AssistiveGreen
import com.example.ui.theme.AssistiveSurface
import com.example.ui.theme.AssistiveTextMuted
import com.example.ui.theme.AssistiveTextPrimary
import com.example.ui.theme.AssistiveTextSecondary
import com.example.ui.theme.assistiveTextFieldColors

// =====================================================================================
// STEP 3: CHILD INFO (Name & Age Free Input)
// =====================================================================================
@Composable
internal fun ChildInfoStep(
    isEn: Boolean,
    childName: String,
    onNameChange: (String) -> Unit,
    childAgeText: String,
    onAgeChange: (String) -> Unit,
    onNext: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 24.dp, vertical = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.fillMaxWidth()
        ) {
            Spacer(modifier = Modifier.height(12.dp))

            Box(
                modifier = Modifier
                    .size(80.dp)
                    .clip(CircleShape)
                    .background(AssistiveBlueLight),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Person,
                    contentDescription = null,
                    tint = AssistiveBlue,
                    modifier = Modifier.size(44.dp)
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            Text(
                text = if (isEn) "Who will use this smartphone?" else "Wer benutzt dieses Smartphone?",
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                color = AssistiveTextPrimary,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = if (isEn)
                    "These details help us customize the home screen and pedagogical quizzes."
                else
                    "Mit diesen Angaben gestalten wir die Oberfläche und Quizze passend.",
                fontSize = 14.sp,
                color = AssistiveTextSecondary,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(24.dp))

            // Child Name Field
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = AssistiveSurface),
                border = BorderStroke(1.dp, AssistiveBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text(
                        text = if (isEn) "Child's name or nickname" else "Name oder Spitzname des Kindes",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = AssistiveTextPrimary
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = childName,
                        onValueChange = onNameChange,
                        placeholder = { Text(if (isEn) "e.g. Ben, Emma, Leo…" else "z. B. Ben, Emma, Leo…") },
                        singleLine = true,
                        colors = assistiveTextFieldColors(),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("child_name_input"),
                        trailingIcon = {
                            if (childName.isNotBlank()) {
                                IconButton(onClick = { onNameChange("") }) {
                                    Icon(Icons.Default.Close, contentDescription = if (isEn) "Clear" else "Löschen")
                                }
                            }
                        }
                    )
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            // Child Age Free Input Field
            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = AssistiveSurface),
                border = BorderStroke(1.dp, AssistiveBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text(
                        text = if (isEn) "How old is your child? (Free input)" else "Wie alt ist dein Kind? (Freiangabe)",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = AssistiveTextPrimary
                    )
                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = childAgeText,
                        onValueChange = {
                            if (it.length <= 15) {
                                onAgeChange(it)
                            }
                        },
                        placeholder = { Text(if (isEn) "Enter age (e.g. 7 or 8 years)" else "Alter eingeben (z. B. 7 oder 8 Jahre)") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Number),
                        colors = assistiveTextFieldColors(),
                        shape = RoundedCornerShape(14.dp),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("child_age_input"),
                        trailingIcon = {
                            if (childAgeText.isNotBlank()) {
                                IconButton(onClick = { onAgeChange("") }) {
                                    Icon(Icons.Default.Close, contentDescription = if (isEn) "Clear" else "Löschen")
                                }
                            }
                        }
                    )

                    Spacer(modifier = Modifier.height(6.dp))

                    Text(
                        text = if (isEn) "Free age input, e.g. as a number." else "Freie Angabe des Alters, z. B. als Zahl.",
                        fontSize = 12.sp,
                        color = AssistiveTextMuted
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        val isNameValid = childName.trim().isNotBlank()
        Button(
            onClick = onNext,
            enabled = isNameValid,
            shape = RoundedCornerShape(16.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = AssistiveBlue,
                disabledContainerColor = AssistiveBorder
            ),
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp)
                .testTag("child_info_next_button")
        ) {
            Text(
                text = if (isNameValid) {
                    if (isEn) "Next: Choose Avatar" else "Weiter: Avatar wählen"
                } else {
                    if (isEn) "Please enter a name" else "Bitte Namen eingeben"
                },
                fontSize = 17.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
        }
    }
}

// =====================================================================================
// STEP 4: AVATAR PICKER
// =====================================================================================
@Composable
internal fun AvatarPickerStep(
    isEn: Boolean,
    childName: String,
    selectedAvatarId: String,
    customPhotoUri: String?,
    onSelectPreset: (ChildAvatarPreset) -> Unit,
    onPickCustomPhoto: () -> Unit,
    onNext: () -> Unit
) {
    val selectedPreset = PRESET_AVATARS.find { it.id == selectedAvatarId }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 24.dp, vertical = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.fillMaxWidth()
        ) {
            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = if (isEn) "Choose an avatar for $childName" else "Wähle einen Avatar für $childName",
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                color = AssistiveTextPrimary,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = if (isEn)
                    "Scroll through the animal avatars or upload your own photo."
                else
                    "Scrolle durch die Tiere oder lade ein eigenes Bild hoch.",
                fontSize = 14.sp,
                color = AssistiveTextSecondary,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(20.dp))

            // Large selected avatar preview card
            Box(
                modifier = Modifier
                    .size(120.dp)
                    .clip(CircleShape)
                    .background(
                        if (customPhotoUri != null) Color.Transparent
                        else Color(selectedPreset?.bgHex ?: 0xFF3B82F6)
                    )
                    .border(4.dp, AssistiveBlue, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                if (customPhotoUri != null) {
                    AsyncImage(
                        model = customPhotoUri,
                        contentDescription = "Avatar",
                        contentScale = ContentScale.Crop,
                        modifier = Modifier
                            .fillMaxSize()
                            .clip(CircleShape)
                    )
                } else {
                    Text(
                        text = selectedPreset?.emoji ?: "🦁",
                        fontSize = 64.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = if (customPhotoUri != null) {
                    if (isEn) "Custom photo for $childName" else "Eigenes Foto von $childName"
                } else (selectedPreset?.name ?: "Avatar"),
                fontSize = 17.sp,
                fontWeight = FontWeight.Bold,
                color = AssistiveTextPrimary
            )

            Spacer(modifier = Modifier.height(20.dp))

            Text(
                text = if (isEn) "Preset Avatars (scroll left to right):" else "Vorgefertigte Avatare (von links nach rechts scrollen):",
                fontSize = 13.sp,
                fontWeight = FontWeight.Bold,
                color = AssistiveTextMuted,
                modifier = Modifier.fillMaxWidth()
            )

            Spacer(modifier = Modifier.height(8.dp))

            // Horizontal scrolling preset avatars
            LazyRow(
                modifier = Modifier
                    .fillMaxWidth()
                    .testTag("avatar_presets_row"),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                contentPadding = PaddingValues(horizontal = 4.dp, vertical = 6.dp)
            ) {
                items(PRESET_AVATARS, key = { it.id }) { preset ->
                    val isSelected = selectedAvatarId == preset.id && customPhotoUri == null
                    Column(
                        horizontalAlignment = Alignment.CenterHorizontally,
                        modifier = Modifier
                            .clip(RoundedCornerShape(16.dp))
                            .clickable { onSelectPreset(preset) }
                            .padding(4.dp)
                            .testTag("avatar_chip_${preset.id}")
                    ) {
                        Box(
                            modifier = Modifier
                                .size(72.dp)
                                .clip(CircleShape)
                                .background(Color(preset.bgHex))
                                .border(
                                    width = if (isSelected) 3.5.dp else 1.dp,
                                    color = if (isSelected) AssistiveBlue else Color.Transparent,
                                    shape = CircleShape
                                ),
                            contentAlignment = Alignment.Center
                        ) {
                            Text(text = preset.emoji, fontSize = 38.sp)
                        }
                        Spacer(modifier = Modifier.height(6.dp))
                        Text(
                            text = preset.name,
                            fontSize = 12.sp,
                            fontWeight = if (isSelected) FontWeight.Bold else FontWeight.Medium,
                            color = if (isSelected) AssistiveBlue else AssistiveTextPrimary
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            // Or upload own photo button
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = AssistiveSurface),
                border = BorderStroke(1.5.dp, if (customPhotoUri != null) AssistiveBlue else AssistiveBorder),
                modifier = Modifier
                    .fillMaxWidth()
                    .clip(RoundedCornerShape(16.dp))
                    .clickable { onPickCustomPhoto() }
                    .testTag("upload_custom_avatar_button")
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(AssistiveBlueLight),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Upload,
                            contentDescription = if (isEn) "Upload photo" else "Foto hochladen",
                            tint = AssistiveBlue,
                            modifier = Modifier.size(24.dp)
                        )
                    }

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = if (isEn) "Upload custom photo" else "Eigenes Foto hochladen",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = AssistiveTextPrimary
                        )
                        Text(
                            text = if (customPhotoUri != null) {
                                if (isEn) "Photo selected ✓" else "Foto ausgewählt ✓"
                            } else {
                                if (isEn) "Choose an image from your device gallery" else "Ein Bild aus der Galerie deines Smartphones auswählen"
                            },
                            fontSize = 12.sp,
                            color = if (customPhotoUri != null) AssistiveGreen else AssistiveTextSecondary
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        Button(
            onClick = onNext,
            shape = RoundedCornerShape(16.dp),
            colors = ButtonDefaults.buttonColors(containerColor = AssistiveBlue),
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp)
                .testTag("avatar_next_button")
        ) {
            Text(
                text = if (isEn) "Next: Select Features" else "Weiter: Funktionen wählen",
                fontSize = 17.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
        }
    }
}
