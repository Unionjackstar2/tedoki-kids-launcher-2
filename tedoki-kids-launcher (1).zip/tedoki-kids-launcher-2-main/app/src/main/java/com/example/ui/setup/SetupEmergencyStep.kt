package com.example.ui.setup

import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Security
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Surface
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.AssistiveBackground
import com.example.ui.theme.AssistiveBlue
import com.example.ui.theme.AssistiveBorder
import com.example.ui.theme.AssistiveGreen
import com.example.ui.theme.AssistiveRed
import com.example.ui.theme.AssistiveRedLight
import com.example.ui.theme.AssistiveSurface
import com.example.ui.theme.AssistiveTextMuted
import com.example.ui.theme.AssistiveTextPrimary
import com.example.ui.theme.AssistiveTextSecondary
import com.example.ui.theme.assistiveTextFieldColors

// =====================================================================================
// STEP 7: EMERGENCY SETUP (SOS)
// =====================================================================================
@Composable
internal fun EmergencySetupStep(
    isEn: Boolean,
    sosEnabled: Boolean,
    onToggleSos: (Boolean) -> Unit,
    emergencyName: String,
    onNameChange: (String) -> Unit,
    emergencyNumber: String,
    onNumberChange: (String) -> Unit,
    sendSms: Boolean,
    onToggleSms: (Boolean) -> Unit,
    onNext: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 24.dp, vertical = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.fillMaxWidth()
        ) {
            Spacer(modifier = Modifier.height(10.dp))

            Box(
                modifier = Modifier
                    .size(80.dp)
                    .clip(CircleShape)
                    .background(AssistiveRedLight),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Security,
                    contentDescription = null,
                    tint = AssistiveRed,
                    modifier = Modifier.size(44.dp)
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            Text(
                text = if (isEn) "SOS Emergency Feature" else "SOS-Notfallfunktion",
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                color = AssistiveTextPrimary,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = if (isEn) "Quick help for your child in critical situations." else "Schnelle Hilfe für dein Kind im Ernstfall.",
                fontSize = 14.sp,
                color = AssistiveTextSecondary,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(18.dp))

            // Explanation Card
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = AssistiveSurface),
                border = BorderStroke(1.dp, AssistiveBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Text(text = "🚨", fontSize = 24.sp)
                        Text(
                            text = if (isEn) "How does the SOS button work?" else "Wie funktioniert der SOS-Knopf?",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = AssistiveTextPrimary
                        )
                    }
                    Spacer(modifier = Modifier.height(8.dp))
                    Text(
                        text = if (isEn)
                            "A red SOS button is located at the bottom of the home screen. Pressing and holding it for 3 seconds immediately calls the configured emergency number or contact."
                        else
                            "Unten auf dem Homescreen befindet sich ein roter SOS-Knopf. Wird dieser für 3 Sekunden gedrückt gehalten, ruft das Smartphone sofort den hinterlegten Kontakt oder Notruf an.",
                        fontSize = 13.sp,
                        color = AssistiveTextSecondary,
                        lineHeight = 18.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(14.dp))

            // Toggle SOS on/off
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = AssistiveSurface),
                border = BorderStroke(1.dp, if (sosEnabled) AssistiveRed else AssistiveBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(16.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = if (isEn) "Enable SOS Emergency Button" else "SOS-Notrufknopf aktivieren",
                            fontSize = 15.sp,
                            fontWeight = FontWeight.Bold,
                            color = AssistiveTextPrimary
                        )
                        Text(
                            text = if (sosEnabled) {
                                if (isEn) "Active on home screen" else "Aktiv auf dem Homescreen"
                            } else {
                                if (isEn) "Disabled" else "Deaktiviert"
                            },
                            fontSize = 12.sp,
                            color = if (sosEnabled) AssistiveRed else AssistiveTextMuted
                        )
                    }

                    Switch(
                        checked = sosEnabled,
                        onCheckedChange = onToggleSos,
                        colors = SwitchDefaults.colors(
                            checkedThumbColor = Color.White,
                            checkedTrackColor = AssistiveRed
                        )
                    )
                }
            }

            AnimatedVisibility(visible = sosEnabled) {
                Column(modifier = Modifier.fillMaxWidth()) {
                    Spacer(modifier = Modifier.height(14.dp))

                    Card(
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = AssistiveSurface),
                        border = BorderStroke(1.dp, AssistiveBorder),
                        modifier = Modifier.fillMaxWidth()
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text(
                                text = if (isEn) "Contact Name" else "Name des Kontakts",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = AssistiveTextPrimary
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            OutlinedTextField(
                                value = emergencyName,
                                onValueChange = onNameChange,
                                placeholder = { Text(if (isEn) "e.g. Mom, Dad or Emergency" else "z.B. Mama, Papa oder Notruf 112") },
                                singleLine = true,
                                shape = RoundedCornerShape(12.dp),
                                colors = assistiveTextFieldColors(),
                                modifier = Modifier.fillMaxWidth()
                            )

                            Spacer(modifier = Modifier.height(14.dp))

                            Text(
                                text = if (isEn) "Emergency Number" else "Notrufnummer",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = AssistiveTextPrimary
                            )
                            Spacer(modifier = Modifier.height(6.dp))
                            OutlinedTextField(
                                value = emergencyNumber,
                                onValueChange = onNumberChange,
                                placeholder = { Text(if (isEn) "112, 911 or mobile number" else "112 oder Handynummer") },
                                singleLine = true,
                                keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                                shape = RoundedCornerShape(12.dp),
                                colors = assistiveTextFieldColors(),
                                modifier = Modifier.fillMaxWidth()
                            )

                            Spacer(modifier = Modifier.height(8.dp))

                            // Quick chips
                            Row(
                                modifier = Modifier.fillMaxWidth(),
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Surface(
                                    shape = RoundedCornerShape(10.dp),
                                    color = if (emergencyNumber == "112") AssistiveRedLight else AssistiveBackground,
                                    border = BorderStroke(1.dp, if (emergencyNumber == "112") AssistiveRed else AssistiveBorder),
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(10.dp))
                                        .clickable { onNumberChange("112") }
                                ) {
                                    Text(
                                        text = "112 (EU)",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (emergencyNumber == "112") AssistiveRed else AssistiveTextPrimary,
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                                    )
                                }

                                Surface(
                                    shape = RoundedCornerShape(10.dp),
                                    color = if (emergencyNumber == "911") AssistiveRedLight else AssistiveBackground,
                                    border = BorderStroke(1.dp, if (emergencyNumber == "911") AssistiveRed else AssistiveBorder),
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(10.dp))
                                        .clickable { onNumberChange("911") }
                                ) {
                                    Text(
                                        text = "911 (US)",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (emergencyNumber == "911") AssistiveRed else AssistiveTextPrimary,
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                                    )
                                }

                                Surface(
                                    shape = RoundedCornerShape(10.dp),
                                    color = if (emergencyNumber == "110") AssistiveRedLight else AssistiveBackground,
                                    border = BorderStroke(1.dp, if (emergencyNumber == "110") AssistiveRed else AssistiveBorder),
                                    modifier = Modifier
                                        .clip(RoundedCornerShape(10.dp))
                                        .clickable { onNumberChange("110") }
                                ) {
                                    Text(
                                        text = if (isEn) "110 (Police)" else "110 (Polizei)",
                                        fontSize = 12.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = if (emergencyNumber == "110") AssistiveRed else AssistiveTextPrimary,
                                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 6.dp)
                                    )
                                }
                            }

                            Spacer(modifier = Modifier.height(14.dp))

                            // SMS location toggle
                            Row(
                                modifier = Modifier
                                    .fillMaxWidth()
                                    .clip(RoundedCornerShape(12.dp))
                                    .clickable { onToggleSms(!sendSms) }
                                    .padding(vertical = 4.dp),
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.SpaceBetween
                            ) {
                                Column(modifier = Modifier.weight(1f)) {
                                    Text(
                                        text = if (isEn) "Send GPS Location via SMS" else "Standort per SMS senden",
                                        fontSize = 14.sp,
                                        fontWeight = FontWeight.Bold,
                                        color = AssistiveTextPrimary
                                    )
                                    Text(
                                        text = if (isEn)
                                            "Automatically sends a map link with the current GPS coordinates"
                                        else
                                            "Sendet automatisch einen Karten-Link mit aktuellem GPS-Standort",
                                        fontSize = 12.sp,
                                        color = AssistiveTextSecondary
                                    )
                                }
                                Switch(
                                    checked = sendSms,
                                    onCheckedChange = onToggleSms,
                                    colors = SwitchDefaults.colors(
                                        checkedThumbColor = Color.White,
                                        checkedTrackColor = AssistiveGreen
                                    )
                                )
                            }
                        }
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        Button(
            onClick = onNext,
            shape = RoundedCornerShape(16.dp),
            colors = ButtonDefaults.buttonColors(containerColor = AssistiveBlue),
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp)
                .testTag("emergency_next_button")
        ) {
            Text(
                text = if (isEn) "Next: Choose Layout" else "Weiter: Layout wählen",
                fontSize = 17.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
        }
    }
}
