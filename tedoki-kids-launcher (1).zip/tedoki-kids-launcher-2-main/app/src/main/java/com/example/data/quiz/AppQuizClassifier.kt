package com.example.data.quiz

import android.Manifest
import android.content.Context
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.os.Build
import androidx.compose.runtime.mutableIntStateOf
import com.example.model.quiz.QuizCategory
import java.util.concurrent.ConcurrentHashMap

/**
 * Schlägt für JEDE App ein passendes Quiz-Thema vor – auch für Apps, die TEDOKI nicht kennt.
 * Komplett offline, ohne KI und ohne Internet. Reihenfolge:
 *
 *  1. Eltern haben selbst ein Thema gewählt (oder "kein Quiz")       → gilt immer
 *  2. Bekannte App (Liste unten, z. B. TikTok, Roblox, Telegram)       → festes Thema
 *  3. Kategorie, die der App-Hersteller selbst angibt (Spiel, Video …) → passendes Thema
 *  4. Was die App darf (Kamera, Mikrofon, Kontakte, Standort, Internet) → passendes Thema
 *  5. App ohne Internetzugriff (Taschenrechner, Malen …)               → kein Quiz nötig
 */
object AppQuizClassifier {

    data class Suggestion(
        val category: QuizCategory?,
        val reasonDe: String,
        val reasonEn: String
    )

    private const val PREFS = "tedoki_quiz_topic_overrides"
    private const val NO_QUIZ = "NONE"

    private var appContext: Context? = null
    private val cache = ConcurrentHashMap<String, Suggestion>()
    private val overrides = ConcurrentHashMap<String, String>()

    /** Wird bei jeder Eltern-Änderung hochgezählt, damit Compose-Ansichten neu zeichnen. */
    val version = mutableIntStateOf(0)

    fun init(context: Context) {
        appContext = context.applicationContext
        val prefs = context.applicationContext.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        overrides.clear()
        prefs.all.forEach { (k, v) -> if (v is String) overrides[k] = v }
    }

    // ------------------------------------------------------------------ Eltern-Auswahl

    fun hasOverride(packageName: String): Boolean {
        version.intValue // Lesen, damit Compose bei Änderungen neu zeichnet
        return overrides.containsKey(packageName)
    }

    fun overrideFor(packageName: String): QuizCategory? {
        val raw = overrides[packageName] ?: return null
        if (raw == NO_QUIZ) return null
        return runCatching { QuizCategory.valueOf(raw) }.getOrNull()
    }

    /** category = null und noQuiz = true → "kein Quiz"; beides null/false → zurück auf automatisch. */
    fun setOverride(packageName: String, category: QuizCategory?, noQuiz: Boolean = false) {
        val prefs = appContext?.getSharedPreferences(PREFS, Context.MODE_PRIVATE)
        when {
            noQuiz -> {
                overrides[packageName] = NO_QUIZ
                prefs?.edit()?.putString(packageName, NO_QUIZ)?.apply()
            }
            category != null -> {
                overrides[packageName] = category.name
                prefs?.edit()?.putString(packageName, category.name)?.apply()
            }
            else -> {
                overrides.remove(packageName)
                prefs?.edit()?.remove(packageName)?.apply()
            }
        }
        version.intValue++
    }

    // ------------------------------------------------------------------ Ergebnis

    /** Endgültiges Quiz-Thema einer App (Eltern-Auswahl hat Vorrang). */
    fun categoryFor(packageName: String): QuizCategory? {
        version.intValue
        if (overrides.containsKey(packageName)) return overrideFor(packageName)
        return suggest(packageName).category
    }

    /** Automatischer Vorschlag inkl. Begründung (für den Elternbereich). */
    fun suggest(packageName: String): Suggestion =
        cache.getOrPut(packageName) { compute(packageName) }

    // ------------------------------------------------------------------ Regeln

    private val knownApps: List<Pair<List<String>, QuizCategory>> = listOf(
        // Chats
        listOf("whatsapp") to QuizCategory.WHATSAPP,
        listOf(
            "org.telegram", "org.thoughtcrime.securesms", "ch.threema", "com.discord",
            "com.facebook.orca", "com.kik", "com.skype", "im.vector", "chat"
        ) to QuizCategory.NACHRICHTEN,
        // Fotos & Selbstdarstellung
        listOf("com.snapchat") to QuizCategory.BEVOR_VERSCHICKEN,
        listOf("com.instagram", "com.pinterest", "com.bereal", "com.facebook.katana") to QuizCategory.FOTOS_VON_ANDEREN,
        // Videos
        listOf(
            "com.zhiliaoapp.musically", "com.ss.android.ugc", "youtube", "netflix", "disney",
            "kika", "zdf", "avp.ard", "ardmediathek", "twitch", "joyn", "de.rtl", "primevideo", "amazon.avod", "toggo"
        ) to QuizCategory.VIDEOS,
        // Spiele
        listOf(
            "com.roblox", "com.mojang", "com.epicgames", "com.supercell", "com.king.",
            "com.miniclip", "com.ea.", "com.gameloft", "com.innersloth", "game"
        ) to QuizCategory.SPIELE,
        // Browser
        listOf("firefox", "org.mozilla", "duckduckgo", "com.opera", "sbrowser", "brave", "browser") to QuizCategory.INTERNET_SURFEN,
        // Karten / Standort
        listOf("maps", "waze", "life360", "findmy", "glympse") to QuizCategory.PERSOENLICHE_DATEN
    )

    private fun compute(packageName: String): Suggestion {
        val pkg = packageName.lowercase()

        // 2. Bekannte Apps
        for ((keys, cat) in knownApps) {
            if (keys.any { pkg.contains(it) }) {
                return Suggestion(cat, "bekannte App", "known app")
            }
        }

        val ctx = appContext ?: return Suggestion(null, "unbekannt", "unknown")
        val pm = ctx.packageManager

        val appInfo: ApplicationInfo = try {
            pm.getApplicationInfo(packageName, 0)
        } catch (e: PackageManager.NameNotFoundException) {
            return Suggestion(null, "App nicht gefunden", "app not found")
        }

        // 3. Herstellerangabe (Android 8+)
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            val byStoreCategory = when (appInfo.category) {
                ApplicationInfo.CATEGORY_GAME -> QuizCategory.SPIELE
                ApplicationInfo.CATEGORY_VIDEO -> QuizCategory.VIDEOS
                ApplicationInfo.CATEGORY_SOCIAL -> QuizCategory.NACHRICHTEN
                ApplicationInfo.CATEGORY_IMAGE -> QuizCategory.FOTOS_VON_ANDEREN
                ApplicationInfo.CATEGORY_NEWS -> QuizCategory.INTERNET_SURFEN
                ApplicationInfo.CATEGORY_MAPS -> QuizCategory.PERSOENLICHE_DATEN
                else -> null
            }
            if (byStoreCategory != null) {
                return Suggestion(byStoreCategory, "laut App-Hersteller", "according to the developer")
            }
        }
        if (appInfo.flags and ApplicationInfo.FLAG_IS_GAME != 0) {
            return Suggestion(QuizCategory.SPIELE, "laut App-Hersteller", "according to the developer")
        }

        // 4. Was darf die App?
        val perms: Set<String> = try {
            pm.getPackageInfo(packageName, PackageManager.GET_PERMISSIONS).requestedPermissions?.toSet() ?: emptySet()
        } catch (e: Exception) {
            emptySet()
        }
        val internet = Manifest.permission.INTERNET in perms
        if (!internet) {
            return Suggestion(null, "kein Internetzugriff – kein Quiz nötig", "no internet access – no quiz needed")
        }
        return when {
            Manifest.permission.READ_CONTACTS in perms && Manifest.permission.RECORD_AUDIO in perms ->
                Suggestion(QuizCategory.SPRACHNACHRICHTEN, "Kontakte + Mikrofon + Internet", "contacts + microphone + internet")
            Manifest.permission.READ_CONTACTS in perms ->
                Suggestion(QuizCategory.NACHRICHTEN, "Kontakte + Internet", "contacts + internet")
            Manifest.permission.CAMERA in perms ->
                Suggestion(QuizCategory.BEVOR_VERSCHICKEN, "Kamera + Internet", "camera + internet")
            Manifest.permission.ACCESS_FINE_LOCATION in perms || Manifest.permission.ACCESS_COARSE_LOCATION in perms ->
                Suggestion(QuizCategory.PERSOENLICHE_DATEN, "Standort + Internet", "location + internet")
            Manifest.permission.RECORD_AUDIO in perms ->
                Suggestion(QuizCategory.SPRACHNACHRICHTEN, "Mikrofon + Internet", "microphone + internet")
            else ->
                Suggestion(QuizCategory.INTERNET_SURFEN, "nutzt das Internet", "uses the internet")
        }
    }
}
