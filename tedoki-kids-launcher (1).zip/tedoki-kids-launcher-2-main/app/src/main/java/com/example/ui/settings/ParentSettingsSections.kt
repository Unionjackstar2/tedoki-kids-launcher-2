package com.example.ui.settings

import androidx.activity.compose.ManagedActivityResultLauncher
import androidx.compose.foundation.layout.ColumnScope
import android.net.Uri
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForwardIos
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.BrightnessAuto
import androidx.compose.material.icons.filled.DarkMode
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.LightMode
import androidx.compose.material.icons.filled.Palette
import androidx.compose.material.icons.filled.TableRows
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.material3.TextButton
import androidx.compose.ui.window.Dialog
import androidx.compose.foundation.layout.heightIn
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.R
import com.example.model.LauncherButton
import com.example.model.LauncherSettings
import com.example.model.LayoutStyle
import com.example.model.ThemeMode
import com.example.ui.theme.AssistiveBlue
import com.example.ui.theme.AssistiveBorder
import com.example.ui.theme.AssistiveSurface
import com.example.ui.theme.AssistiveTextMuted
import com.example.ui.theme.AssistiveTextPrimary
import com.example.ui.theme.AssistiveTextSecondary

@Composable
internal fun ColumnScope.ProfileSection(
    currentSettings: LauncherSettings,
    onSaveSettings: (LauncherSettings) -> Unit,
    isDark: Boolean,
    childName: String,
    childAvatarPickerLauncher: ManagedActivityResultLauncher<PickVisualMediaRequest, Uri?>,
    childAvatar: String,
    showAvatarModal: Boolean,
    onChildAvatarChange: (String) -> Unit,
    onShowAvatarModalChange: (Boolean) -> Unit
) {
        // Section: Child Profile
        SettingsSectionLabel(title = "Profil des Kindes")

        val avatarPreset = com.example.ui.setup.PRESET_AVATARS.find { it.id == childAvatar }
        val isCustomPhoto = childAvatar.startsWith("content://") || childAvatar.startsWith("file://") || childAvatar.startsWith("/")

        Card(
            shape = RoundedCornerShape(22.dp),
            colors = CardDefaults.cardColors(containerColor = AssistiveSurface),
            border = BorderStroke(1.dp, AssistiveBorder),
            modifier = Modifier.fillMaxWidth().testTag("child_profile_settings_card")
        ) {
            Column(
                modifier = Modifier.padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(14.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(14.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(56.dp)
                            .clip(CircleShape)
                            .background(
                                if (isCustomPhoto) Color.Transparent
                                else Color(avatarPreset?.bgHex ?: 0xFF3B82F6)
                            )
                            .border(2.dp, AssistiveBlue, CircleShape)
                            .clickable {
                                onShowAvatarModalChange(true)
                            },
                        contentAlignment = Alignment.Center
                    ) {
                        if (isCustomPhoto) {
                            AsyncImage(
                                model = childAvatar,
                                contentDescription = "Avatar",
                                contentScale = ContentScale.Crop,
                                modifier = Modifier.fillMaxSize().clip(CircleShape)
                            )
                        } else {
                            Text(text = avatarPreset?.emoji ?: "🦁", fontSize = 30.sp)
                        }
                    }

                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = childName.ifBlank { "Kind" },
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = AssistiveTextPrimary
                        )
                        Text(
                            text = if (isCustomPhoto) "Eigenes Profilfoto hinterlegt ✓" else (avatarPreset?.name ?: "Avatar"),
                            fontSize = 13.sp,
                            color = AssistiveTextSecondary
                        )
                    }

                    Button(
                        onClick = {
                            onShowAvatarModalChange(true)
                        },
                        shape = RoundedCornerShape(12.dp),
                        colors = ButtonDefaults.buttonColors(
                            containerColor = if (isDark) Color(0xFF1E293B) else Color(0xFFEFF6FF),
                            contentColor = AssistiveBlue
                        ),
                        border = BorderStroke(1.dp, AssistiveBlue),
                        contentPadding = PaddingValues(horizontal = 12.dp, vertical = 6.dp)
                    ) {
                        Text(text = "Foto ändern", fontSize = 12.sp, fontWeight = FontWeight.Bold)
                    }
                }
            }
        }

        if (showAvatarModal) {
            Dialog(onDismissRequest = { onShowAvatarModalChange(false) }) {
                Card(
                    shape = RoundedCornerShape(24.dp),
                    colors = CardDefaults.cardColors(containerColor = AssistiveSurface),
                    border = BorderStroke(1.dp, AssistiveBorder),
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(16.dp)
                ) {
                    Column(
                        modifier = Modifier.padding(20.dp),
                        horizontalAlignment = Alignment.CenterHorizontally,
                        verticalArrangement = Arrangement.spacedBy(16.dp)
                    ) {
                        Text(
                            text = "Profilbild auswählen",
                            fontSize = 20.sp,
                            fontWeight = FontWeight.Bold,
                            color = AssistiveTextPrimary
                        )

                        // Presets Grid
                        val columns = 4
                        val presets = com.example.ui.setup.PRESET_AVATARS
                        val rows = (presets.size + columns - 1) / columns

                        Column(
                            verticalArrangement = Arrangement.spacedBy(12.dp),
                            modifier = Modifier
                                .fillMaxWidth()
                                .heightIn(max = 280.dp)
                                .verticalScroll(rememberScrollState())
                        ) {
                            for (r in 0 until rows) {
                                Row(
                                    modifier = Modifier.fillMaxWidth(),
                                    horizontalArrangement = Arrangement.SpaceEvenly
                                ) {
                                    for (c in 0 until columns) {
                                        val index = r * columns + c
                                        if (index < presets.size) {
                                            val preset = presets[index]
                                            val isSelected = childAvatar == preset.id
                                            Box(
                                                modifier = Modifier
                                                    .size(60.dp)
                                                    .clip(CircleShape)
                                                    .background(Color(preset.bgHex))
                                                    .border(
                                                        width = if (isSelected) 3.dp else 1.dp,
                                                        color = if (isSelected) AssistiveBlue else Color.Transparent,
                                                        shape = CircleShape
                                                    )
                                                    .clickable {
                                                        onChildAvatarChange(preset.id)
                                                        onSaveSettings(currentSettings.copy(childAvatar = preset.id))
                                                        onShowAvatarModalChange(false)
                                                    },
                                                contentAlignment = Alignment.Center
                                            ) {
                                                Text(text = preset.emoji, fontSize = 32.sp)
                                            }
                                        } else {
                                            Spacer(modifier = Modifier.size(60.dp))
                                        }
                                    }
                                }
                            }
                        }

                        Spacer(
                            modifier = Modifier
                                .fillMaxWidth()
                                .height(1.dp)
                                .background(AssistiveBorder)
                        )

                        // Upload own photo option
                        Button(
                            onClick = {
                                onShowAvatarModalChange(false)
                                childAvatarPickerLauncher.launch(
                                    PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                )
                            },
                            shape = RoundedCornerShape(14.dp),
                            colors = ButtonDefaults.buttonColors(
                                containerColor = AssistiveBlue,
                                contentColor = Color.White
                            ),
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Row(
                                horizontalArrangement = Arrangement.spacedBy(8.dp),
                                verticalAlignment = Alignment.CenterVertically
                            ) {
                                Icon(
                                    imageVector = Icons.Default.Add,
                                    contentDescription = "Foto hochladen"
                                )
                                Text("Eigenes Foto hochladen", fontWeight = FontWeight.Bold)
                            }
                        }

                        TextButton(
                            onClick = { onShowAvatarModalChange(false) },
                            modifier = Modifier.fillMaxWidth()
                        ) {
                            Text("Abbrechen", color = AssistiveTextSecondary, fontWeight = FontWeight.Medium)
                        }
                    }
                }
            }
        }
}

@Composable
internal fun ColumnScope.HomescreenSection(
    currentSettings: LauncherSettings,
    onSaveSettings: (LauncherSettings) -> Unit,
    isDark: Boolean,
    buttons: List<LauncherButton>,
    layoutStyle: LayoutStyle,
    themeMode: ThemeMode,
    onLayoutStyleChange: (LayoutStyle) -> Unit,
    onThemeModeChange: (ThemeMode) -> Unit,
    onShowAppsSubScreenChange: (Boolean) -> Unit
) {
        // Section: Homescreen & Layout
        SettingsSectionLabel(title = "Startbildschirm & Tasten")

        // Appearance & Theme Mode Selector Card
        Card(
            shape = RoundedCornerShape(22.dp),
            colors = CardDefaults.cardColors(containerColor = AssistiveSurface),
            border = BorderStroke(1.dp, AssistiveBorder),
            modifier = Modifier.fillMaxWidth().testTag("theme_mode_card")
        ) {
            Column(
                modifier = Modifier.padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    Box(
                        modifier = Modifier
                            .size(42.dp)
                            .clip(CircleShape)
                            .background(AssistiveBlue.copy(alpha = 0.12f)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Palette,
                            contentDescription = null,
                            tint = AssistiveBlue,
                            modifier = Modifier.size(22.dp)
                        )
                    }
                    Column(modifier = Modifier.weight(1f)) {
                        Text(
                            text = stringResource(R.string.settings_appearance_title),
                            fontSize = 18.sp,
                            fontWeight = FontWeight.Bold,
                            color = AssistiveTextPrimary
                        )
                        Text(
                            text = stringResource(R.string.settings_appearance_desc),
                            fontSize = 13.sp,
                            color = AssistiveTextMuted
                        )
                    }
                }

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    ThemeTogglePill(
                        title = stringResource(R.string.theme_mode_system),
                        isSelected = themeMode == ThemeMode.SYSTEM,
                        icon = Icons.Default.BrightnessAuto,
                        modifier = Modifier.weight(1f).testTag("theme_btn_system"),
                        onClick = {
                            onThemeModeChange(ThemeMode.SYSTEM)
                            onSaveSettings(currentSettings.copy(themeMode = ThemeMode.SYSTEM))
                        }
                    )

                    ThemeTogglePill(
                        title = stringResource(R.string.theme_mode_light),
                        isSelected = themeMode == ThemeMode.LIGHT,
                        icon = Icons.Default.LightMode,
                        modifier = Modifier.weight(1f).testTag("theme_btn_light"),
                        onClick = {
                            onThemeModeChange(ThemeMode.LIGHT)
                            onSaveSettings(currentSettings.copy(themeMode = ThemeMode.LIGHT))
                        }
                    )

                    ThemeTogglePill(
                        title = stringResource(R.string.theme_mode_dark),
                        isSelected = themeMode == ThemeMode.DARK,
                        icon = Icons.Default.DarkMode,
                        modifier = Modifier.weight(1f).testTag("theme_btn_dark"),
                        onClick = {
                            onThemeModeChange(ThemeMode.DARK)
                            onSaveSettings(currentSettings.copy(themeMode = ThemeMode.DARK))
                        }
                    )
                }
            }
        }

        // Layout Style Switcher
        Card(
            shape = RoundedCornerShape(22.dp),
            colors = CardDefaults.cardColors(containerColor = AssistiveSurface),
            border = BorderStroke(1.dp, AssistiveBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Column(
                modifier = Modifier.padding(18.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                Text(
                    text = stringResource(R.string.layout_style_title),
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = AssistiveTextPrimary
                )

                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    LayoutTogglePill(
                        title = stringResource(R.string.layout_grid),
                        isSelected = layoutStyle == LayoutStyle.GRID,
                        icon = Icons.Default.GridView,
                        modifier = Modifier.weight(1f),
                        onClick = {
                            onLayoutStyleChange(LayoutStyle.GRID)
                            onSaveSettings(currentSettings.copy(layoutStyle = LayoutStyle.GRID))
                        }
                    )

                    LayoutTogglePill(
                        title = stringResource(R.string.layout_rows),
                        isSelected = layoutStyle == LayoutStyle.ROWS,
                        icon = Icons.Default.TableRows,
                        modifier = Modifier.weight(1f),
                        onClick = {
                            onLayoutStyleChange(LayoutStyle.ROWS)
                            onSaveSettings(currentSettings.copy(layoutStyle = LayoutStyle.ROWS))
                        }
                    )
                }
            }
        }

        // Dedicated Apps & Tasten Management Submenu Entry Card
        Card(
            shape = RoundedCornerShape(22.dp),
            colors = CardDefaults.cardColors(containerColor = AssistiveSurface),
            border = BorderStroke(1.dp, AssistiveBorder),
            modifier = Modifier
                .fillMaxWidth()
                .clickable { onShowAppsSubScreenChange(true) }
                .testTag("open_apps_submenu")
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(18.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(14.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(46.dp)
                            .clip(CircleShape)
                            .background(if (isDark) Color(0xFF1E3A8A).copy(alpha = 0.4f) else Color(0xFFEFF6FF)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Apps,
                            contentDescription = null,
                            tint = AssistiveBlue,
                            modifier = Modifier.size(24.dp)
                        )
                    }

                    Column {
                        Text(
                            text = "Apps & Tasten auswählen",
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold,
                            color = AssistiveTextPrimary
                        )
                        Text(
                            text = "${buttons.size} von 8 Tasten auf dem Homescreen aktiv",
                            fontSize = 13.sp,
                            color = AssistiveTextSecondary
                        )
                    }
                }

                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowForwardIos,
                    contentDescription = null,
                    tint = Color(0xFF94A3B8),
                    modifier = Modifier.size(18.dp)
                )
            }
        }
}
