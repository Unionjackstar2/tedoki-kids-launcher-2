package com.example.data.quiz

import com.example.model.quiz.QuizCategory
import com.example.model.quiz.QuizModule

/**
 * Registry of all pedagogical quiz modules.
 * The module contents live in QuizModulesCommunication.kt, QuizModulesMedia.kt and QuizModulesSafety.kt.
 */
object PedagogyQuizData {

    val allModules: Map<QuizCategory, QuizModule> = mapOf(
        QuizCategory.ANRUFEN to anrufenModule,
        QuizCategory.UNBEKANNTE_NUMMERN to unbekannteNummernModule,
        QuizCategory.NACHRICHTEN to nachrichtenModule,
        QuizCategory.WHATSAPP to whatsappModule,
        QuizCategory.FOTOS_MACHEN to fotosMachenModule,
        QuizCategory.FOTOS_VON_ANDEREN to fotosVonAnderenModule,
        QuizCategory.SPRACHNACHRICHTEN to sprachnachrichtenModule,
        QuizCategory.BLOCKIEREN to blockierenModule,
        QuizCategory.PERSOENLICHE_DATEN to persoenlicheDatenModule,
        QuizCategory.BEVOR_VERSCHICKEN to bevorVerschickenModule,
        QuizCategory.INTERNET_SURFEN to internetSurfenModule,
        QuizCategory.VIDEOS to videosModule,
        QuizCategory.SPIELE to spieleModule
    )

    fun getModule(category: QuizCategory): QuizModule {
        return allModules[category] ?: allModules.values.first()
    }
}
