package com.example.ui.home

import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.PhotoCamera
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.draw.shadow
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.animation.core.*
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.model.ButtonType
import com.example.model.LauncherButton
import com.example.model.quiz.AppPedagogyStatus
import com.example.ui.theme.AssistiveBorder
import com.example.ui.theme.AssistiveGreen
import com.example.ui.theme.AssistiveSurface
import com.example.ui.theme.AssistiveTextMuted
import com.example.ui.theme.AssistiveTextPrimary

/**
 * Large iOS Assistive Access style Grid Tile (Big icon/photo + large label)
 */
@Composable
fun AssistiveGridTile(
    button: LauncherButton,
    pedagogyStatus: AppPedagogyStatus? = null,
    modifier: Modifier = Modifier,
    isClickable: Boolean = true,
    onClick: () -> Unit
) {
    val smsMessages by com.example.sms.SmsRepository.messagesFlow.collectAsState()
    val unreadSmsCount = remember(smsMessages, button.type) {
        if (button.type == ButtonType.SMS) smsMessages.count { it.isIncoming && !it.isRead } else 0
    }

    Box(
        modifier = modifier.fillMaxWidth()
    ) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .height(180.dp)
                .shadow(6.dp, RoundedCornerShape(32.dp))
                .clip(RoundedCornerShape(32.dp))
                .clickable(enabled = isClickable, onClick = onClick)
                .testTag("tile_${button.id}"),
            shape = RoundedCornerShape(32.dp),
            colors = CardDefaults.cardColors(containerColor = AssistiveSurface),
            border = androidx.compose.foundation.BorderStroke(1.5.dp, AssistiveBorder)
        ) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(16.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                // Large Icon or Contact Photo
                Box(
                    modifier = Modifier
                        .size(80.dp)
                        .clip(CircleShape)
                        .background(Color(button.colorHex)),
                    contentAlignment = Alignment.Center
                ) {
                    if (button.photoUri != null) {
                        AsyncImage(
                            model = button.photoUri,
                            contentDescription = button.title,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .fillMaxSize()
                                .clip(CircleShape)
                        )
                    } else if (button.type == ButtonType.APP) {
                        com.example.util.InstalledAppIcon(
                            packageName = button.packageName,
                            modifier = Modifier.size(52.dp)
                        )
                    } else {
                        val icon = when (button.type) {
                            ButtonType.CAMERA -> Icons.Default.PhotoCamera
                            ButtonType.PHOTOS -> Icons.Default.Image
                            ButtonType.CALL -> Icons.Default.Phone
                            ButtonType.APP -> Icons.Default.Phone
                            ButtonType.BROWSER -> Icons.Default.Language
                            ButtonType.SMS -> Icons.Default.Email
                        }
                        Icon(
                            imageVector = icon,
                            contentDescription = button.title,
                            tint = Color.White,
                            modifier = Modifier.size(44.dp)
                        )
                    }
                }

                Spacer(modifier = Modifier.height(12.dp))

                // High contrast large label
                Text(
                    text = com.example.ui.components.getLocalizedButtonTitle(button),
                    fontSize = 20.sp,
                    fontWeight = FontWeight.Bold,
                    color = AssistiveTextPrimary,
                    maxLines = 1
                )
            }
        }

        // Status badge: green checkmark if fully unlocked, or lock if protected & locked
        if (pedagogyStatus != null) {
            val isUnlocked = pedagogyStatus.isFullyUnlocked()
            Box(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(12.dp)
                    .size(28.dp)
                    .clip(CircleShape)
                    .background(if (isUnlocked) AssistiveGreen else Color(0xFFE2E8F0)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = if (isUnlocked) Icons.Default.Check else Icons.Default.Lock,
                    contentDescription = if (isUnlocked) "Freigeschaltet" else "Gesperrt",
                    tint = if (isUnlocked) Color.White else Color(0xFF64748B),
                    modifier = Modifier.size(16.dp)
                )
            }
        }

        // Visual notification counter badge for unread SMS
        if (unreadSmsCount > 0 && button.type == ButtonType.SMS) {
            Box(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(10.dp)
                    .size(34.dp)
                    .clip(CircleShape)
                    .background(Color(0xFFEF4444))
                    .border(2.dp, Color.White, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = if (unreadSmsCount > 99) "99+" else unreadSmsCount.toString(),
                    color = Color.White,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.ExtraBold
                )
            }
        }
    }
}

/**
 * Large iOS Assistive Access style Row Tile (Full-width list with large icon & text)
 */
@Composable
fun AssistiveRowTile(
    button: LauncherButton,
    pedagogyStatus: AppPedagogyStatus? = null,
    modifier: Modifier = Modifier,
    isClickable: Boolean = true,
    onClick: () -> Unit
) {
    val smsMessages by com.example.sms.SmsRepository.messagesFlow.collectAsState()
    val unreadSmsCount = remember(smsMessages, button.type) {
        if (button.type == ButtonType.SMS) smsMessages.count { it.isIncoming && !it.isRead } else 0
    }

    Box(
        modifier = modifier.fillMaxWidth()
    ) {
        Card(
            modifier = Modifier
                .fillMaxWidth()
                .height(96.dp)
                .shadow(5.dp, RoundedCornerShape(26.dp))
                .clip(RoundedCornerShape(26.dp))
                .clickable(enabled = isClickable, onClick = onClick)
                .testTag("row_${button.id}"),
            shape = RoundedCornerShape(26.dp),
            colors = CardDefaults.cardColors(containerColor = AssistiveSurface),
            border = androidx.compose.foundation.BorderStroke(1.5.dp, AssistiveBorder)
        ) {
            Row(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(horizontal = 20.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(18.dp)
            ) {
                // Icon or Photo
                Box(
                    modifier = Modifier
                        .size(64.dp)
                        .clip(CircleShape)
                        .background(Color(button.colorHex)),
                    contentAlignment = Alignment.Center
                ) {
                    if (button.photoUri != null) {
                        AsyncImage(
                            model = button.photoUri,
                            contentDescription = button.title,
                            contentScale = ContentScale.Crop,
                            modifier = Modifier
                                .fillMaxSize()
                                .clip(CircleShape)
                        )
                    } else if (button.type == ButtonType.APP) {
                        com.example.util.InstalledAppIcon(
                            packageName = button.packageName,
                            modifier = Modifier.size(42.dp)
                        )
                    } else {
                        val icon = when (button.type) {
                            ButtonType.CAMERA -> Icons.Default.PhotoCamera
                            ButtonType.PHOTOS -> Icons.Default.Image
                            ButtonType.CALL -> Icons.Default.Phone
                            ButtonType.APP -> Icons.Default.Phone
                            ButtonType.BROWSER -> Icons.Default.Language
                            ButtonType.SMS -> Icons.Default.Email
                        }
                        Icon(
                            imageVector = icon,
                            contentDescription = button.title,
                            tint = Color.White,
                            modifier = Modifier.size(36.dp)
                        )
                    }
                }

                Column(
                    modifier = Modifier.weight(1f)
                ) {
                    Text(
                        text = com.example.ui.components.getLocalizedButtonTitle(button),
                        fontSize = 24.sp,
                        fontWeight = FontWeight.Bold,
                        color = AssistiveTextPrimary
                    )
                    if (button.type == ButtonType.CALL && button.phoneNumber.isNotEmpty()) {
                        Text(
                            text = button.phoneNumber,
                            fontSize = 15.sp,
                            color = AssistiveTextMuted
                        )
                    }
                }
            }
        }

        // Status badge: green checkmark if fully unlocked, or lock if protected & locked
        if (pedagogyStatus != null) {
            val isUnlocked = pedagogyStatus.isFullyUnlocked()
            Box(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(12.dp)
                    .size(28.dp)
                    .clip(CircleShape)
                    .background(if (isUnlocked) AssistiveGreen else Color(0xFFE2E8F0)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = if (isUnlocked) Icons.Default.Check else Icons.Default.Lock,
                    contentDescription = if (isUnlocked) "Freigeschaltet" else "Gesperrt",
                    tint = if (isUnlocked) Color.White else Color(0xFF64748B),
                    modifier = Modifier.size(16.dp)
                )
            }
        }

        // Visual notification counter badge for unread SMS
        if (unreadSmsCount > 0 && button.type == ButtonType.SMS) {
            Box(
                modifier = Modifier
                    .align(Alignment.TopEnd)
                    .padding(10.dp)
                    .size(34.dp)
                    .clip(CircleShape)
                    .background(Color(0xFFEF4444))
                    .border(2.dp, Color.White, CircleShape),
                contentAlignment = Alignment.Center
            ) {
                Text(
                    text = if (unreadSmsCount > 99) "99+" else unreadSmsCount.toString(),
                    color = Color.White,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.ExtraBold
                )
            }
        }
    }
}

internal data class UnlockedFeatureItem(
    val id: String,
    val title: String,
    val emoji: String,
    val colorHex: Long,
    val explanation: String
)
