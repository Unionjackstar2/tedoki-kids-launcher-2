package com.example.ui.setup

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.PaddingValues
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import com.example.ui.theme.AssistiveAmber
import com.example.ui.theme.AssistiveAmberLight
import com.example.ui.theme.AssistiveBlue
import com.example.ui.theme.AssistiveBlueLight
import com.example.ui.theme.AssistiveBorder
import com.example.ui.theme.AssistiveGreen
import com.example.ui.theme.AssistiveGreenLight
import com.example.ui.theme.AssistiveSurface
import com.example.ui.theme.AssistiveTextMuted
import com.example.ui.theme.AssistiveTextPrimary
import com.example.ui.theme.AssistiveTextSecondary
import com.example.util.SystemSetupHelper
import com.example.util.SystemSetupHelper.Item

// =====================================================================================
// EINRICHTUNG: "Handy vorbereiten" – Standard-Apps, Zugriffe, Sperrbildschirm
// =====================================================================================

private data class ItemText(val emoji: String, val title: String, val text: String)

private fun itemText(item: Item, isEn: Boolean): ItemText = when (item) {
    Item.HOME -> if (isEn) ItemText(
        "🏠", "Start screen",
        "So the Home button always leads to TEDOKI and not to the normal phone screen. In the next window tap \"TEDOKI kids\"."
    ) else ItemText(
        "🏠", "Startbildschirm",
        "Damit die Home-Taste immer zu TEDOKI führt und nicht zum normalen Handy-Bildschirm. Im nächsten Fenster „TEDOKI kids“ antippen."
    )
    Item.DIALER -> if (isEn) ItemText(
        "📞", "Phone app",
        "Calls arrive in the simple child view and the SOS call works. In the next window choose \"TEDOKI kids\" and confirm."
    ) else ItemText(
        "📞", "Telefon-App",
        "Damit Anrufe in der einfachen Kinder-Ansicht ankommen und der SOS-Anruf klappt. Im nächsten Fenster „TEDOKI kids“ wählen und bestätigen."
    )
    Item.SMS -> if (isEn) ItemText(
        "💬", "SMS app",
        "Messages arrive in TEDOKI and the SOS text with location can be sent. In the next window choose \"TEDOKI kids\"."
    ) else ItemText(
        "💬", "SMS-App",
        "Damit Nachrichten in TEDOKI ankommen und die SOS-SMS mit Standort verschickt werden kann. Im nächsten Fenster „TEDOKI kids“ wählen."
    )
    Item.PERMISSIONS -> if (isEn) ItemText(
        "✅", "Allow access",
        "Contacts, camera, location and notifications. Android asks one by one – tap \"Allow\" or \"While using the app\" each time."
    ) else ItemText(
        "✅", "Zugriffe erlauben",
        "Kontakte, Kamera, Standort und Benachrichtigungen. Android fragt nacheinander – jedes Mal „Zulassen“ bzw. „Während der App-Nutzung“ antippen."
    )
    Item.FULL_SCREEN_CALLS -> if (isEn) ItemText(
        "📲", "Calls on the whole screen",
        "So an incoming call is shown big even when the screen is off. Switch on the toggle next to \"TEDOKI kids\", then come back."
    ) else ItemText(
        "📲", "Anrufe im Vollbild",
        "Damit ein Anruf auch bei ausgeschaltetem Bildschirm groß erscheint. Den Schalter bei „TEDOKI kids“ einschalten und zurückkommen."
    )
    Item.LOCATION_ON -> if (isEn) ItemText(
        "📍", "Turn on location",
        "Only needed for the SOS text: without location, TEDOKI can't tell you where your child is. Switch on \"Use location\"."
    ) else ItemText(
        "📍", "Standort einschalten",
        "Nur für die SOS-SMS nötig: Ohne Standort kann TEDOKI nicht mitschicken, wo dein Kind gerade ist. „Standort verwenden“ einschalten."
    )
    Item.SYSTEM_LOCK_OFF -> if (isEn) ItemText(
        "🔓", "Remove the Android screen lock",
        "Otherwise your child first has to get past the normal phone lock (PIN/pattern). TEDOKI brings its own child-friendly lock screen. In the next window choose \"None\" – Android asks for the old code first, that's normal."
    ) else ItemText(
        "🔓", "Android-Sperre entfernen",
        "Sonst muss dein Kind erst an der normalen Handy-Sperre (PIN/Muster) vorbei. TEDOKI hat einen eigenen, kindgerechten Sperrbildschirm. Im nächsten Fenster „Keine“ wählen – Android fragt vorher nach dem bisherigen Code, das ist normal."
    )
}

/**
 * Wiederverwendbare Checkliste – in der Einrichtung und im Elternbereich (System & Telefonie).
 * Prüft bei jeder Rückkehr in die App automatisch neu, was schon erledigt ist.
 */
@Composable
fun SystemSetupChecklist(
    isEn: Boolean,
    needCalls: Boolean,
    needSms: Boolean,
    needLocation: Boolean,
    removeSystemLock: Boolean,
    modifier: Modifier = Modifier
) {
    val context = LocalContext.current
    val lifecycleOwner = androidx.compose.ui.platform.LocalLifecycleOwner.current

    var refreshTick by remember { mutableIntStateOf(0) }
    var restrictedHelpFor by remember { mutableStateOf<Item?>(null) }
    var permissionsDenied by remember { mutableStateOf(false) }

    // Neu prüfen, sobald die Eltern aus den Android-Einstellungen zurückkommen
    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, event ->
            if (event == Lifecycle.Event.ON_RESUME) refreshTick++
        }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    val permissions = remember(needCalls, needSms, needLocation) {
        SystemSetupHelper.requiredPermissions(needCalls, needSms, needLocation)
    }

    val items = remember(needCalls, needSms, needLocation, removeSystemLock) {
        buildList {
            add(Item.HOME)
            if (needCalls) add(Item.DIALER)
            if (needSms) add(Item.SMS)
            add(Item.PERMISSIONS)
            if (needCalls) add(Item.FULL_SCREEN_CALLS)
            if (needLocation) add(Item.LOCATION_ON)
            if (removeSystemLock) add(Item.SYSTEM_LOCK_OFF)
        }
    }

    var pendingRole by remember { mutableStateOf<Item?>(null) }
    val roleLauncher = rememberLauncherForActivityResult(ActivityResultContracts.StartActivityForResult()) {
        val item = pendingRole
        refreshTick++
        if (item != null && !SystemSetupHelper.isDone(context, item, permissions) &&
            (item == Item.SMS || item == Item.DIALER) && SystemSetupHelper.mayBeRestrictedSetting()
        ) {
            restrictedHelpFor = item
        }
        pendingRole = null
    }

    val permissionLauncher = rememberLauncherForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) {
        refreshTick++
        permissionsDenied = SystemSetupHelper.missingPermissions(context, permissions).isNotEmpty()
    }

    val doneMap = remember(refreshTick, items, permissions) {
        items.associateWith { SystemSetupHelper.isDone(context, it, permissions) }
    }
    val doneCount = doneMap.values.count { it }

    Column(modifier = modifier.fillMaxWidth(), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(
            text = if (isEn) "$doneCount of ${items.size} done" else "$doneCount von ${items.size} erledigt",
            fontSize = 13.sp,
            fontWeight = FontWeight.Bold,
            color = if (doneCount == items.size) AssistiveGreen else AssistiveTextMuted
        )

        items.forEach { item ->
            val t = itemText(item, isEn)
            val done = doneMap[item] == true
            ChecklistRow(
                emoji = t.emoji,
                title = t.title,
                text = t.text,
                done = done,
                isEn = isEn,
                onSetup = {
                    when (item) {
                        Item.PERMISSIONS -> {
                            val missing = SystemSetupHelper.missingPermissions(context, permissions)
                            if (permissionsDenied || missing.isEmpty()) {
                                SystemSetupHelper.openAppInfo(context)
                            } else {
                                permissionLauncher.launch(missing.toTypedArray())
                            }
                        }
                        Item.HOME, Item.DIALER, Item.SMS -> {
                            val intent = SystemSetupHelper.roleRequestIntent(context, item)
                            if (intent != null) {
                                pendingRole = item
                                try {
                                    roleLauncher.launch(intent)
                                } catch (e: Exception) {
                                    pendingRole = null
                                    SystemSetupHelper.open(context, item)
                                }
                            } else {
                                SystemSetupHelper.open(context, item)
                            }
                        }
                        else -> SystemSetupHelper.open(context, item)
                    }
                }
            )

            if (item == Item.PERMISSIONS && permissionsDenied && !done) {
                HintCard(
                    text = if (isEn)
                        "Some access was declined. No problem: tap \"Set up\" again – the app info opens. There tap \"Permissions\" and allow the missing ones."
                    else
                        "Manches wurde abgelehnt. Kein Problem: Nochmal auf „Einrichten“ tippen – die App-Info öffnet sich. Dort „Berechtigungen“ antippen und das Fehlende erlauben."
                )
            }

            if (restrictedHelpFor == item && !done) {
                RestrictedSettingsHelp(isEn = isEn, onOpenAppInfo = { SystemSetupHelper.openAppInfo(context) })
            }
        }
    }
}

@Composable
private fun ChecklistRow(
    emoji: String,
    title: String,
    text: String,
    done: Boolean,
    isEn: Boolean,
    onSetup: () -> Unit
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = AssistiveSurface),
        border = BorderStroke(1.dp, if (done) AssistiveGreen else AssistiveBorder),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(14.dp)) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(38.dp)
                        .clip(CircleShape)
                        .background(if (done) AssistiveGreenLight else AssistiveBlueLight),
                    contentAlignment = Alignment.Center
                ) {
                    Text(text = if (done) "✓" else emoji, fontSize = 18.sp, color = AssistiveGreen, fontWeight = FontWeight.Bold)
                }
                Spacer(modifier = Modifier.width(12.dp))
                Text(
                    text = title,
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = AssistiveTextPrimary,
                    modifier = Modifier.weight(1f)
                )
                if (done) {
                    Text(
                        text = if (isEn) "Done" else "Erledigt",
                        fontSize = 12.sp,
                        fontWeight = FontWeight.Bold,
                        color = AssistiveGreen
                    )
                } else {
                    Button(
                        onClick = onSetup,
                        shape = RoundedCornerShape(10.dp),
                        colors = ButtonDefaults.buttonColors(containerColor = AssistiveBlue),
                        contentPadding = PaddingValues(horizontal = 14.dp, vertical = 6.dp)
                    ) {
                        Text(
                            text = if (isEn) "Set up" else "Einrichten",
                            fontSize = 13.sp,
                            color = Color.White,
                            fontWeight = FontWeight.SemiBold
                        )
                    }
                }
            }
            if (!done) {
                Spacer(modifier = Modifier.height(8.dp))
                Text(text = text, fontSize = 13.sp, color = AssistiveTextSecondary, lineHeight = 18.sp)
            }
        }
    }
}

@Composable
private fun HintCard(text: String) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = AssistiveAmberLight),
        border = BorderStroke(1.dp, AssistiveAmber),
        modifier = Modifier.fillMaxWidth()
    ) {
        Text(
            text = text,
            fontSize = 13.sp,
            color = Color(0xFF78350F),
            lineHeight = 18.sp,
            modifier = Modifier.padding(12.dp)
        )
    }
}

@Composable
private fun RestrictedSettingsHelp(isEn: Boolean, onOpenAppInfo: () -> Unit) {
    Card(
        shape = RoundedCornerShape(14.dp),
        colors = CardDefaults.cardColors(containerColor = AssistiveAmberLight),
        border = BorderStroke(1.dp, AssistiveAmber),
        modifier = Modifier.fillMaxWidth()
    ) {
        Column(modifier = Modifier.padding(12.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
            Text(
                text = if (isEn) "Android blocked this?" else "Android hat das blockiert?",
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = Color(0xFF78350F)
            )
            Text(
                text = if (isEn)
                    "That's normal for apps that don't come from the Play Store (\"Restricted setting\"). Here's how:\n" +
                        "1. Tap \"Open app info\" below.\n" +
                        "2. Tap the three dots ⋮ at the top right.\n" +
                        "3. Choose \"Allow restricted settings\" and confirm with your code.\n" +
                        "4. Come back here and tap \"Set up\" again."
                else
                    "Das ist normal bei Apps, die nicht aus dem Play Store kommen („Eingeschränkte Einstellung“). So geht’s:\n" +
                        "1. Unten auf „App-Info öffnen“ tippen.\n" +
                        "2. Oben rechts auf die drei Punkte ⋮ tippen.\n" +
                        "3. „Eingeschränkte Einstellungen zulassen“ wählen und mit dem Handy-Code bestätigen.\n" +
                        "4. Hierher zurückkommen und nochmal „Einrichten“ tippen.",
                fontSize = 13.sp,
                color = Color(0xFF78350F),
                lineHeight = 18.sp
            )
            OutlinedButton(
                onClick = onOpenAppInfo,
                shape = RoundedCornerShape(10.dp),
                border = BorderStroke(1.dp, AssistiveAmber)
            ) {
                Text(
                    text = if (isEn) "Open app info" else "App-Info öffnen",
                    fontSize = 13.sp,
                    color = Color(0xFF78350F),
                    fontWeight = FontWeight.SemiBold
                )
            }
            Text(
                text = if (isEn)
                    "Tip: Do this BEFORE removing the Android screen lock – Android asks for the code here."
                else
                    "Tipp: Das VOR dem Entfernen der Android-Sperre erledigen – Android fragt hier nach dem Handy-Code.",
                fontSize = 12.sp,
                color = Color(0xFF92400E),
                lineHeight = 16.sp
            )
        }
    }
}

/**
 * Einrichtungsschritt "Handy vorbereiten".
 */
@Composable
internal fun SystemSetupStep(
    isEn: Boolean,
    needCalls: Boolean,
    needSms: Boolean,
    needLocation: Boolean,
    useChildLockscreen: Boolean,
    onToggleChildLockscreen: (Boolean) -> Unit,
    onNext: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 24.dp, vertical = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally
    ) {
        Spacer(modifier = Modifier.height(6.dp))
        Box(
            modifier = Modifier
                .size(80.dp)
                .clip(CircleShape)
                .background(AssistiveBlueLight),
            contentAlignment = Alignment.Center
        ) {
            Text(text = "🛠️", fontSize = 40.sp)
        }
        Spacer(modifier = Modifier.height(14.dp))
        Text(
            text = if (isEn) "Prepare the phone" else "Handy vorbereiten",
            fontSize = 24.sp,
            fontWeight = FontWeight.Bold,
            color = AssistiveTextPrimary,
            textAlign = TextAlign.Center
        )
        Spacer(modifier = Modifier.height(4.dp))
        Text(
            text = if (isEn)
                "A few Android settings so TEDOKI works properly. Tap \"Set up\" for each point – Android opens a window, you tap, then you come back here automatically or with the back button. Green means done."
            else
                "Ein paar Android-Einstellungen, damit TEDOKI richtig funktioniert. Bei jedem Punkt auf „Einrichten“ tippen – Android öffnet ein Fenster, du tippst dort, danach geht’s automatisch oder mit der Zurück-Taste hierher. Grün heißt erledigt.",
            fontSize = 14.sp,
            color = AssistiveTextSecondary,
            textAlign = TextAlign.Center,
            lineHeight = 19.sp
        )
        Spacer(modifier = Modifier.height(16.dp))

        // Kinder-Sperrbildschirm ja/nein
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = AssistiveSurface),
            border = BorderStroke(1.dp, if (useChildLockscreen) AssistiveBlue else AssistiveBorder),
            modifier = Modifier.fillMaxWidth()
        ) {
            Row(modifier = Modifier.padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                Column(modifier = Modifier.weight(1f)) {
                    Text(
                        text = if (isEn) "Use the TEDOKI lock screen" else "TEDOKI-Sperrbildschirm benutzen",
                        fontSize = 15.sp,
                        fontWeight = FontWeight.Bold,
                        color = AssistiveTextPrimary
                    )
                    Text(
                        text = if (isEn)
                            "With learning clock and simple unlocking. The Android lock is removed for this."
                        else
                            "Mit Lernuhr und kindgerechtem Entsperren. Dafür wird die Android-Sperre entfernt.",
                        fontSize = 12.sp,
                        color = AssistiveTextSecondary
                    )
                }
                Spacer(modifier = Modifier.width(10.dp))
                Switch(
                    checked = useChildLockscreen,
                    onCheckedChange = onToggleChildLockscreen,
                    colors = SwitchDefaults.colors(checkedThumbColor = Color.White, checkedTrackColor = AssistiveBlue)
                )
            }
        }

        if (useChildLockscreen) {
            Spacer(modifier = Modifier.height(8.dp))
            HintCard(
                text = if (isEn)
                    "Good to know: Without the Android lock, the phone itself has no code anymore (fingerprint is also removed). The parent area stays protected by your parent PIN. If the phone is lost, anyone could see photos and messages – please keep that in mind."
                else
                    "Gut zu wissen: Ohne Android-Sperre hat das Handy selbst keinen Code mehr (auch der Fingerabdruck wird entfernt). Der Elternbereich bleibt durch eure Eltern-PIN geschützt. Geht das Handy verloren, könnte jemand Fotos und Nachrichten sehen – bitte im Hinterkopf behalten."
            )
        }

        Spacer(modifier = Modifier.height(14.dp))

        SystemSetupChecklist(
            isEn = isEn,
            needCalls = needCalls,
            needSms = needSms,
            needLocation = needLocation,
            removeSystemLock = useChildLockscreen
        )

        Spacer(modifier = Modifier.height(10.dp))
        Text(
            text = if (isEn)
                "Order matters a little: do the Android lock last. You can finish anything later in the parent area under \"System & default apps\"."
            else
                "Reihenfolge: Die Android-Sperre am besten zuletzt. Alles, was jetzt nicht klappt, kannst du später im Elternbereich unter „System & Standard-Apps“ nachholen.",
            fontSize = 12.sp,
            color = AssistiveTextMuted,
            textAlign = TextAlign.Center,
            lineHeight = 16.sp
        )
        Spacer(modifier = Modifier.height(16.dp))
        Button(
            onClick = onNext,
            shape = RoundedCornerShape(14.dp),
            colors = ButtonDefaults.buttonColors(containerColor = AssistiveBlue),
            modifier = Modifier
                .fillMaxWidth()
                .height(52.dp)
        ) {
            Text(
                text = if (isEn) "Continue" else "Weiter",
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
        }
        Spacer(modifier = Modifier.height(10.dp))
    }
}
