package com.example.ui.setup

import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.GridView
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Quiz
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.TableRows
import androidx.compose.material.icons.filled.Visibility
import androidx.compose.material.icons.filled.VisibilityOff
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Brush
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.layout.ContentScale
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.input.VisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import coil.compose.AsyncImage
import com.example.model.LayoutStyle
import com.example.ui.theme.AssistiveBackground
import com.example.ui.theme.AssistiveBlue
import com.example.ui.theme.AssistiveBlueLight
import com.example.ui.theme.AssistiveBorder
import com.example.ui.theme.AssistiveGreen
import com.example.ui.theme.AssistiveRed
import com.example.ui.theme.AssistiveSurface
import com.example.ui.theme.AssistiveTextMuted
import com.example.ui.theme.AssistiveTextPrimary
import com.example.ui.theme.AssistiveTextSecondary
import com.example.ui.theme.assistiveTextFieldColors

// =====================================================================================
// STEP 8: LAYOUT STYLE (Grid vs. Rows)
// =====================================================================================
@Composable
internal fun LayoutStyleStep(
    isEn: Boolean,
    selectedStyle: LayoutStyle,
    onSelectStyle: (LayoutStyle) -> Unit,
    onNext: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 24.dp, vertical = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.fillMaxWidth()
        ) {
            Spacer(modifier = Modifier.height(10.dp))

            Text(
                text = if (isEn) "Choose Layout" else "Layout auswählen",
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                color = AssistiveTextPrimary,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = if (isEn)
                    "How should tiles be arranged on the home screen?"
                else
                    "Wie sollen die Kacheln auf dem Homescreen angeordnet sein?",
                fontSize = 14.sp,
                color = AssistiveTextSecondary,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(24.dp))

            // Grid Choice Card
            LayoutChoiceCard(
                icon = Icons.Default.GridView,
                title = if (isEn) "Grid (2 Columns)" else "Gitter (Grid)",
                desc = if (isEn)
                    "Large, square tiles in two columns. Ideal for tablets and visual recognition."
                else
                    "Große, quadratische Kacheln in zwei Spalten. Ideal für Tablets und visuelle Erkennung.",
                isSelected = selectedStyle == LayoutStyle.GRID,
                onClick = { onSelectStyle(LayoutStyle.GRID) },
                tag = "layout_choice_grid"
            )

            Spacer(modifier = Modifier.height(16.dp))

            // Rows Choice Card
            LayoutChoiceCard(
                icon = Icons.Default.TableRows,
                title = if (isEn) "Rows (List)" else "Reihen (Rows)",
                desc = if (isEn)
                    "Full-width rows with large icon and title side-by-side. Highly readable."
                else
                    "Große Zeilen über die volle Breite mit Icon und Text nebeneinander. Besonders gut lesbar.",
                isSelected = selectedStyle == LayoutStyle.ROWS,
                onClick = { onSelectStyle(LayoutStyle.ROWS) },
                tag = "layout_choice_rows"
            )
        }

        Spacer(modifier = Modifier.height(20.dp))

        Button(
            onClick = onNext,
            shape = RoundedCornerShape(16.dp),
            colors = ButtonDefaults.buttonColors(containerColor = AssistiveBlue),
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp)
                .testTag("layout_next_button")
        ) {
            Text(
                text = if (isEn) "Next: Set Parent PIN" else "Weiter: Eltern-PIN festlegen",
                fontSize = 17.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
        }
    }
}

@Composable
internal fun LayoutChoiceCard(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    title: String,
    desc: String,
    isSelected: Boolean,
    onClick: () -> Unit,
    tag: String
) {
    Card(
        shape = RoundedCornerShape(20.dp),
        colors = CardDefaults.cardColors(containerColor = AssistiveSurface),
        border = BorderStroke(
            2.dp,
            if (isSelected) AssistiveBlue else AssistiveBorder
        ),
        elevation = CardDefaults.cardElevation(defaultElevation = if (isSelected) 4.dp else 1.dp),
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(20.dp))
            .clickable { onClick() }
            .testTag(tag)
    ) {
        Row(
            modifier = Modifier.padding(20.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(56.dp)
                    .clip(CircleShape)
                    .background(if (isSelected) AssistiveBlueLight else AssistiveBackground),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = if (isSelected) AssistiveBlue else AssistiveTextSecondary,
                    modifier = Modifier.size(32.dp)
                )
            }

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = AssistiveTextPrimary
                )
                Spacer(modifier = Modifier.height(4.dp))
                Text(
                    text = desc,
                    fontSize = 13.sp,
                    color = AssistiveTextSecondary,
                    lineHeight = 18.sp
                )
            }

            if (isSelected) {
                Icon(
                    imageVector = Icons.Default.CheckCircle,
                    contentDescription = "Selected",
                    tint = AssistiveBlue,
                    modifier = Modifier.size(28.dp)
                )
            }
        }
    }
}

// =====================================================================================
// STEP 9: PARENT PIN (Enter 2x to verify)
// =====================================================================================
@Composable
internal fun ParentPinStep(
    isEn: Boolean,
    pin: String,
    onPinChange: (String) -> Unit,
    pinConfirm: String,
    onConfirmChange: (String) -> Unit,
    pinVisible: Boolean,
    onToggleVisibility: () -> Unit,
    onNext: () -> Unit
) {
    val is4Digits = pin.length == 4 && pin.all { it.isDigit() }
    val isConfirm4Digits = pinConfirm.length == 4 && pinConfirm.all { it.isDigit() }
    val isMatch = is4Digits && isConfirm4Digits && pin == pinConfirm

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 24.dp, vertical = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.fillMaxWidth()
        ) {
            Spacer(modifier = Modifier.height(10.dp))

            Box(
                modifier = Modifier
                    .size(80.dp)
                    .clip(CircleShape)
                    .background(AssistiveBlueLight),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Lock,
                    contentDescription = null,
                    tint = AssistiveBlue,
                    modifier = Modifier.size(44.dp)
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            Text(
                text = if (isEn) "Set Parent PIN" else "Eltern-PIN festlegen",
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                color = AssistiveTextPrimary,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = if (isEn)
                    "Secure the parent area and unlock features for your child after the quiz."
                else
                    "Sichere den Elternbereich und schalte damit Funktionen nach dem Quiz für dein Kind frei.",
                fontSize = 14.sp,
                color = AssistiveTextSecondary,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(24.dp))

            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = AssistiveSurface),
                border = BorderStroke(1.dp, AssistiveBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text(
                        text = if (isEn) "1. New 4-digit PIN:" else "1. Neue 4-stellige PIN:",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = AssistiveTextPrimary
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = pin,
                        onValueChange = {
                            if (it.length <= 4 && it.all { char -> char.isDigit() }) {
                                onPinChange(it)
                            }
                        },
                        placeholder = { Text(if (isEn) "4 digits (e.g. 2468)" else "4 Ziffern (z. B. 2468)") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                        visualTransformation = if (pinVisible) VisualTransformation.None else PasswordVisualTransformation(),
                        shape = RoundedCornerShape(14.dp),
                        colors = assistiveTextFieldColors(),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("setup_pin_field"),
                        trailingIcon = {
                            IconButton(onClick = onToggleVisibility) {
                                Icon(
                                    imageVector = if (pinVisible) Icons.Default.VisibilityOff else Icons.Default.Visibility,
                                    contentDescription = if (isEn) "Show PIN" else "PIN anzeigen"
                                )
                            }
                        }
                    )

                    Spacer(modifier = Modifier.height(18.dp))

                    Text(
                        text = if (isEn) "2. Repeat PIN to confirm:" else "2. PIN zur Bestätigung wiederholen:",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = AssistiveTextPrimary
                    )

                    Spacer(modifier = Modifier.height(8.dp))

                    OutlinedTextField(
                        value = pinConfirm,
                        onValueChange = {
                            if (it.length <= 4 && it.all { char -> char.isDigit() }) {
                                onConfirmChange(it)
                            }
                        },
                        placeholder = { Text(if (isEn) "Repeat PIN" else "PIN wiederholen") },
                        singleLine = true,
                        keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                        visualTransformation = if (pinVisible) VisualTransformation.None else PasswordVisualTransformation(),
                        shape = RoundedCornerShape(14.dp),
                        colors = assistiveTextFieldColors(),
                        modifier = Modifier
                            .fillMaxWidth()
                            .testTag("setup_pin_confirm_field")
                    )

                    Spacer(modifier = Modifier.height(14.dp))

                    // Real-time verification feedback
                    if (pin.length == 4 && pinConfirm.length == 4) {
                        if (isMatch) {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(
                                    Icons.Default.CheckCircle,
                                    contentDescription = null,
                                    tint = AssistiveGreen,
                                    modifier = Modifier.size(20.dp)
                                )
                                Text(
                                    text = if (isEn) "PINs match ✓" else "PINs stimmen überein ✓",
                                    color = AssistiveGreen,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp
                                )
                            }
                        } else {
                            Row(
                                verticalAlignment = Alignment.CenterVertically,
                                horizontalArrangement = Arrangement.spacedBy(8.dp)
                            ) {
                                Icon(
                                    Icons.Default.Warning,
                                    contentDescription = null,
                                    tint = AssistiveRed,
                                    modifier = Modifier.size(20.dp)
                                )
                                Text(
                                    text = if (isEn) "PINs do not match!" else "PINs stimmen nicht überein!",
                                    color = AssistiveRed,
                                    fontWeight = FontWeight.Bold,
                                    fontSize = 13.sp
                                )
                            }
                        }
                    } else {
                        Text(
                            text = if (isEn) "Please enter exactly 4 digits." else "Bitte genau 4 Ziffern eingeben.",
                            fontSize = 12.sp,
                            color = AssistiveTextMuted
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        Button(
            onClick = onNext,
            enabled = isMatch,
            shape = RoundedCornerShape(16.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = AssistiveBlue,
                disabledContainerColor = AssistiveBorder
            ),
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp)
                .testTag("pin_next_button")
        ) {
            Text(
                text = if (isMatch) {
                    if (isEn) "Save PIN & Continue" else "PIN speichern & Weiter"
                } else {
                    if (isEn) "Please enter a valid 4-digit PIN" else "Bitte gültige 4-stellige PIN eingeben"
                },
                fontSize = 16.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
        }
    }
}

// =====================================================================================
// STEP 10: COMPLETION & CELEBRATION
// =====================================================================================
@Composable
internal fun CompletionStep(
    isEn: Boolean,
    childName: String,
    childAvatar: String,
    includeCamera: Boolean,
    includePhotos: Boolean,
    includeCalls: Boolean,
    sosEnabled: Boolean,
    emergencyNumber: String,
    layoutStyle: LayoutStyle,
    onFinish: () -> Unit
) {
    val preset = PRESET_AVATARS.find { it.id == childAvatar }
    val isCustomPhoto = childAvatar.startsWith("content://") || childAvatar.startsWith("file://")

    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 24.dp, vertical = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.fillMaxWidth()
        ) {
            Spacer(modifier = Modifier.height(16.dp))

            // Big celebratory hero badge
            Box(
                modifier = Modifier
                    .size(100.dp)
                    .clip(CircleShape)
                    .background(
                        Brush.linearGradient(
                            listOf(Color(0xFFF59E0B), Color(0xFFEF4444), Color(0xFFEC4899))
                        )
                    ),
                contentAlignment = Alignment.Center
            ) {
                Text(text = "🎉", fontSize = 52.sp)
            }

            Spacer(modifier = Modifier.height(18.dp))

            Text(
                text = if (isEn) "All set for $childName!" else "Alles bereit für $childName!",
                fontSize = 26.sp,
                fontWeight = FontWeight.Bold,
                color = AssistiveTextPrimary,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = if (isEn)
                    "Initial setup is complete. We wish you and your child a joyful and safe journey exploring the smartphone world together!"
                else
                    "Die Ersteinrichtung ist erfolgreich abgeschlossen. Wir wünschen dir und deinem Kind viel Freude beim gemeinsamen Erkunden der Smartphone-Welt!",
                fontSize = 15.sp,
                color = AssistiveTextSecondary,
                textAlign = TextAlign.Center,
                lineHeight = 22.sp
            )

            Spacer(modifier = Modifier.height(24.dp))

            // Summary Card
            Card(
                shape = RoundedCornerShape(20.dp),
                colors = CardDefaults.cardColors(containerColor = AssistiveSurface),
                border = BorderStroke(1.dp, AssistiveBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text(
                        text = if (isEn) "Summary of chosen settings:" else "Zusammenfassung der Einstellungen:",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = AssistiveTextMuted
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    Row(
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(10.dp)
                    ) {
                        Box(
                            modifier = Modifier
                                .size(36.dp)
                                .clip(CircleShape)
                                .background(Color(preset?.bgHex ?: 0xFF3B82F6)),
                            contentAlignment = Alignment.Center
                        ) {
                            if (isCustomPhoto) {
                                AsyncImage(
                                    model = childAvatar,
                                    contentDescription = "Avatar",
                                    contentScale = ContentScale.Crop,
                                    modifier = Modifier.fillMaxSize().clip(CircleShape)
                                )
                            } else {
                                Text(text = preset?.emoji ?: "🦁", fontSize = 20.sp)
                            }
                        }

                        Text(
                            text = if (isEn) "Profile: $childName" else "Profil: $childName",
                            fontWeight = FontWeight.Bold,
                            fontSize = 15.sp,
                            color = AssistiveTextPrimary
                        )
                    }

                    Spacer(modifier = Modifier.height(10.dp))

                    val activeFeatures = mutableListOf<String>()
                    if (includeCamera) activeFeatures.add(if (isEn) "Camera" else "Kamera")
                    if (includePhotos) activeFeatures.add(if (isEn) "Photos" else "Fotos")
                    if (includeCalls) activeFeatures.add(if (isEn) "Calls" else "Anrufen")

                    Text(
                        text = if (isEn)
                            "• Features: ${activeFeatures.joinToString(", ")} (initially protected)"
                        else
                            "• Funktionen: ${activeFeatures.joinToString(", ")} (anfangs geschützt)",
                        fontSize = 13.sp,
                        color = AssistiveTextSecondary
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    Text(
                        text = if (sosEnabled) {
                            if (isEn) "• SOS Emergency: Active ($emergencyNumber)" else "• SOS-Notruf: Aktiv ($emergencyNumber)"
                        } else {
                            if (isEn) "• SOS Emergency: Disabled" else "• SOS-Notruf: Deaktiviert"
                        },
                        fontSize = 13.sp,
                        color = AssistiveTextSecondary
                    )

                    Spacer(modifier = Modifier.height(4.dp))

                    Text(
                        text = if (isEn) {
                            "• Layout: ${if (layoutStyle == LayoutStyle.GRID) "Grid (2 columns)" else "Rows"}"
                        } else {
                            "• Layout: ${if (layoutStyle == LayoutStyle.GRID) "Gitter (2 Spalten)" else "Reihen"}"
                        },
                        fontSize = 13.sp,
                        color = AssistiveTextSecondary
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(24.dp))

        Button(
            onClick = onFinish,
            shape = RoundedCornerShape(16.dp),
            colors = ButtonDefaults.buttonColors(containerColor = AssistiveGreen),
            modifier = Modifier
                .fillMaxWidth()
                .height(60.dp)
                .testTag("setup_finish_button")
        ) {
            Row(
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.spacedBy(10.dp)
            ) {
                Icon(
                    imageVector = Icons.Default.Star,
                    contentDescription = null,
                    tint = Color.White
                )
                Text(
                    text = if (isEn) "Launch TEDOKI Kids Launcher" else "TEDOKI Kids Launcher starten",
                    fontSize = 18.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color.White
                )
            }
        }
    }
}
