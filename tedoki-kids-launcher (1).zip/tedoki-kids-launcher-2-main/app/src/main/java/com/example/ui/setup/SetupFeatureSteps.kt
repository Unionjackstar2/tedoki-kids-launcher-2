package com.example.ui.setup

import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.foundation.verticalScroll
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Email
import androidx.compose.material.icons.filled.Image
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Quiz
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.ui.theme.AssistiveAmber
import com.example.ui.theme.AssistiveAmberLight
import com.example.ui.theme.AssistiveBlue
import com.example.ui.theme.AssistiveBlueLight
import com.example.ui.theme.AssistiveBorder
import com.example.ui.theme.AssistivePurple
import com.example.ui.theme.AssistivePurpleLight
import com.example.ui.theme.AssistiveSurface
import com.example.ui.theme.AssistiveTextPrimary
import com.example.ui.theme.AssistiveTextSecondary
import com.example.ui.theme.assistiveTextFieldColors

// =====================================================================================
// STEP 5: INITIAL FEATURE SELECTION (Camera, Photos, Calls & first 2 contacts)
// =====================================================================================
@Composable
internal fun InitialFeatureSelectionStep(
    isEn: Boolean,
    includeSms: Boolean,
    onToggleSms: (Boolean) -> Unit,
    includeCalls: Boolean,
    onToggleCalls: (Boolean) -> Unit,
    includeCamera: Boolean,
    onToggleCamera: (Boolean) -> Unit,
    includePhotos: Boolean,
    onTogglePhotos: (Boolean) -> Unit,
    onNext: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 24.dp, vertical = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.fillMaxWidth()
        ) {
            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = if (isEn) "Select Initial Apps" else "Erste Apps auswählen",
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                color = AssistiveTextPrimary,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = if (isEn)
                    "Choose which initial core apps should appear on the home screen."
                else
                    "Wähle aus, welche ersten Apps auf dem Startbildschirm erscheinen sollen.",
                fontSize = 14.sp,
                color = AssistiveTextSecondary,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(14.dp))

            // Important callout: Selection != already unlocked
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = AssistiveAmberLight),
                border = BorderStroke(1.dp, AssistiveAmber),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Lock,
                        contentDescription = null,
                        tint = AssistiveAmber,
                        modifier = Modifier.size(24.dp)
                    )
                    Text(
                        text = if (isEn)
                            "Important: Features start locked to protect your child. You will unlock them together later via quiz."
                        else
                            "Wichtig: Die Funktionen starten zum Schutz deines Kindes gesperrt. Du schaltest sie später gemeinsam per Quiz frei.",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Medium,
                        color = Color(0xFF78350F),
                        lineHeight = 18.sp
                    )
                }
            }

            Spacer(modifier = Modifier.height(18.dp))

            // 1. Nachrichten (SMS) Toggle
            FeatureToggleCard(
                icon = Icons.Default.Email,
                iconBg = 0xFF6366F1,
                title = if (isEn) "Messages" else "Nachrichten",
                desc = if (isEn) "Send & receive text messages safely" else "Sicher Textnachrichten senden & empfangen",
                checked = includeSms,
                onCheckedChange = onToggleSms,
                tag = "feature_toggle_sms"
            )

            Spacer(modifier = Modifier.height(10.dp))

            // 2. Telefonie Toggle
            FeatureToggleCard(
                icon = Icons.Default.Phone,
                iconBg = 0xFF059669,
                title = if (isEn) "Phone" else "Telefonie",
                desc = if (isEn) "Call saved contacts with large buttons" else "Hinterlegte Kontakte einfach anrufen",
                checked = includeCalls,
                onCheckedChange = onToggleCalls,
                tag = "feature_toggle_calls"
            )

            Spacer(modifier = Modifier.height(10.dp))

            // 3. Camera Toggle
            FeatureToggleCard(
                icon = Icons.Default.CameraAlt,
                iconBg = 0xFF2563EB,
                title = if (isEn) "Camera" else "Kamera",
                desc = if (isEn) "Take photos & videos" else "Fotos & Videos aufnehmen",
                checked = includeCamera,
                onCheckedChange = onToggleCamera,
                tag = "feature_toggle_camera"
            )

            Spacer(modifier = Modifier.height(10.dp))

            // 4. Photos Toggle
            FeatureToggleCard(
                icon = Icons.Default.Image,
                iconBg = 0xFFDB2777,
                title = if (isEn) "Photos" else "Fotos",
                desc = if (isEn) "Protected gallery of captured photos" else "Geschützte Galerie der eigenen Aufnahmen",
                checked = includePhotos,
                onCheckedChange = onTogglePhotos,
                tag = "feature_toggle_photos"
            )
        }

        Spacer(modifier = Modifier.height(20.dp))

        val hasAnyFeature = includeSms || includeCalls || includeCamera || includePhotos
        Button(
            onClick = onNext,
            enabled = hasAnyFeature,
            shape = RoundedCornerShape(16.dp),
            colors = ButtonDefaults.buttonColors(
                containerColor = AssistiveBlue,
                disabledContainerColor = AssistiveBorder
            ),
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp)
                .testTag("features_next_button")
        ) {
            Text(
                text = if (hasAnyFeature) {
                    if (isEn) "Next: Set Up Initial Contacts" else "Weiter: Erste Kontakte anlegen"
                } else {
                    if (isEn) "Select at least 1 app" else "Mindestens 1 App wählen"
                },
                fontSize = 17.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
        }
    }
}

@Composable
internal fun InitialContactsSetupStep(
    isEn: Boolean,
    contact1Name: String,
    onContact1NameChange: (String) -> Unit,
    contact1Number: String,
    onContact1NumberChange: (String) -> Unit,
    contact2Name: String,
    onContact2NameChange: (String) -> Unit,
    contact2Number: String,
    onContact2NumberChange: (String) -> Unit,
    onNext: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 24.dp, vertical = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.fillMaxWidth()
        ) {
            Spacer(modifier = Modifier.height(8.dp))

            Text(
                text = if (isEn) "Initial Contacts" else "Erste Kontakte anlegen",
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                color = AssistiveTextPrimary,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(4.dp))

            Text(
                text = if (isEn)
                    "Enter the first contacts (e.g. Mom & Dad). They will appear in the Contacts sub-menu and in the Phone & Messages apps."
                else
                    "Lege hier die ersten Kontakte an (z. B. Mama und Papa). Sie stehen deinem Kind in der Telefon- & Nachrichten-App zur Verfügung und werden im Untermenü des Elterndashboards gespeichert.",
                fontSize = 14.sp,
                color = AssistiveTextSecondary,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(18.dp))

            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = AssistiveSurface),
                border = BorderStroke(1.dp, AssistiveBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(16.dp)) {
                    Text(
                        text = if (isEn) "1st Contact (e.g. Mom):" else "1. Kontakt (z. B. Mama):",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = AssistiveTextPrimary
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = contact1Name,
                            onValueChange = onContact1NameChange,
                            placeholder = { Text(if (isEn) "Mom" else "Mama") },
                            singleLine = true,
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(12.dp),
                            colors = assistiveTextFieldColors()
                        )
                        OutlinedTextField(
                            value = contact1Number,
                            onValueChange = onContact1NumberChange,
                            placeholder = { Text("0170 1234567") },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                            modifier = Modifier.weight(1.2f),
                            shape = RoundedCornerShape(12.dp),
                            colors = assistiveTextFieldColors()
                        )
                    }

                    Spacer(modifier = Modifier.height(14.dp))

                    Text(
                        text = if (isEn) "2nd Contact (e.g. Dad or Grandma):" else "2. Kontakt (z. B. Papa oder Oma):",
                        fontSize = 13.sp,
                        fontWeight = FontWeight.Bold,
                        color = AssistiveTextPrimary
                    )
                    Spacer(modifier = Modifier.height(6.dp))
                    Row(
                        modifier = Modifier.fillMaxWidth(),
                        horizontalArrangement = Arrangement.spacedBy(8.dp)
                    ) {
                        OutlinedTextField(
                            value = contact2Name,
                            onValueChange = onContact2NameChange,
                            placeholder = { Text(if (isEn) "Dad" else "Papa") },
                            singleLine = true,
                            modifier = Modifier.weight(1f),
                            shape = RoundedCornerShape(12.dp),
                            colors = assistiveTextFieldColors()
                        )
                        OutlinedTextField(
                            value = contact2Number,
                            onValueChange = onContact2NumberChange,
                            placeholder = { Text("0171 7654321") },
                            singleLine = true,
                            keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.Phone),
                            modifier = Modifier.weight(1.2f),
                            shape = RoundedCornerShape(12.dp),
                            colors = assistiveTextFieldColors()
                        )
                    }
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        Button(
            onClick = onNext,
            shape = RoundedCornerShape(16.dp),
            colors = ButtonDefaults.buttonColors(containerColor = AssistiveBlue),
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp)
                .testTag("contacts_next_button")
        ) {
            Text(
                text = if (isEn) "Next: Explore Parent Dashboard" else "Weiter: Elterndashboard entdecken",
                fontSize = 17.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
        }
    }
}

// =====================================================================================
// STEP 6: DASHBOARD INFO (Explaining later additions of apps and features)
// =====================================================================================
@Composable
internal fun DashboardInfoStep(
    isEn: Boolean,
    onNext: () -> Unit
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .verticalScroll(rememberScrollState())
            .padding(horizontal = 24.dp, vertical = 16.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Column(
            horizontalAlignment = Alignment.CenterHorizontally,
            modifier = Modifier.fillMaxWidth()
        ) {
            Spacer(modifier = Modifier.height(10.dp))

            Box(
                modifier = Modifier
                    .size(80.dp)
                    .clip(CircleShape)
                    .background(AssistivePurpleLight),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Apps,
                    contentDescription = null,
                    tint = AssistivePurple,
                    modifier = Modifier.size(44.dp)
                )
            }

            Spacer(modifier = Modifier.height(14.dp))

            Text(
                text = if (isEn) "Expandable Later" else "Später erweiterbar",
                fontSize = 24.sp,
                fontWeight = FontWeight.Bold,
                color = AssistiveTextPrimary,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(6.dp))

            Text(
                text = if (isEn)
                    "Add more apps & features anytime in the Parent Dashboard."
                else
                    "Weitere Apps & Funktionen jederzeit im Elterndashboard hinzufügen.",
                fontSize = 14.sp,
                color = AssistiveTextSecondary,
                textAlign = TextAlign.Center
            )

            Spacer(modifier = Modifier.height(20.dp))

            Card(
                shape = RoundedCornerShape(18.dp),
                colors = CardDefaults.cardColors(containerColor = AssistiveSurface),
                border = BorderStroke(1.dp, AssistiveBorder),
                modifier = Modifier.fillMaxWidth()
            ) {
                Column(modifier = Modifier.padding(18.dp)) {
                    Text(
                        text = if (isEn)
                            "For the start, the core features are enough. In the protected parent area, you can gradually unlock more apps:"
                        else
                            "Für den Start genügen die Grundfunktionen. Im geschützten Elternbereich kannst du später nach und nach weitere Apps freischalten:",
                        fontSize = 14.sp,
                        color = AssistiveTextPrimary,
                        lineHeight = 20.sp
                    )

                    Spacer(modifier = Modifier.height(16.dp))

                    DashboardFeatureExampleRow(
                        icon = "🌐",
                        title = if (isEn) "Safe Internet" else "Sicheres Internet",
                        desc = if (isEn)
                            "Kid-friendly web browser with whitelist for PBS Kids, BBC Bitesize, Kiddle, etc."
                        else
                            "Kindgerechter Web-Browser mit Whitelist für Die Maus, KiKA, FragFINN etc."
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    DashboardFeatureExampleRow(
                        icon = "💬",
                        title = if (isEn) "Messenger & WhatsApp" else "Messenger & WhatsApp",
                        desc = if (isEn)
                            "Dedicated chat apps with educational quiz on privacy & messages."
                        else
                            "Eigene Chat-Apps mit pädagogischem Quiz zu Datenschutz & Nachrichten."
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    DashboardFeatureExampleRow(
                        icon = "🎧",
                        title = if (isEn) "Audiobooks & Music" else "Hörspiele & Musik",
                        desc = if (isEn)
                            "Kids streaming like Spotify Kids or audiobook apps."
                        else
                            "Kinder-Streaming wie Spotify Kids, Tigerbox oder Hörspiel-Apps."
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    DashboardFeatureExampleRow(
                        icon = "📚",
                        title = if (isEn) "Learning & School Apps" else "Lern- & Schul-Apps",
                        desc = if (isEn)
                            "Math apps, learning tools, or any apps installed on the device."
                        else
                            "Anton, Mathe-Apps oder andere auf dem Smartphone installierte Apps."
                    )

                    Spacer(modifier = Modifier.height(12.dp))

                    DashboardFeatureExampleRow(
                        icon = "👥",
                        title = if (isEn) "More Contacts" else "Weitere Kontakte",
                        desc = if (isEn)
                            "Grandparents, siblings, and friends as quick-dial tiles."
                        else
                            "Oma, Opa, Geschwister und Freunde als Schnellwahl-Kacheln."
                    )
                }
            }

            Spacer(modifier = Modifier.height(16.dp))

            // Blue Info Note
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = AssistiveBlueLight),
                modifier = Modifier.fillMaxWidth()
            ) {
                Row(
                    modifier = Modifier.padding(14.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(10.dp)
                ) {
                    Icon(
                        imageVector = Icons.Default.Info,
                        contentDescription = null,
                        tint = AssistiveBlue,
                        modifier = Modifier.size(24.dp)
                    )
                    Text(
                        text = if (isEn)
                            "Every newly added app automatically goes through the educational unlock routine before first use."
                        else
                            "Jede neu hinzugefügte App durchläuft vor der ersten Nutzung automatisch die kindgerechte Freischalt-Routine.",
                        fontSize = 13.sp,
                        color = Color(0xFF1E3A8A),
                        lineHeight = 18.sp
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(20.dp))

        Button(
            onClick = onNext,
            shape = RoundedCornerShape(16.dp),
            colors = ButtonDefaults.buttonColors(containerColor = AssistiveBlue),
            modifier = Modifier
                .fillMaxWidth()
                .height(56.dp)
                .testTag("dashboard_info_next_button")
        ) {
            Text(
                text = if (isEn) "Next: Setup Emergency SOS" else "Weiter: Notfallfunktion einrichten",
                fontSize = 17.sp,
                fontWeight = FontWeight.Bold,
                color = Color.White
            )
        }
    }
}

@Composable
internal fun DashboardFeatureExampleRow(
    icon: String,
    title: String,
    desc: String
) {
    Row(
        verticalAlignment = Alignment.CenterVertically,
        horizontalArrangement = Arrangement.spacedBy(12.dp),
        modifier = Modifier.fillMaxWidth()
    ) {
        Text(text = icon, fontSize = 24.sp)
        Column(modifier = Modifier.weight(1f)) {
            Text(
                text = title,
                fontSize = 14.sp,
                fontWeight = FontWeight.Bold,
                color = AssistiveTextPrimary
            )
            Text(
                text = desc,
                fontSize = 12.sp,
                color = AssistiveTextSecondary,
                lineHeight = 16.sp
            )
        }
    }
}

@Composable
internal fun FeatureToggleCard(
    icon: androidx.compose.ui.graphics.vector.ImageVector,
    iconBg: Long,
    title: String,
    desc: String,
    checked: Boolean,
    onCheckedChange: (Boolean) -> Unit,
    tag: String
) {
    Card(
        shape = RoundedCornerShape(16.dp),
        colors = CardDefaults.cardColors(containerColor = AssistiveSurface),
        border = BorderStroke(1.dp, if (checked) Color(iconBg) else AssistiveBorder),
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(16.dp))
            .clickable { onCheckedChange(!checked) }
            .testTag(tag)
    ) {
        Row(
            modifier = Modifier.padding(14.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(46.dp)
                    .clip(CircleShape)
                    .background(Color(iconBg)),
                contentAlignment = Alignment.Center
            ) {
                Icon(
                    imageVector = icon,
                    contentDescription = null,
                    tint = Color.White,
                    modifier = Modifier.size(26.dp)
                )
            }

            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = title,
                    fontSize = 16.sp,
                    fontWeight = FontWeight.Bold,
                    color = AssistiveTextPrimary
                )
                Text(
                    text = desc,
                    fontSize = 12.sp,
                    color = AssistiveTextSecondary
                )
            }

            Switch(
                checked = checked,
                onCheckedChange = onCheckedChange,
                colors = SwitchDefaults.colors(
                    checkedThumbColor = Color.White,
                    checkedTrackColor = Color(iconBg)
                )
            )
        }
    }
}
