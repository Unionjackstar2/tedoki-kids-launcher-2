# Keine eigenen Regeln nötig, solange isMinifyEnabled = false ist.
