package com.example.ui.components

import androidx.compose.animation.core.Spring
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.spring
import androidx.compose.foundation.Indication
import androidx.compose.foundation.LocalIndication
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.interaction.collectIsPressedAsState
import androidx.compose.runtime.Composable
import androidx.compose.runtime.State
import androidx.compose.runtime.getValue
import androidx.compose.runtime.remember
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.graphicsLayer

/**
 * Leichter "Material 3 Expressive"-Effekt: Große Tasten geben beim Drücken federnd nach
 * und springen beim Loslassen zurück. Größe und Aussehen der Tasten bleiben unverändert.
 */
class PressState internal constructor(
    val interactionSource: MutableInteractionSource,
    val indication: Indication,
    val scale: State<Float>
)

@Composable
fun rememberPressScale(pressedScale: Float = 0.95f): PressState {
    val interactionSource = remember { MutableInteractionSource() }
    val pressed by interactionSource.collectIsPressedAsState()
    val scale = animateFloatAsState(
        targetValue = if (pressed) pressedScale else 1f,
        animationSpec = spring(
            dampingRatio = Spring.DampingRatioMediumBouncy,
            stiffness = Spring.StiffnessMediumLow
        ),
        label = "press_scale"
    )
    val indication = LocalIndication.current
    return remember(interactionSource, indication) { PressState(interactionSource, indication, scale) }
}

/** Zuerst in der Modifier-Kette (vor shadow/clip), damit die ganze Taste mitfedert. */
fun Modifier.pressScale(state: PressState): Modifier = this.graphicsLayer {
    val s = state.scale.value
    scaleX = s
    scaleY = s
}

/** Ersetzt .clickable(...) – nach clip, damit die Welle die runden Ecken behält. */
fun Modifier.pressClickable(state: PressState, enabled: Boolean = true, onClick: () -> Unit): Modifier =
    this.clickable(
        interactionSource = state.interactionSource,
        indication = state.indication,
        enabled = enabled,
        onClick = onClick
    )
