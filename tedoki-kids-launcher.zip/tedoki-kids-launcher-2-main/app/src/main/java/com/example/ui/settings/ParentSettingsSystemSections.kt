package com.example.ui.settings

import androidx.compose.foundation.layout.ColumnScope
import android.provider.Settings
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.automirrored.filled.ArrowForwardIos
import androidx.compose.material.icons.filled.Apps
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.School
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Icon
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.R
import com.example.model.LauncherSettings
import com.example.ui.components.LargeBackButton
import com.example.ui.theme.AssistiveBlue
import com.example.ui.theme.AssistiveBorder
import com.example.ui.theme.AssistiveGreen
import com.example.ui.theme.AssistiveRed
import com.example.ui.theme.AssistiveRedLight
import com.example.ui.theme.AssistiveSurface
import com.example.ui.theme.AssistiveTextPrimary
import com.example.ui.theme.AssistiveTextSecondary

@Composable
internal fun ColumnScope.CommunicationSection(
    currentSettings: LauncherSettings,
    isDark: Boolean,
    onShowEmergencySubScreenChange: (Boolean) -> Unit,
    onShowBrowserSubScreenChange: (Boolean) -> Unit,
    onShowContactsSubScreenChange: (Boolean) -> Unit
) {
        // Section: Communication & Emergency
        SettingsSectionLabel(title = "Telefon, Nachrichten & Notfall")

        // Dedicated Contacts Management Submenu Card
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = AssistiveSurface),
            border = BorderStroke(1.dp, AssistiveBorder),
            modifier = Modifier
                .fillMaxWidth()
                .clickable { onShowContactsSubScreenChange(true) }
                .testTag("open_contacts_submenu")
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(18.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(14.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(if (isDark) Color(0xFF0469A1).copy(alpha = 0.35f) else Color(0xFFE0F2FE)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Phone,
                            contentDescription = null,
                            tint = AssistiveBlue,
                            modifier = Modifier.size(22.dp)
                        )
                    }

                    Column {
                        Text(
                            text = "Kontakte verwalten",
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold,
                            color = AssistiveTextPrimary
                        )
                        Text(
                            text = "${currentSettings.contacts.size} Personen, die dein Kind anrufen und anschreiben kann",
                            fontSize = 13.sp,
                            color = AssistiveTextSecondary
                        )
                    }
                }

                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowForwardIos,
                    contentDescription = null,
                    tint = Color(0xFF94A3B8),
                    modifier = Modifier.size(16.dp)
                )
            }
        }

        // Dedicated SOS Emergency Submenu Entry Card
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = AssistiveSurface),
            border = BorderStroke(1.dp, AssistiveBorder),
            modifier = Modifier
                .fillMaxWidth()
                .clickable { onShowEmergencySubScreenChange(true) }
                .testTag("open_emergency_submenu")
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(18.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(14.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(
                                if (currentSettings.showSosButton) {
                                    if (isDark) Color(0xFF7F1D1D).copy(alpha = 0.4f) else Color(0xFFFEE2E2)
                                } else {
                                    if (isDark) Color(0xFF0F172A) else Color(0xFFF1F5F9)
                                }
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Warning,
                            contentDescription = null,
                            tint = if (currentSettings.showSosButton) Color(0xFFDC2626) else Color.Gray,
                            modifier = Modifier.size(22.dp)
                        )
                    }

                    Column {
                        Text(
                            text = stringResource(R.string.emergency_submenu_title),
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold,
                            color = AssistiveTextPrimary
                        )
                        Text(
                            text = if (currentSettings.showSosButton) {
                                "${currentSettings.emergencyNumber} • ${currentSettings.emergencyContactName}"
                            } else {
                                stringResource(R.string.settings_sos_toggle_desc)
                            },
                            fontSize = 13.sp,
                            color = AssistiveTextSecondary
                        )
                    }
                }

                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowForwardIos,
                    contentDescription = null,
                    tint = Color(0xFF94A3B8),
                    modifier = Modifier.size(16.dp)
                )
            }
        }

        // Dedicated Kid Browser Submenu Entry Card ("Surfen")
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = AssistiveSurface),
            border = BorderStroke(1.dp, AssistiveBorder),
            modifier = Modifier
                .fillMaxWidth()
                .clickable { onShowBrowserSubScreenChange(true) }
                .testTag("open_browser_submenu")
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(18.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(14.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(if (isDark) Color(0xFF0369A1).copy(alpha = 0.35f) else Color(0xFFE0F2FE)),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(text = "🌐", fontSize = 22.sp)
                    }

                    Column {
                        Text(
                            text = stringResource(R.string.browser_settings_title),
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold,
                            color = AssistiveTextPrimary
                        )
                        Text(
                            text = "${currentSettings.allowedWebsites.size} erlaubte Webseiten – alles andere bleibt gesperrt",
                            fontSize = 13.sp,
                            color = AssistiveTextSecondary
                        )
                    }
                }

                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowForwardIos,
                    contentDescription = null,
                    tint = Color(0xFF94A3B8),
                    modifier = Modifier.size(16.dp)
                )
            }
        }
}

@Composable
internal fun ColumnScope.SecuritySection(
    currentSettings: LauncherSettings,
    isDark: Boolean,
    onShowPinSubScreenChange: (Boolean) -> Unit,
    onShowLockscreenSubScreenChange: (Boolean) -> Unit,
    onShowPedagogySubScreenChange: (Boolean) -> Unit
) {
        // Section: Security & Child Protection
        SettingsSectionLabel(title = "Schutz & Freischaltungen")

        // Dedicated Parent PIN & Security Submenu Entry Card
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = AssistiveSurface),
            border = BorderStroke(1.dp, AssistiveBorder),
            modifier = Modifier
                .fillMaxWidth()
                .clickable { onShowPinSubScreenChange(true) }
                .testTag("open_pin_submenu")
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(18.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(14.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(if (isDark) Color(0xFF78350F).copy(alpha = 0.4f) else Color(0xFFFEF3C7)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Lock,
                            contentDescription = null,
                            tint = Color(0xFFD97706),
                            modifier = Modifier.size(22.dp)
                        )
                    }

                    Column {
                        Text(
                            text = stringResource(R.string.settings_pin_submenu_title),
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold,
                            color = AssistiveTextPrimary
                        )
                        Text(
                            text = "Der Code, der diesen Elternbereich schützt",
                            fontSize = 13.sp,
                            color = AssistiveTextSecondary
                        )
                    }
                }

                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowForwardIos,
                    contentDescription = null,
                    tint = Color(0xFF94A3B8),
                    modifier = Modifier.size(16.dp)
                )
            }
        }

        // Dedicated Kinder-Sperrbildschirm (Lockscreen) Submenu Entry Card
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = AssistiveSurface),
            border = BorderStroke(1.dp, AssistiveBorder),
            modifier = Modifier
                .fillMaxWidth()
                .clickable { onShowLockscreenSubScreenChange(true) }
                .testTag("open_lockscreen_submenu")
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(18.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(14.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(
                                if (currentSettings.enableLockscreen) {
                                    if (isDark) Color(0xFF064E3B).copy(alpha = 0.4f) else Color(0xFFD1FAE5)
                                } else {
                                    if (isDark) Color(0xFF1E293B) else Color(0xFFF1F5F9)
                                }
                            ),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Lock,
                            contentDescription = null,
                            tint = if (currentSettings.enableLockscreen) AssistiveGreen else AssistiveTextSecondary,
                            modifier = Modifier.size(22.dp)
                        )
                    }

                    Column {
                        Text(
                            text = "Sperrbildschirm",
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold,
                            color = AssistiveTextPrimary
                        )
                        Text(
                            text = if (currentSettings.enableLockscreen) {
                                val clockType = if (currentSettings.lockscreenClockStyle == com.example.model.LockscreenClockStyle.ANALOG_CONNI) "Lernuhr" else "Digitale Uhr"
                                val mathInfo = if (currentSettings.lockscreenRequireMathProblem) " • Mit Rechenaufgabe" else ""
                                "Aktiviert • $clockType$mathInfo"
                            } else {
                                "Deaktiviert • Tippen zum Konfigurieren"
                            },
                            fontSize = 13.sp,
                            color = if (currentSettings.enableLockscreen) AssistiveGreen else AssistiveTextSecondary
                        )
                    }
                }

                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowForwardIos,
                    contentDescription = null,
                    tint = Color(0xFF94A3B8),
                    modifier = Modifier.size(16.dp)
                )
            }
        }

        // Dedicated Pedagogy & App Unlocks Submenu Entry Card
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = AssistiveSurface),
            border = BorderStroke(1.dp, AssistiveBorder),
            modifier = Modifier
                .fillMaxWidth()
                .clickable { onShowPedagogySubScreenChange(true) }
                .testTag("open_pedagogy_submenu")
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(18.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(14.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(if (isDark) Color(0xFF3B0764).copy(alpha = 0.4f) else Color(0xFFF3E8FF)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.School,
                            contentDescription = null,
                            tint = Color(0xFF9333EA),
                            modifier = Modifier.size(22.dp)
                        )
                    }

                    Column {
                        Text(
                            text = "Quiz & Freischaltungen",
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold,
                            color = AssistiveTextPrimary
                        )
                        Text(
                            text = "Welche Apps frei sind und welches Quiz zu welcher App gehört",
                            fontSize = 13.sp,
                            color = AssistiveTextSecondary
                        )
                    }
                }

                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowForwardIos,
                    contentDescription = null,
                    tint = Color(0xFF94A3B8),
                    modifier = Modifier.size(16.dp)
                )
            }
        }
}

@Composable
internal fun ColumnScope.SystemSection(
    isDark: Boolean,
    safeReturnToHome: () -> Unit,
    onShowResetSubScreenChange: (Boolean) -> Unit,
    onShowSystemSubScreenChange: (Boolean) -> Unit
) {
        // Section: System & Device Administration
        SettingsSectionLabel(title = "Handy & System")

        // Dedicated System & Default Apps Submenu Entry Card
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = AssistiveSurface),
            border = BorderStroke(1.dp, AssistiveBorder),
            modifier = Modifier
                .fillMaxWidth()
                .clickable { onShowSystemSubScreenChange(true) }
                .testTag("open_system_submenu")
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(18.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(14.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(if (isDark) Color(0xFF1E293B) else Color(0xFFF1F5F9)),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Settings,
                            contentDescription = null,
                            tint = AssistiveBlue,
                            modifier = Modifier.size(22.dp)
                        )
                    }

                    Column {
                        Text(
                            text = "System & Standard-Apps",
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold,
                            color = AssistiveTextPrimary
                        )
                        Text(
                            text = "Handy-Check, Telefon- und SMS-App, Uhr & Kalender",
                            fontSize = 13.sp,
                            color = AssistiveTextSecondary
                        )
                    }
                }

                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowForwardIos,
                    contentDescription = null,
                    tint = Color(0xFF94A3B8),
                    modifier = Modifier.size(16.dp)
                )
            }
        }

        // Dedicated Reset Submenu Entry Card
        Card(
            shape = RoundedCornerShape(20.dp),
            colors = CardDefaults.cardColors(containerColor = AssistiveSurface),
            border = BorderStroke(1.dp, AssistiveBorder),
            modifier = Modifier
                .fillMaxWidth()
                .clickable { onShowResetSubScreenChange(true) }
                .testTag("open_reset_submenu")
        ) {
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(18.dp),
                verticalAlignment = Alignment.CenterVertically,
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(14.dp),
                    modifier = Modifier.weight(1f)
                ) {
                    Box(
                        modifier = Modifier
                            .size(44.dp)
                            .clip(CircleShape)
                            .background(if (isDark) Color(0xFF7F1D1D).copy(alpha = 0.4f) else AssistiveRedLight),
                        contentAlignment = Alignment.Center
                    ) {
                        Icon(
                            imageVector = Icons.Default.Warning,
                            contentDescription = null,
                            tint = AssistiveRed,
                            modifier = Modifier.size(22.dp)
                        )
                    }

                    Column {
                        Text(
                            text = "TEDOKI zurücksetzen",
                            fontSize = 17.sp,
                            fontWeight = FontWeight.Bold,
                            color = AssistiveTextPrimary
                        )
                        Text(
                            text = "Löscht alle Einstellungen und startet die Einrichtung neu",
                            fontSize = 13.sp,
                            color = AssistiveTextSecondary
                        )
                    }
                }

                Icon(
                    imageVector = Icons.AutoMirrored.Filled.ArrowForwardIos,
                    contentDescription = null,
                    tint = Color(0xFF94A3B8),
                    modifier = Modifier.size(16.dp)
                )
            }
        }

        Spacer(modifier = Modifier.height(14.dp))

        // Return to Simplified Mode button (inside scrollable content at the bottom)
        LargeBackButton(
            onClick = safeReturnToHome,
            text = stringResource(R.string.settings_exit_to_home),
            modifier = Modifier
                .fillMaxWidth()
                .padding(vertical = 8.dp)
        )
}
