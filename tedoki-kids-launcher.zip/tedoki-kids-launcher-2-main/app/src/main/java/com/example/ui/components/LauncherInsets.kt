package com.example.ui.components

import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.displayCutout
import androidx.compose.foundation.layout.navigationBarsIgnoringVisibility
import androidx.compose.foundation.layout.statusBarsIgnoringVisibility
import androidx.compose.foundation.layout.union
import androidx.compose.runtime.Composable
import androidx.compose.ui.platform.LocalDensity
import androidx.compose.ui.unit.Dp
import androidx.compose.ui.unit.dp

/**
 * Minimum height of the in-app status bar ([CustomLauncherStatusBar]).
 */
val LauncherStatusBarMinHeight: Dp = 42.dp

/**
 * Insets that every screen must respect.
 *
 * The launcher hides the real Android system bars (immersive mode) and draws its own
 * [CustomLauncherStatusBar] on top. While the system bars are hidden, `WindowInsets.statusBars`
 * and `WindowInsets.navigationBars` report 0, so content ran underneath the custom bar and the
 * notch / punch-hole camera. Therefore the *IgnoringVisibility variants are used, combined with
 * the display cutout, and the top inset is never smaller than the custom status bar.
 */
val WindowInsets.Companion.launcherSafe: WindowInsets
    @Composable
    get() = WindowInsets.statusBarsIgnoringVisibility
        .union(WindowInsets.navigationBarsIgnoringVisibility)
        .union(WindowInsets.displayCutout)
        .union(WindowInsets(top = LauncherStatusBarMinHeight))

/**
 * Height of the in-app status bar: system status bar / cutout height, but at least [LauncherStatusBarMinHeight].
 */
@Composable
fun launcherStatusBarHeight(): Dp {
    val density = LocalDensity.current
    val topInset = WindowInsets.statusBarsIgnoringVisibility
        .union(WindowInsets.displayCutout)
        .getTop(density)
    return with(density) { topInset.toDp() }.coerceAtLeast(LauncherStatusBarMinHeight)
}
