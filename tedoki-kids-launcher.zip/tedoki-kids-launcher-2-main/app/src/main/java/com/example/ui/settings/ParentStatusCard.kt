package com.example.ui.settings

import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.lifecycle.Lifecycle
import androidx.lifecycle.LifecycleEventObserver
import com.example.model.ButtonType
import com.example.model.LauncherSettings
import com.example.ui.theme.AssistiveAmber
import com.example.ui.theme.AssistiveAmberLight
import com.example.ui.theme.AssistiveGreen
import com.example.ui.theme.AssistiveGreenLight
import com.example.util.SystemSetupHelper
import com.example.util.SystemSetupHelper.Item

/**
 * Ganz oben im Elternbereich: "Ist alles startklar?" – auf einen Blick.
 * Antippen öffnet den Handy-Check (System & Standard-Apps).
 */
@Composable
fun ParentStatusCard(currentSettings: LauncherSettings, onOpenSystem: () -> Unit) {
    val context = LocalContext.current
    val lifecycleOwner = androidx.compose.ui.platform.LocalLifecycleOwner.current
    var tick by remember { mutableIntStateOf(0) }

    DisposableEffect(lifecycleOwner) {
        val observer = LifecycleEventObserver { _, e -> if (e == Lifecycle.Event.ON_RESUME) tick++ }
        lifecycleOwner.lifecycle.addObserver(observer)
        onDispose { lifecycleOwner.lifecycle.removeObserver(observer) }
    }

    val needCalls = currentSettings.buttons.any { it.type == ButtonType.CALL } || currentSettings.showSosButton
    val sosSms = currentSettings.showSosButton && currentSettings.sendSosLocationSms
    val needSms = currentSettings.buttons.any { it.type == ButtonType.SMS } || sosSms

    val open = remember(tick, needCalls, needSms, sosSms, currentSettings.enableLockscreen) {
        val perms = SystemSetupHelper.requiredPermissions(needCalls, needSms, sosSms)
        buildList {
            add(Item.HOME)
            if (needCalls) { add(Item.DIALER); add(Item.FULL_SCREEN_CALLS) }
            if (needSms) add(Item.SMS)
            add(Item.PERMISSIONS)
            if (sosSms) add(Item.LOCATION_ON)
            if (currentSettings.enableLockscreen) add(Item.SYSTEM_LOCK_OFF)
        }.count { !SystemSetupHelper.isDone(context, it, perms) }
    }

    val ok = open == 0
    Card(
        shape = RoundedCornerShape(28.dp),
        colors = CardDefaults.cardColors(containerColor = if (ok) AssistiveGreenLight else AssistiveAmberLight),
        border = BorderStroke(1.dp, if (ok) AssistiveGreen else AssistiveAmber),
        modifier = Modifier
            .fillMaxWidth()
            .clip(RoundedCornerShape(28.dp))
            .clickable(onClick = onOpenSystem)
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.spacedBy(14.dp)
        ) {
            Box(
                modifier = Modifier
                    .size(44.dp)
                    .clip(CircleShape)
                    .background(if (ok) AssistiveGreen else AssistiveAmber),
                contentAlignment = Alignment.Center
            ) {
                Text(text = if (ok) "✓" else "!", fontSize = 22.sp, fontWeight = FontWeight.Bold, color = Color.White)
            }
            Column(modifier = Modifier.weight(1f)) {
                Text(
                    text = if (ok) "Alles startklar" else if (open == 1) "1 Sache fehlt noch" else "$open Sachen fehlen noch",
                    fontSize = 17.sp,
                    fontWeight = FontWeight.Bold,
                    color = Color(0xFF1E293B)
                )
                Text(
                    text = if (ok) "Das Handy ist fertig eingerichtet."
                    else "Antippen – TEDOKI zeigt Schritt für Schritt, was zu tun ist.",
                    fontSize = 13.sp,
                    color = Color(0xFF475569)
                )
            }
        }
    }
}
