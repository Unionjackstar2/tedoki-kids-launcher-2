package com.example.ui.quiz

import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.foundation.layout.windowInsetsPadding
import com.example.ui.components.launcherSafe
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.CameraAlt
import androidx.compose.material.icons.filled.Chat
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Language
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.PhotoLibrary
import androidx.compose.material.icons.filled.Security
import androidx.compose.material.icons.filled.VolumeOff
import androidx.compose.material.icons.filled.VolumeUp
import androidx.compose.material3.Button
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.DisposableEffect
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.data.quiz.PedagogyQuizData
import com.example.model.quiz.QuizCategory
import com.example.model.quiz.ReviewDueState
import com.example.util.QuizSpeechManager
import com.example.ui.theme.AssistiveBackground
import com.example.ui.theme.AssistiveBlue
import com.example.ui.theme.AssistiveBlueLight
import com.example.ui.theme.AssistiveRed
import com.example.ui.theme.AssistiveRedLight
import com.example.ui.theme.AssistiveTextMuted
import com.example.ui.theme.AssistiveTextSecondary

enum class QuizFlowStep {
    CHILD_INTRO,
    CHILD_QUESTION,
    CHILD_FEEDBACK,
    CHILD_SUMMARY,
    HANDOFF_TO_PARENT,
    PARENT_INTRO,
    PARENT_QUESTION,
    PARENT_FEEDBACK,
    PARENT_TIPS,
    PARENT_PIN
}

@Composable
fun QuizFlowScreen(
    appName: String,
    category: QuizCategory,
    reviewState: ReviewDueState = ReviewDueState.NONE,
    parentPin: String,
    onCompleteUnlocked: () -> Unit,
    onCancel: () -> Unit
) {
    BackHandler { onCancel() }

    val module = remember(category) { PedagogyQuizData.getModule(category) }

    var currentStep by remember { mutableStateOf(QuizFlowStep.CHILD_INTRO) }

    // Child quiz state
    var childQuestionIdx by remember { mutableIntStateOf(0) }
    var childSelectedIdx by remember { mutableStateOf<Int?>(null) }
    var childIsCorrect by remember { mutableStateOf<Boolean?>(null) }

    // Parent quiz state
    var parentQuestionIdx by remember { mutableIntStateOf(0) }
    var parentSelectedIdx by remember { mutableStateOf<Int?>(null) }
    var parentIsCorrect by remember { mutableStateOf<Boolean?>(null) }

    // PIN state
    var enteredPin by remember { mutableStateOf("") }
    var pinError by remember { mutableStateOf(false) }

    val appIcon: ImageVector = remember(category) {
        when (category) {
            QuizCategory.ANRUFEN, QuizCategory.UNBEKANNTE_NUMMERN -> Icons.Default.Phone
            QuizCategory.FOTOS_MACHEN -> Icons.Default.CameraAlt
            QuizCategory.FOTOS_VON_ANDEREN, QuizCategory.BEVOR_VERSCHICKEN -> Icons.Default.PhotoLibrary
            QuizCategory.WHATSAPP, QuizCategory.NACHRICHTEN, QuizCategory.SPRACHNACHRICHTEN -> Icons.Default.Chat
            QuizCategory.BLOCKIEREN, QuizCategory.PERSOENLICHE_DATEN -> Icons.Default.Security
            QuizCategory.INTERNET_SURFEN -> Icons.Default.Language
        }
    }

    val context = LocalContext.current
    val speechManager = remember { QuizSpeechManager(context) }
    val isSpeaking by speechManager.isSpeaking

    DisposableEffect(Unit) {
        onDispose {
            speechManager.shutdown()
        }
    }

    // Stop speaking automatically whenever the step or question changes
    LaunchedEffect(currentStep, childQuestionIdx, parentQuestionIdx) {
        speechManager.stop()
    }

    val currentSpeechText = remember(
        currentStep,
        childQuestionIdx,
        childIsCorrect,
        parentQuestionIdx,
        parentIsCorrect,
        appName,
        module,
        reviewState
    ) {
        when (currentStep) {
            QuizFlowStep.CHILD_INTRO -> {
                val reviewText = if (reviewState != ReviewDueState.NONE) {
                    "Wir schauen heute noch einmal gemeinsam, was du über $appName weißt."
                } else {
                    "Bevor du $appName benutzen kannst, schauen wir uns gemeinsam an, was dabei wichtig ist."
                }
                "$appName. ${module.childIntroText}. $reviewText"
            }
            QuizFlowStep.CHILD_QUESTION -> {
                val q = module.childQuestions.getOrNull(childQuestionIdx)
                if (q != null) {
                    val optionsSpoken = q.options.joinToString(". ") { "Antwort ${it.id}: ${it.text}" }
                    "Frage ${childQuestionIdx + 1} von ${module.childQuestions.size}. ${q.title}. ${q.situation}. Die Antwortmöglichkeiten lauten: $optionsSpoken"
                } else ""
            }
            QuizFlowStep.CHILD_FEEDBACK -> {
                val q = module.childQuestions.getOrNull(childQuestionIdx)
                val statusText = if (childIsCorrect == true) "Genau richtig! Super gemacht!" else "Nochmal überlegen!"
                if (q != null) "$statusText. ${q.explanation}" else statusText
            }
            QuizFlowStep.CHILD_SUMMARY -> {
                "Das hast du gelernt: " + module.childSummaryPoints.joinToString(". ")
            }
            QuizFlowStep.HANDOFF_TO_PARENT -> {
                "Jetzt sind deine Eltern dran! Deine Eltern beantworten ein paar Fragen, um $appName für dich freizugeben. Sie erfahren dabei auch, worauf sie achten sollten."
            }
            QuizFlowStep.PARENT_INTRO -> {
                "$appName. Warum ist das wichtig? ${module.parentIntroText}. Wichtige Themen sind: " + module.parentFocusTopics.joinToString(". ")
            }
            QuizFlowStep.PARENT_QUESTION -> {
                val q = module.parentQuestions.getOrNull(parentQuestionIdx)
                if (q != null) {
                    val optionsSpoken = q.options.joinToString(". ") { "Option ${it.id}: ${it.text}" }
                    "Frage ${parentQuestionIdx + 1} von ${module.parentQuestions.size}. ${q.title}. ${q.situation}. Die Optionen lauten: $optionsSpoken"
                } else ""
            }
            QuizFlowStep.PARENT_FEEDBACK -> {
                val q = module.parentQuestions.getOrNull(parentQuestionIdx)
                val statusText = if (parentIsCorrect == true) "Genau richtig!" else "Nochmal überlegen!"
                if (q != null) "$statusText. ${q.explanation}" else statusText
            }
            QuizFlowStep.PARENT_TIPS -> {
                "Tipps für Eltern bei $appName: " + module.parentTips.joinToString(". ")
            }
            QuizFlowStep.PARENT_PIN -> {
                "Bitte gib deine Eltern-PIN ein, um die App freizuschalten."
            }
        }
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(AssistiveBackground)
            .windowInsetsPadding(WindowInsets.launcherSafe)
    ) {
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(horizontal = 20.dp, vertical = 12.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Header with TTS Vorlesen button and cancel X button
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 8.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Text(
                    text = "TEDOKI Kids",
                    fontSize = 15.sp,
                    fontWeight = FontWeight.Bold,
                    color = AssistiveTextMuted
                )

                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    // Vorlesen / Stopp on-demand Pill Button
                    Surface(
                        shape = RoundedCornerShape(20.dp),
                        color = if (isSpeaking) AssistiveRedLight else AssistiveBlueLight,
                        border = BorderStroke(
                            1.5.dp,
                            if (isSpeaking) AssistiveRed else AssistiveBlue
                        ),
                        modifier = Modifier
                            .clip(RoundedCornerShape(20.dp))
                            .clickable {
                                if (isSpeaking) {
                                    speechManager.stop()
                                } else {
                                    speechManager.speak(currentSpeechText)
                                }
                            }
                            .testTag("quiz_tts_button")
                    ) {
                        Row(
                            verticalAlignment = Alignment.CenterVertically,
                            horizontalArrangement = Arrangement.spacedBy(6.dp),
                            modifier = Modifier.padding(horizontal = 12.dp, vertical = 6.dp)
                        ) {
                            Icon(
                                imageVector = if (isSpeaking) Icons.Default.VolumeOff else Icons.Default.VolumeUp,
                                contentDescription = if (isSpeaking) "Vorlesen beenden" else "Text vorlesen",
                                tint = if (isSpeaking) AssistiveRed else AssistiveBlue,
                                modifier = Modifier.size(18.dp)
                            )
                            Text(
                                text = if (isSpeaking) "Stopp" else "Vorlesen",
                                fontSize = 13.sp,
                                fontWeight = FontWeight.Bold,
                                color = if (isSpeaking) AssistiveRed else AssistiveBlue
                            )
                        }
                    }

                    IconButton(
                        onClick = {
                            speechManager.stop()
                            onCancel()
                        },
                        modifier = Modifier.testTag("quiz_close_button")
                    ) {
                        Icon(
                            imageVector = Icons.Default.Close,
                            contentDescription = "Schließen",
                            tint = AssistiveTextSecondary
                        )
                    }
                }
            }

            AnimatedContent(
                targetState = currentStep,
                transitionSpec = { fadeIn() togetherWith fadeOut() },
                label = "quiz_step_transition",
                modifier = Modifier.weight(1f)
            ) { step ->
                when (step) {
                    QuizFlowStep.CHILD_INTRO -> {
                        ChildIntroView(
                            appName = appName,
                            category = category,
                            icon = appIcon,
                            introText = module.childIntroText,
                            isReview = reviewState != ReviewDueState.NONE,
                            onStart = {
                                childQuestionIdx = 0
                                childSelectedIdx = null
                                childIsCorrect = null
                                currentStep = QuizFlowStep.CHILD_QUESTION
                            }
                        )
                    }

                    QuizFlowStep.CHILD_QUESTION -> {
                        val question = module.childQuestions[childQuestionIdx]
                        val childComic = when (category) {
                            QuizCategory.FOTOS_MACHEN, QuizCategory.FOTOS_VON_ANDEREN, QuizCategory.BEVOR_VERSCHICKEN -> ComicType.QUESTION_ASK_PHOTO
                            QuizCategory.ANRUFEN, QuizCategory.UNBEKANNTE_NUMMERN -> ComicType.QUESTION_CALL_CONTACT
                            QuizCategory.WHATSAPP, QuizCategory.NACHRICHTEN, QuizCategory.SPRACHNACHRICHTEN, QuizCategory.BLOCKIEREN -> ComicType.QUESTION_CHAT_MESSAGE
                            else -> ComicType.QUESTION_ASK_PHOTO
                        }
                        QuestionView(
                            stepTitle = "${childQuestionIdx + 1}/${module.childQuestions.size}",
                            questionTitle = question.title,
                            situationText = question.situation,
                            questionId = question.id,
                            comicType = childComic,
                            options = question.options,
                            selectedIndex = childSelectedIdx,
                            onOptionSelected = { idx -> childSelectedIdx = idx },
                            onNext = {
                                if (childSelectedIdx != null) {
                                    childIsCorrect = (childSelectedIdx == question.correctIndex)
                                    currentStep = QuizFlowStep.CHILD_FEEDBACK
                                }
                            },
                            onSpeakSituation = {
                                val optionsSpoken = question.options.joinToString(". ") { "Antwort ${it.id}: ${it.text}" }
                                speechManager.speak("${question.title}. ${question.situation}. Die Antwortmöglichkeiten lauten: $optionsSpoken")
                            },
                            onSpeakOption = { opt ->
                                speechManager.speak("Antwort ${opt.id}: ${opt.text}")
                            }
                        )
                    }

                    QuizFlowStep.CHILD_FEEDBACK -> {
                        val question = module.childQuestions[childQuestionIdx]
                        val isCorrect = childIsCorrect == true
                        FeedbackView(
                            stepTitle = "${childQuestionIdx + 1}/${module.childQuestions.size}",
                            isCorrect = isCorrect,
                            explanationText = question.explanation,
                            questionId = question.id,
                            onNext = {
                                if (isCorrect) {
                                    if (childQuestionIdx + 1 < module.childQuestions.size) {
                                        childQuestionIdx++
                                        childSelectedIdx = null
                                        childIsCorrect = null
                                        currentStep = QuizFlowStep.CHILD_QUESTION
                                    } else {
                                        currentStep = QuizFlowStep.CHILD_SUMMARY
                                    }
                                } else {
                                    // Retry the question
                                    childSelectedIdx = null
                                    childIsCorrect = null
                                    currentStep = QuizFlowStep.CHILD_QUESTION
                                }
                            },
                            onSpeakExplanation = {
                                val statusText = if (isCorrect) "Genau richtig! Super gemacht!" else "Nochmal überlegen!"
                                speechManager.speak("$statusText. ${question.explanation}")
                            }
                        )
                    }

                    QuizFlowStep.CHILD_SUMMARY -> {
                        ChildSummaryView(
                            summaryPoints = module.childSummaryPoints,
                            onNext = {
                                currentStep = QuizFlowStep.HANDOFF_TO_PARENT
                            }
                        )
                    }

                    QuizFlowStep.HANDOFF_TO_PARENT -> {
                        HandoffToParentView(
                            appName = appName,
                            onProceed = {
                                currentStep = QuizFlowStep.PARENT_INTRO
                            }
                        )
                    }

                    QuizFlowStep.PARENT_INTRO -> {
                        ParentIntroView(
                            appName = appName,
                            icon = appIcon,
                            introText = module.parentIntroText,
                            focusTopics = module.parentFocusTopics,
                            onStart = {
                                parentQuestionIdx = 0
                                parentSelectedIdx = null
                                parentIsCorrect = null
                                currentStep = QuizFlowStep.PARENT_QUESTION
                            }
                        )
                    }

                    QuizFlowStep.PARENT_QUESTION -> {
                        val question = module.parentQuestions[parentQuestionIdx]
                        QuestionView(
                            stepTitle = "${parentQuestionIdx + 1}/${module.parentQuestions.size}",
                            questionTitle = question.title,
                            situationText = question.situation,
                            questionId = question.id,
                            comicType = ComicType.PARENT_DISCUSSION,
                            options = question.options,
                            selectedIndex = parentSelectedIdx,
                            onOptionSelected = { idx -> parentSelectedIdx = idx },
                            onNext = {
                                if (parentSelectedIdx != null) {
                                    parentIsCorrect = (parentSelectedIdx == question.correctIndex)
                                    currentStep = QuizFlowStep.PARENT_FEEDBACK
                                }
                            },
                            onSpeakSituation = {
                                val optionsSpoken = question.options.joinToString(". ") { "Option ${it.id}: ${it.text}" }
                                speechManager.speak("${question.title}. ${question.situation}. Die Optionen lauten: $optionsSpoken")
                            },
                            onSpeakOption = { opt ->
                                speechManager.speak("Option ${opt.id}: ${opt.text}")
                            }
                        )
                    }

                    QuizFlowStep.PARENT_FEEDBACK -> {
                        val question = module.parentQuestions[parentQuestionIdx]
                        val isCorrect = parentIsCorrect == true
                        FeedbackView(
                            stepTitle = "${parentQuestionIdx + 1}/${module.parentQuestions.size}",
                            isCorrect = isCorrect,
                            explanationText = question.explanation,
                            questionId = question.id,
                            onNext = {
                                if (isCorrect) {
                                    if (parentQuestionIdx + 1 < module.parentQuestions.size) {
                                        parentQuestionIdx++
                                        parentSelectedIdx = null
                                        parentIsCorrect = null
                                        currentStep = QuizFlowStep.PARENT_QUESTION
                                    } else {
                                        currentStep = QuizFlowStep.PARENT_TIPS
                                    }
                                } else {
                                    parentSelectedIdx = null
                                    parentIsCorrect = null
                                    currentStep = QuizFlowStep.PARENT_QUESTION
                                }
                            },
                            onSpeakExplanation = {
                                val statusText = if (isCorrect) "Genau richtig!" else "Nochmal überlegen!"
                                speechManager.speak("$statusText. ${question.explanation}")
                            }
                        )
                    }

                    QuizFlowStep.PARENT_TIPS -> {
                        ParentTipsView(
                            appName = appName,
                            tips = module.parentTips,
                            onNext = {
                                enteredPin = ""
                                pinError = false
                                currentStep = QuizFlowStep.PARENT_PIN
                            }
                        )
                    }

                    QuizFlowStep.PARENT_PIN -> {
                        ParentPinUnlockView(
                            enteredPin = enteredPin,
                            pinError = pinError,
                            onDigitEntered = { digit ->
                                if (enteredPin.length < 6) {
                                    pinError = false
                                    enteredPin += digit
                                    if (enteredPin == parentPin) {
                                        onCompleteUnlocked()
                                    } else if (enteredPin.length >= parentPin.length) {
                                        pinError = true
                                    }
                                }
                            },
                            onDelete = {
                                if (enteredPin.isNotEmpty()) {
                                    enteredPin = enteredPin.dropLast(1)
                                    pinError = false
                                }
                            },
                            onClear = {
                                enteredPin = ""
                                pinError = false
                            }
                        )
                    }
                }
            }
        }
    }
}
