package com.example.ui.setup

import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.foundation.layout.windowInsetsPadding
import com.example.ui.components.launcherSafe
import android.net.Uri
import androidx.activity.compose.BackHandler
import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.PickVisualMediaRequest
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.animation.AnimatedContent
import androidx.compose.animation.fadeIn
import androidx.compose.animation.fadeOut
import androidx.compose.animation.togetherWith
import androidx.compose.foundation.BorderStroke
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.WindowInsets
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Phone
import androidx.compose.material.icons.filled.Quiz
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.LinearProgressIndicator
import androidx.compose.material3.Surface
import androidx.compose.material3.Text
import androidx.compose.runtime.Composable
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.LocalFocusManager
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.model.ButtonType
import com.example.model.LauncherButton
import com.example.model.LauncherSettings
import com.example.ui.theme.AssistiveBackground
import com.example.ui.theme.AssistiveBlue
import com.example.ui.theme.AssistiveBorder
import com.example.ui.theme.AssistiveSurface
import com.example.ui.theme.AssistiveTextMuted
import com.example.ui.theme.AssistiveTextPrimary

/**
 * 10-step guided initial onboarding wizard for parents:
 * 1. Welcome to TEDOKI Kids Launcher
 * 2. Pedagogical Quiz Unlock Concept
 * 3. Child profile: Name & Age (free input)
 * 4. Avatar Selection: Horizontal scrolling preset avatars or custom photo
 * 5. Initial Homescreen Features: Camera, Photos, Calling & first 2 contacts
 * 6. Dashboard Preview: Explanation of later unlocking additional features/apps with icons
 * 7. Emergency SOS setup
 * 8. Layout Style: Grid vs. Rows
 * 9. Parent PIN setup & 2x verification
 * 10. Completion & celebration
 */
enum class SetupStep {
    WELCOME,
    PEDAGOGY_CONCEPT,
    CHILD_INFO,
    AVATAR_PICKER,
    FEATURE_SELECTION,
    INITIAL_CONTACTS,
    DASHBOARD_INFO,
    EMERGENCY_SETUP,
    LAYOUT_STYLE,
    PARENT_PIN,
    COMPLETION
}

data class ChildAvatarPreset(
    val id: String,
    val name: String,
    val emoji: String,
    val bgHex: Long
)

val PRESET_AVATARS = listOf(
    ChildAvatarPreset("lion", "Leo", "🦁", 0xFFF59E0B),
    ChildAvatarPreset("panda", "Bao", "🐼", 0xFF10B981),
    ChildAvatarPreset("astro", "Astro", "🚀", 0xFF3B82F6),
    ChildAvatarPreset("fox", "Felix", "🦊", 0xFFEA580C),
    ChildAvatarPreset("cat", "Mimi", "🐱", 0xFFEC4899),
    ChildAvatarPreset("robot", "Beep", "🤖", 0xFF6366F1),
    ChildAvatarPreset("dragon", "Fuchur", "🐲", 0xFF059669),
    ChildAvatarPreset("bunny", "Hops", "🐰", 0xFFF43F5E),
    ChildAvatarPreset("owl", "Luna", "🦉", 0xFF8B5CF6),
    ChildAvatarPreset("penguin", "Pico", "🐧", 0xFF0284C7),
    ChildAvatarPreset("unicorn", "Sternchen", "🦄", 0xFFD946EF),
    ChildAvatarPreset("dog", "Bello", "🐶", 0xFFD97706),
    ChildAvatarPreset("tiger", "Sammy", "🐯", 0xFFDC2626),
    ChildAvatarPreset("bear", "Bruno", "🐻", 0xFF92400E)
)

@Composable
fun ParentSetupScreen(
    currentSettings: LauncherSettings,
    onCompleteSetup: (LauncherSettings) -> Unit,
    onLanguageChange: (String) -> Unit
) {
    val context = LocalContext.current
    val focusManager = LocalFocusManager.current

    var currentStep by remember { mutableStateOf(SetupStep.WELCOME) }
    var currentLanguage by remember(currentSettings.language) { mutableStateOf(currentSettings.language) }
    val isEn = currentLanguage == "en"

    // Step 3 state
    var childName by remember { mutableStateOf(currentSettings.childName) }
    var childAgeText by remember { mutableStateOf(if (currentSettings.childAge > 0) currentSettings.childAge.toString() else "8") }

    // Step 4 state
    var selectedAvatarId by remember { mutableStateOf(currentSettings.childAvatar.ifEmpty { "lion" }) }
    var customPhotoUri by remember {
        mutableStateOf<String?>(
            if (currentSettings.childAvatar.startsWith("content://") ||
                currentSettings.childAvatar.startsWith("file://") ||
                currentSettings.childAvatar.startsWith("/")
            ) currentSettings.childAvatar else null
        )
    }

    // Step 5 state (Initial feature selection)
    var includeSms by remember { mutableStateOf(true) }
    var includeCalls by remember { mutableStateOf(true) }
    var includeCamera by remember { mutableStateOf(true) }
    var includePhotos by remember { mutableStateOf(true) }

    var contact1Name by remember { mutableStateOf(if (isEn) "Mom" else "Mama") }
    var contact1Number by remember { mutableStateOf("0170 1234567") }

    var contact2Name by remember { mutableStateOf(if (isEn) "Dad" else "Papa") }
    var contact2Number by remember { mutableStateOf("0171 7654321") }

    // Step 7 state (Emergency SOS)
    var sosEnabled by remember { mutableStateOf(currentSettings.showSosButton) }
    var emergencyContactName by remember {
        mutableStateOf(
            if (currentSettings.emergencyContactName == "Emergency / Notruf" || currentSettings.emergencyContactName == "Notruf / Emergency") {
                if (isEn) "Mom" else "Mama"
            } else currentSettings.emergencyContactName
        )
    }
    var emergencyNumber by remember { mutableStateOf(currentSettings.emergencyNumber.ifEmpty { "112" }) }
    var sendSosLocationSms by remember { mutableStateOf(currentSettings.sendSosLocationSms) }

    // Step 8 state (Layout)
    var layoutStyle by remember { mutableStateOf(currentSettings.layoutStyle) }

    // Step 9 state (PIN)
    var pin by remember { mutableStateOf("") }
    var pinConfirm by remember { mutableStateOf("") }
    var pinVisible by remember { mutableStateOf(false) }

    // Photo picker for custom avatar with permanent storage copy
    val avatarPickerLauncher = rememberLauncherForActivityResult(
        contract = ActivityResultContracts.PickVisualMedia()
    ) { uri: Uri? ->
        if (uri != null) {
            val permanentUri = com.example.util.ImageStorageUtils.saveImageToInternalStorage(context, uri, "child_avatar") ?: uri.toString()
            customPhotoUri = permanentUri
            selectedAvatarId = permanentUri
        }
    }

    // Back handling
    BackHandler(enabled = currentStep != SetupStep.WELCOME) {
        val steps = SetupStep.values()
        val currentIdx = steps.indexOf(currentStep)
        if (currentIdx > 0) {
            currentStep = steps[currentIdx - 1]
        }
    }

    val stepIndex = SetupStep.values().indexOf(currentStep)
    val totalSteps = SetupStep.values().size
    val progress = (stepIndex + 1).toFloat() / totalSteps.toFloat()

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(AssistiveBackground)
            .windowInsetsPadding(WindowInsets.launcherSafe)
    ) {
        Column(
            modifier = Modifier.fillMaxSize()
        ) {
            // Top Bar: Step progress, Title, and Language Switcher
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(horizontal = 20.dp, vertical = 10.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Row(
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.spacedBy(8.dp)
                ) {
                    if (stepIndex > 0) {
                        IconButton(
                            onClick = {
                                val steps = SetupStep.values()
                                currentStep = steps[stepIndex - 1]
                            },
                            modifier = Modifier.size(36.dp)
                        ) {
                            Icon(
                                imageVector = Icons.Default.ArrowBack,
                                contentDescription = if (isEn) "Back" else "Zurück",
                                tint = AssistiveTextPrimary
                            )
                        }
                    }
                    Text(
                        text = if (isEn) "Step ${stepIndex + 1} of $totalSteps" else "Schritt ${stepIndex + 1} von $totalSteps",
                        fontSize = 14.sp,
                        fontWeight = FontWeight.Bold,
                        color = AssistiveTextMuted
                    )
                }

                // Language toggle pill (DE / EN)
                Surface(
                    shape = RoundedCornerShape(16.dp),
                    color = AssistiveSurface,
                    border = BorderStroke(1.dp, AssistiveBorder),
                    modifier = Modifier.clip(RoundedCornerShape(16.dp))
                ) {
                    Row(
                        modifier = Modifier.padding(horizontal = 10.dp, vertical = 4.dp),
                        verticalAlignment = Alignment.CenterVertically,
                        horizontalArrangement = Arrangement.spacedBy(6.dp)
                    ) {
                        Text(
                            text = "DE",
                            fontSize = 12.sp,
                            fontWeight = if (!isEn) FontWeight.Bold else FontWeight.Normal,
                            color = if (!isEn) AssistiveBlue else AssistiveTextMuted,
                            modifier = Modifier.clickable {
                                currentLanguage = "de"
                                onLanguageChange("de")
                            }
                        )
                        Text(text = "|", fontSize = 12.sp, color = AssistiveTextMuted)
                        Text(
                            text = "EN",
                            fontSize = 12.sp,
                            fontWeight = if (isEn) FontWeight.Bold else FontWeight.Normal,
                            color = if (isEn) AssistiveBlue else AssistiveTextMuted,
                            modifier = Modifier.clickable {
                                currentLanguage = "en"
                                onLanguageChange("en")
                            }
                        )
                    }
                }
            }

            // Progress Indicator
            LinearProgressIndicator(
                progress = { progress },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(4.dp),
                color = AssistiveBlue,
                trackColor = AssistiveBorder
            )

            // Step Content Area (Animated)
            Box(
                modifier = Modifier
                    .weight(1f)
                    .fillMaxWidth()
            ) {
                AnimatedContent(
                    targetState = currentStep,
                    transitionSpec = { fadeIn() togetherWith fadeOut() },
                    label = "setup_step_transition"
                ) { step ->
                    when (step) {
                        SetupStep.WELCOME -> {
                            WelcomeStep(
                                isEn = isEn,
                                onNext = { currentStep = SetupStep.PEDAGOGY_CONCEPT }
                            )
                        }
                        SetupStep.PEDAGOGY_CONCEPT -> {
                            PedagogyConceptStep(
                                isEn = isEn,
                                onNext = { currentStep = SetupStep.CHILD_INFO }
                            )
                        }
                        SetupStep.CHILD_INFO -> {
                            ChildInfoStep(
                                isEn = isEn,
                                childName = childName,
                                onNameChange = { childName = it },
                                childAgeText = childAgeText,
                                onAgeChange = { childAgeText = it },
                                onNext = {
                                    focusManager.clearFocus()
                                    currentStep = SetupStep.AVATAR_PICKER
                                }
                            )
                        }
                        SetupStep.AVATAR_PICKER -> {
                            AvatarPickerStep(
                                isEn = isEn,
                                childName = childName.ifBlank { if (isEn) "your child" else "dein Kind" },
                                selectedAvatarId = selectedAvatarId,
                                customPhotoUri = customPhotoUri,
                                onSelectPreset = {
                                    selectedAvatarId = it.id
                                    customPhotoUri = null
                                },
                                onPickCustomPhoto = {
                                    avatarPickerLauncher.launch(
                                        PickVisualMediaRequest(ActivityResultContracts.PickVisualMedia.ImageOnly)
                                    )
                                },
                                onNext = { currentStep = SetupStep.FEATURE_SELECTION }
                            )
                        }
                        SetupStep.FEATURE_SELECTION -> {
                            InitialFeatureSelectionStep(
                                isEn = isEn,
                                includeSms = includeSms,
                                onToggleSms = { includeSms = it },
                                includeCalls = includeCalls,
                                onToggleCalls = { includeCalls = it },
                                includeCamera = includeCamera,
                                onToggleCamera = { includeCamera = it },
                                includePhotos = includePhotos,
                                onTogglePhotos = { includePhotos = it },
                                onNext = { currentStep = SetupStep.INITIAL_CONTACTS }
                            )
                        }
                        SetupStep.INITIAL_CONTACTS -> {
                            InitialContactsSetupStep(
                                isEn = isEn,
                                contact1Name = contact1Name,
                                onContact1NameChange = { contact1Name = it },
                                contact1Number = contact1Number,
                                onContact1NumberChange = { contact1Number = it },
                                contact2Name = contact2Name,
                                onContact2NameChange = { contact2Name = it },
                                contact2Number = contact2Number,
                                onContact2NumberChange = { contact2Number = it },
                                onNext = { currentStep = SetupStep.DASHBOARD_INFO }
                            )
                        }
                        SetupStep.DASHBOARD_INFO -> {
                            DashboardInfoStep(
                                isEn = isEn,
                                onNext = { currentStep = SetupStep.EMERGENCY_SETUP }
                            )
                        }
                        SetupStep.EMERGENCY_SETUP -> {
                            EmergencySetupStep(
                                isEn = isEn,
                                sosEnabled = sosEnabled,
                                onToggleSos = { sosEnabled = it },
                                emergencyName = emergencyContactName,
                                onNameChange = { emergencyContactName = it },
                                emergencyNumber = emergencyNumber,
                                onNumberChange = { emergencyNumber = it },
                                sendSms = sendSosLocationSms,
                                onToggleSms = { sendSosLocationSms = it },
                                onNext = {
                                    focusManager.clearFocus()
                                    currentStep = SetupStep.LAYOUT_STYLE
                                }
                            )
                        }
                        SetupStep.LAYOUT_STYLE -> {
                            LayoutStyleStep(
                                isEn = isEn,
                                selectedStyle = layoutStyle,
                                onSelectStyle = { layoutStyle = it },
                                onNext = { currentStep = SetupStep.PARENT_PIN }
                            )
                        }
                        SetupStep.PARENT_PIN -> {
                            ParentPinStep(
                                isEn = isEn,
                                pin = pin,
                                onPinChange = { pin = it },
                                pinConfirm = pinConfirm,
                                onConfirmChange = { pinConfirm = it },
                                pinVisible = pinVisible,
                                onToggleVisibility = { pinVisible = !pinVisible },
                                onNext = {
                                    focusManager.clearFocus()
                                    currentStep = SetupStep.COMPLETION
                                }
                            )
                        }
                        SetupStep.COMPLETION -> {
                            CompletionStep(
                                isEn = isEn,
                                childName = childName.ifBlank { if (isEn) "Child" else "Kind" },
                                childAvatar = selectedAvatarId,
                                includeCamera = includeCamera,
                                includePhotos = includePhotos,
                                includeCalls = includeCalls,
                                sosEnabled = sosEnabled,
                                emergencyNumber = emergencyNumber,
                                layoutStyle = layoutStyle,
                                onFinish = {
                                    // Assemble initial buttons: Nachrichten, Telefonie, Kamera, Fotos
                                    val finalButtons = mutableListOf<LauncherButton>()
                                    if (includeSms) {
                                        finalButtons.add(
                                            LauncherButton(
                                                id = "sms_default",
                                                type = ButtonType.SMS,
                                                title = if (isEn) "Messages" else "Nachrichten",
                                                colorHex = 0xFF6366F1
                                            )
                                        )
                                    }
                                    if (includeCalls) {
                                        finalButtons.add(
                                            LauncherButton(
                                                id = "call_default",
                                                type = ButtonType.CALL,
                                                title = if (isEn) "Phone" else "Telefon",
                                                colorHex = 0xFF059669
                                            )
                                        )
                                    }
                                    if (includeCamera) {
                                        finalButtons.add(
                                            LauncherButton(
                                                id = "camera_default",
                                                type = ButtonType.CAMERA,
                                                title = if (isEn) "Camera" else "Kamera",
                                                colorHex = 0xFF2563EB
                                            )
                                        )
                                    }
                                    if (includePhotos) {
                                        finalButtons.add(
                                            LauncherButton(
                                                id = "photos_default",
                                                type = ButtonType.PHOTOS,
                                                title = if (isEn) "Photos" else "Fotos",
                                                colorHex = 0xFFDB2777
                                            )
                                        )
                                    }

                                    // Assemble initial contacts for Contacts submenu
                                    val finalContacts = mutableListOf<com.example.model.LauncherContact>()
                                    if (contact1Name.isNotBlank() && contact1Number.isNotBlank()) {
                                        finalContacts.add(
                                            com.example.model.LauncherContact(
                                                id = "contact_0",
                                                name = contact1Name.trim(),
                                                phoneNumber = contact1Number.trim(),
                                                colorHex = 0xFF059669
                                            )
                                        )
                                    }
                                    if (contact2Name.isNotBlank() && contact2Number.isNotBlank()) {
                                        finalContacts.add(
                                            com.example.model.LauncherContact(
                                                id = "contact_1",
                                                name = contact2Name.trim(),
                                                phoneNumber = contact2Number.trim(),
                                                colorHex = 0xFF2563EB
                                            )
                                        )
                                    }

                                    val parsedAge = childAgeText.filter { it.isDigit() }.toIntOrNull() ?: 8
                                    val finalSettings = currentSettings.copy(
                                        isSetupComplete = true,
                                        language = currentLanguage,
                                        childName = childName.trim(),
                                        childAge = parsedAge,
                                        childAvatar = selectedAvatarId,
                                        buttons = finalButtons.take(8),
                                        contacts = if (finalContacts.isNotEmpty()) finalContacts else LauncherSettings.defaultContacts(),
                                        layoutStyle = layoutStyle,
                                        pin = pin.ifBlank { "1234" },
                                        showSosButton = sosEnabled,
                                        emergencyContactName = emergencyContactName.ifBlank { if (isEn) "Emergency" else "Notruf / Emergency" },
                                        emergencyNumber = emergencyNumber.ifBlank { "112" },
                                        sendSosLocationSms = sendSosLocationSms
                                    )
                                    onCompleteSetup(finalSettings)
                                }
                            )
                        }
                    }
                }
            }
        }
    }
}
