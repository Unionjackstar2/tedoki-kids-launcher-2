# Alle Bild-Prompts zum Kopieren

Reihenfolge: zuerst das Figurenblatt (Nr. 0), dann bei **jedem** weiteren Bild das Figurenblatt als Referenzbild mitgeben.
Dateiname = Überschrift (z. B. `quiz_call_1.png`). Danach: `python3 tools/comics_einbauen.py ordner/`

## 0 · figurenblatt (nur Vorlage, wird nicht eingebaut)

```
Calm, modern children's picture-book illustration in a soft flat style.
Gentle rounded shapes, thin soft navy outlines, very little shading, no harsh contrast.
Muted, harmonious palette: navy blue, sage green, warm amber, soft sky blue, muted coral, warm sand.
Plain solid cream background (#F6F1EA) that fills the entire image edge to edge –
no border, no frame, no vignette, no drop shadow, no white margin, no rounded corners.
Few objects, plenty of calm empty space, relaxed friendly expressions, no motion lines, no clutter.
Recurring characters (always identical):
"Tedo" – 8-year-old boy, short messy brown hair, navy hoodie;
"Kiki" – 8-year-old girl, dark curly hair in two puffs, amber-striped shirt;
"Mama" – woman, brown shoulder-length hair, sage-green cardigan;
"Papa" – man, short dark hair and beard, warm sand-colored sweater.
The smartphone is a simple rounded rectangle with a navy case; screen content only as simple icons.
Landscape 4:3, main subject centered, everything important inside the middle 80 % of the image.
Absolutely NO text, NO letters, NO numbers, NO words, NO logos anywhere in the image.

Character sheet: Tedo, Kiki, Mama and Papa standing side by side, front view, neutral friendly pose.
```

## 1 · quiz_call_1

```
Use the attached character sheet as strict reference for characters and style.

Calm, modern children's picture-book illustration in a soft flat style.
Gentle rounded shapes, thin soft navy outlines, very little shading, no harsh contrast.
Muted, harmonious palette: navy blue, sage green, warm amber, soft sky blue, muted coral, warm sand.
Plain solid cream background (#F6F1EA) that fills the entire image edge to edge –
no border, no frame, no vignette, no drop shadow, no white margin, no rounded corners.
Few objects, plenty of calm empty space, relaxed friendly expressions, no motion lines, no clutter.
Recurring characters (always identical):
"Tedo" – 8-year-old boy, short messy brown hair, navy hoodie;
"Kiki" – 8-year-old girl, dark curly hair in two puffs, amber-striped shirt;
"Mama" – woman, brown shoulder-length hair, sage-green cardigan;
"Papa" – man, short dark hair and beard, warm sand-colored sweater.
The smartphone is a simple rounded rectangle with a navy case; screen content only as simple icons.
Landscape 4:3, main subject centered, everything important inside the middle 80 % of the image.
Absolutely NO text, NO letters, NO numbers, NO words, NO logos anywhere in the image.

Scene: Tedo on the sofa scrolls a contact list with round avatar icons on his phone, Mama's avatar with a heart is highlighted, green call button glowing.
```

## 2 · quiz_call_2

```
Use the attached character sheet as strict reference for characters and style.

Calm, modern children's picture-book illustration in a soft flat style.
Gentle rounded shapes, thin soft navy outlines, very little shading, no harsh contrast.
Muted, harmonious palette: navy blue, sage green, warm amber, soft sky blue, muted coral, warm sand.
Plain solid cream background (#F6F1EA) that fills the entire image edge to edge –
no border, no frame, no vignette, no drop shadow, no white margin, no rounded corners.
Few objects, plenty of calm empty space, relaxed friendly expressions, no motion lines, no clutter.
Recurring characters (always identical):
"Tedo" – 8-year-old boy, short messy brown hair, navy hoodie;
"Kiki" – 8-year-old girl, dark curly hair in two puffs, amber-striped shirt;
"Mama" – woman, brown shoulder-length hair, sage-green cardigan;
"Papa" – man, short dark hair and beard, warm sand-colored sweater.
The smartphone is a simple rounded rectangle with a navy case; screen content only as simple icons.
Landscape 4:3, main subject centered, everything important inside the middle 80 % of the image.
Absolutely NO text, NO letters, NO numbers, NO words, NO logos anywhere in the image.

Scene: Tedo looks slightly surprised at his phone showing an outgoing call, his finger on the red hang-up button, small "oops" sweat drop, relaxed mood.
```

## 3 · quiz_call_3

```
Use the attached character sheet as strict reference for characters and style.

Calm, modern children's picture-book illustration in a soft flat style.
Gentle rounded shapes, thin soft navy outlines, very little shading, no harsh contrast.
Muted, harmonious palette: navy blue, sage green, warm amber, soft sky blue, muted coral, warm sand.
Plain solid cream background (#F6F1EA) that fills the entire image edge to edge –
no border, no frame, no vignette, no drop shadow, no white margin, no rounded corners.
Few objects, plenty of calm empty space, relaxed friendly expressions, no motion lines, no clutter.
Recurring characters (always identical):
"Tedo" – 8-year-old boy, short messy brown hair, navy hoodie;
"Kiki" – 8-year-old girl, dark curly hair in two puffs, amber-striped shirt;
"Mama" – woman, brown shoulder-length hair, sage-green cardigan;
"Papa" – man, short dark hair and beard, warm sand-colored sweater.
The smartphone is a simple rounded rectangle with a navy case; screen content only as simple icons.
Landscape 4:3, main subject centered, everything important inside the middle 80 % of the image.
Absolutely NO text, NO letters, NO numbers, NO words, NO logos anywhere in the image.

Scene: Tedo holds the phone to his ear, waiting; a small clock icon and a speech-bubble icon (message symbol) float next to him, patient expression.
```

## 4 · quiz_unk_1

```
Use the attached character sheet as strict reference for characters and style.

Calm, modern children's picture-book illustration in a soft flat style.
Gentle rounded shapes, thin soft navy outlines, very little shading, no harsh contrast.
Muted, harmonious palette: navy blue, sage green, warm amber, soft sky blue, muted coral, warm sand.
Plain solid cream background (#F6F1EA) that fills the entire image edge to edge –
no border, no frame, no vignette, no drop shadow, no white margin, no rounded corners.
Few objects, plenty of calm empty space, relaxed friendly expressions, no motion lines, no clutter.
Recurring characters (always identical):
"Tedo" – 8-year-old boy, short messy brown hair, navy hoodie;
"Kiki" – 8-year-old girl, dark curly hair in two puffs, amber-striped shirt;
"Mama" – woman, brown shoulder-length hair, sage-green cardigan;
"Papa" – man, short dark hair and beard, warm sand-colored sweater.
The smartphone is a simple rounded rectangle with a navy case; screen content only as simple icons.
Landscape 4:3, main subject centered, everything important inside the middle 80 % of the image.
Absolutely NO text, NO letters, NO numbers, NO words, NO logos anywhere in the image.

Scene: Kiki looks at a ringing phone on the table showing a grey avatar with a question mark; she calmly walks toward Mama in the background.
```

## 5 · quiz_unk_2

```
Use the attached character sheet as strict reference for characters and style.

Calm, modern children's picture-book illustration in a soft flat style.
Gentle rounded shapes, thin soft navy outlines, very little shading, no harsh contrast.
Muted, harmonious palette: navy blue, sage green, warm amber, soft sky blue, muted coral, warm sand.
Plain solid cream background (#F6F1EA) that fills the entire image edge to edge –
no border, no frame, no vignette, no drop shadow, no white margin, no rounded corners.
Few objects, plenty of calm empty space, relaxed friendly expressions, no motion lines, no clutter.
Recurring characters (always identical):
"Tedo" – 8-year-old boy, short messy brown hair, navy hoodie;
"Kiki" – 8-year-old girl, dark curly hair in two puffs, amber-striped shirt;
"Mama" – woman, brown shoulder-length hair, sage-green cardigan;
"Papa" – man, short dark hair and beard, warm sand-colored sweater.
The smartphone is a simple rounded rectangle with a navy case; screen content only as simple icons.
Landscape 4:3, main subject centered, everything important inside the middle 80 % of the image.
Absolutely NO text, NO letters, NO numbers, NO words, NO logos anywhere in the image.

Scene: Kiki on the phone, a shadowy grey silhouette icon on the screen; above her head a little house icon inside a shield with a lock – she shakes her head confidently.
```

## 6 · quiz_unk_3

```
Use the attached character sheet as strict reference for characters and style.

Calm, modern children's picture-book illustration in a soft flat style.
Gentle rounded shapes, thin soft navy outlines, very little shading, no harsh contrast.
Muted, harmonious palette: navy blue, sage green, warm amber, soft sky blue, muted coral, warm sand.
Plain solid cream background (#F6F1EA) that fills the entire image edge to edge –
no border, no frame, no vignette, no drop shadow, no white margin, no rounded corners.
Few objects, plenty of calm empty space, relaxed friendly expressions, no motion lines, no clutter.
Recurring characters (always identical):
"Tedo" – 8-year-old boy, short messy brown hair, navy hoodie;
"Kiki" – 8-year-old girl, dark curly hair in two puffs, amber-striped shirt;
"Mama" – woman, brown shoulder-length hair, sage-green cardigan;
"Papa" – man, short dark hair and beard, warm sand-colored sweater.
The smartphone is a simple rounded rectangle with a navy case; screen content only as simple icons.
Landscape 4:3, main subject centered, everything important inside the middle 80 % of the image.
Absolutely NO text, NO letters, NO numbers, NO words, NO logos anywhere in the image.

Scene: Phone on a table showing many repeated grey call icons stacked; Kiki and Papa together tap a shield/block icon on the screen.
```

## 7 · quiz_msg_1

```
Use the attached character sheet as strict reference for characters and style.

Calm, modern children's picture-book illustration in a soft flat style.
Gentle rounded shapes, thin soft navy outlines, very little shading, no harsh contrast.
Muted, harmonious palette: navy blue, sage green, warm amber, soft sky blue, muted coral, warm sand.
Plain solid cream background (#F6F1EA) that fills the entire image edge to edge –
no border, no frame, no vignette, no drop shadow, no white margin, no rounded corners.
Few objects, plenty of calm empty space, relaxed friendly expressions, no motion lines, no clutter.
Recurring characters (always identical):
"Tedo" – 8-year-old boy, short messy brown hair, navy hoodie;
"Kiki" – 8-year-old girl, dark curly hair in two puffs, amber-striped shirt;
"Mama" – woman, brown shoulder-length hair, sage-green cardigan;
"Papa" – man, short dark hair and beard, warm sand-colored sweater.
The smartphone is a simple rounded rectangle with a navy case; screen content only as simple icons.
Landscape 4:3, main subject centered, everything important inside the middle 80 % of the image.
Absolutely NO text, NO letters, NO numbers, NO words, NO logos anywhere in the image.

Scene: Tedo plays with building blocks, his phone lies beside him with a small message notification dot; relaxed, no hurry, a little hourglass icon.
```

## 8 · quiz_msg_2

```
Use the attached character sheet as strict reference for characters and style.

Calm, modern children's picture-book illustration in a soft flat style.
Gentle rounded shapes, thin soft navy outlines, very little shading, no harsh contrast.
Muted, harmonious palette: navy blue, sage green, warm amber, soft sky blue, muted coral, warm sand.
Plain solid cream background (#F6F1EA) that fills the entire image edge to edge –
no border, no frame, no vignette, no drop shadow, no white margin, no rounded corners.
Few objects, plenty of calm empty space, relaxed friendly expressions, no motion lines, no clutter.
Recurring characters (always identical):
"Tedo" – 8-year-old boy, short messy brown hair, navy hoodie;
"Kiki" – 8-year-old girl, dark curly hair in two puffs, amber-striped shirt;
"Mama" – woman, brown shoulder-length hair, sage-green cardigan;
"Papa" – man, short dark hair and beard, warm sand-colored sweater.
The smartphone is a simple rounded rectangle with a navy case; screen content only as simple icons.
Landscape 4:3, main subject centered, everything important inside the middle 80 % of the image.
Absolutely NO text, NO letters, NO numbers, NO words, NO logos anywhere in the image.

Scene: Kiki looks puzzled at a chat with a big question-mark bubble, then types a reply bubble with a question-mark icon; thought bubble with a light bulb.
```

## 9 · quiz_msg_3

```
Use the attached character sheet as strict reference for characters and style.

Calm, modern children's picture-book illustration in a soft flat style.
Gentle rounded shapes, thin soft navy outlines, very little shading, no harsh contrast.
Muted, harmonious palette: navy blue, sage green, warm amber, soft sky blue, muted coral, warm sand.
Plain solid cream background (#F6F1EA) that fills the entire image edge to edge –
no border, no frame, no vignette, no drop shadow, no white margin, no rounded corners.
Few objects, plenty of calm empty space, relaxed friendly expressions, no motion lines, no clutter.
Recurring characters (always identical):
"Tedo" – 8-year-old boy, short messy brown hair, navy hoodie;
"Kiki" – 8-year-old girl, dark curly hair in two puffs, amber-striped shirt;
"Mama" – woman, brown shoulder-length hair, sage-green cardigan;
"Papa" – man, short dark hair and beard, warm sand-colored sweater.
The smartphone is a simple rounded rectangle with a navy case; screen content only as simple icons.
Landscape 4:3, main subject centered, everything important inside the middle 80 % of the image.
Absolutely NO text, NO letters, NO numbers, NO words, NO logos anywhere in the image.

Scene: Tedo looks sad at a chat bubble with a jagged red angry-face icon; Mama sits beside him with an arm around him, comforting.
```

## 10 · quiz_wa_1

```
Use the attached character sheet as strict reference for characters and style.

Calm, modern children's picture-book illustration in a soft flat style.
Gentle rounded shapes, thin soft navy outlines, very little shading, no harsh contrast.
Muted, harmonious palette: navy blue, sage green, warm amber, soft sky blue, muted coral, warm sand.
Plain solid cream background (#F6F1EA) that fills the entire image edge to edge –
no border, no frame, no vignette, no drop shadow, no white margin, no rounded corners.
Few objects, plenty of calm empty space, relaxed friendly expressions, no motion lines, no clutter.
Recurring characters (always identical):
"Tedo" – 8-year-old boy, short messy brown hair, navy hoodie;
"Kiki" – 8-year-old girl, dark curly hair in two puffs, amber-striped shirt;
"Mama" – woman, brown shoulder-length hair, sage-green cardigan;
"Papa" – man, short dark hair and beard, warm sand-colored sweater.
The smartphone is a simple rounded rectangle with a navy case; screen content only as simple icons.
Landscape 4:3, main subject centered, everything important inside the middle 80 % of the image.
Absolutely NO text, NO letters, NO numbers, NO words, NO logos anywhere in the image.

Scene: Phone screen showing a group chat as many round friendly kid avatars connected in a circle, small chat bubbles with emoji icons between them.
```

## 11 · quiz_c_wa_2

```
Use the attached character sheet as strict reference for characters and style.

Calm, modern children's picture-book illustration in a soft flat style.
Gentle rounded shapes, thin soft navy outlines, very little shading, no harsh contrast.
Muted, harmonious palette: navy blue, sage green, warm amber, soft sky blue, muted coral, warm sand.
Plain solid cream background (#F6F1EA) that fills the entire image edge to edge –
no border, no frame, no vignette, no drop shadow, no white margin, no rounded corners.
Few objects, plenty of calm empty space, relaxed friendly expressions, no motion lines, no clutter.
Recurring characters (always identical):
"Tedo" – 8-year-old boy, short messy brown hair, navy hoodie;
"Kiki" – 8-year-old girl, dark curly hair in two puffs, amber-striped shirt;
"Mama" – woman, brown shoulder-length hair, sage-green cardigan;
"Papa" – man, short dark hair and beard, warm sand-colored sweater.
The smartphone is a simple rounded rectangle with a navy case; screen content only as simple icons.
Landscape 4:3, main subject centered, everything important inside the middle 80 % of the image.
Absolutely NO text, NO letters, NO numbers, NO words, NO logos anywhere in the image.

Scene: Kiki looks at her phone showing a group of grey unknown avatars with question marks; she presses a door/exit icon, calm and sure.
```

## 12 · quiz_wa_3

```
Use the attached character sheet as strict reference for characters and style.

Calm, modern children's picture-book illustration in a soft flat style.
Gentle rounded shapes, thin soft navy outlines, very little shading, no harsh contrast.
Muted, harmonious palette: navy blue, sage green, warm amber, soft sky blue, muted coral, warm sand.
Plain solid cream background (#F6F1EA) that fills the entire image edge to edge –
no border, no frame, no vignette, no drop shadow, no white margin, no rounded corners.
Few objects, plenty of calm empty space, relaxed friendly expressions, no motion lines, no clutter.
Recurring characters (always identical):
"Tedo" – 8-year-old boy, short messy brown hair, navy hoodie;
"Kiki" – 8-year-old girl, dark curly hair in two puffs, amber-striped shirt;
"Mama" – woman, brown shoulder-length hair, sage-green cardigan;
"Papa" – man, short dark hair and beard, warm sand-colored sweater.
The smartphone is a simple rounded rectangle with a navy case; screen content only as simple icons.
Landscape 4:3, main subject centered, everything important inside the middle 80 % of the image.
Absolutely NO text, NO letters, NO numbers, NO words, NO logos anywhere in the image.

Scene: In a group chat a photo of a crying child appears; Tedo holds up a hand like "stop" and shows his phone to Mama.
```

## 13 · quiz_p_wa_3

```
Use the attached character sheet as strict reference for characters and style.

Calm, modern children's picture-book illustration in a soft flat style.
Gentle rounded shapes, thin soft navy outlines, very little shading, no harsh contrast.
Muted, harmonious palette: navy blue, sage green, warm amber, soft sky blue, muted coral, warm sand.
Plain solid cream background (#F6F1EA) that fills the entire image edge to edge –
no border, no frame, no vignette, no drop shadow, no white margin, no rounded corners.
Few objects, plenty of calm empty space, relaxed friendly expressions, no motion lines, no clutter.
Recurring characters (always identical):
"Tedo" – 8-year-old boy, short messy brown hair, navy hoodie;
"Kiki" – 8-year-old girl, dark curly hair in two puffs, amber-striped shirt;
"Mama" – woman, brown shoulder-length hair, sage-green cardigan;
"Papa" – man, short dark hair and beard, warm sand-colored sweater.
The smartphone is a simple rounded rectangle with a navy case; screen content only as simple icons.
Landscape 4:3, main subject centered, everything important inside the middle 80 % of the image.
Absolutely NO text, NO letters, NO numbers, NO words, NO logos anywhere in the image.

Scene: Kiki's finger hovers above a send button over a big group of avatars, a yellow pause/think icon above; she thinks before sending.
```

## 14 · quiz_cam_1

```
Use the attached character sheet as strict reference for characters and style.

Calm, modern children's picture-book illustration in a soft flat style.
Gentle rounded shapes, thin soft navy outlines, very little shading, no harsh contrast.
Muted, harmonious palette: navy blue, sage green, warm amber, soft sky blue, muted coral, warm sand.
Plain solid cream background (#F6F1EA) that fills the entire image edge to edge –
no border, no frame, no vignette, no drop shadow, no white margin, no rounded corners.
Few objects, plenty of calm empty space, relaxed friendly expressions, no motion lines, no clutter.
Recurring characters (always identical):
"Tedo" – 8-year-old boy, short messy brown hair, navy hoodie;
"Kiki" – 8-year-old girl, dark curly hair in two puffs, amber-striped shirt;
"Mama" – woman, brown shoulder-length hair, sage-green cardigan;
"Papa" – man, short dark hair and beard, warm sand-colored sweater.
The smartphone is a simple rounded rectangle with a navy case; screen content only as simple icons.
Landscape 4:3, main subject centered, everything important inside the middle 80 % of the image.
Absolutely NO text, NO letters, NO numbers, NO words, NO logos anywhere in the image.

Scene: Tedo holds up the phone camera and smiles at Kiki, Kiki gives a thumbs-up and nods (consent).
```

## 15 · quiz_cam_2

```
Use the attached character sheet as strict reference for characters and style.

Calm, modern children's picture-book illustration in a soft flat style.
Gentle rounded shapes, thin soft navy outlines, very little shading, no harsh contrast.
Muted, harmonious palette: navy blue, sage green, warm amber, soft sky blue, muted coral, warm sand.
Plain solid cream background (#F6F1EA) that fills the entire image edge to edge –
no border, no frame, no vignette, no drop shadow, no white margin, no rounded corners.
Few objects, plenty of calm empty space, relaxed friendly expressions, no motion lines, no clutter.
Recurring characters (always identical):
"Tedo" – 8-year-old boy, short messy brown hair, navy hoodie;
"Kiki" – 8-year-old girl, dark curly hair in two puffs, amber-striped shirt;
"Mama" – woman, brown shoulder-length hair, sage-green cardigan;
"Papa" – man, short dark hair and beard, warm sand-colored sweater.
The smartphone is a simple rounded rectangle with a navy case; screen content only as simple icons.
Landscape 4:3, main subject centered, everything important inside the middle 80 % of the image.
Absolutely NO text, NO letters, NO numbers, NO words, NO logos anywhere in the image.

Scene: Kiki's photo gallery shows a blurry picture; her finger taps a trash-can icon, the blurry picture flies into the bin.
```

## 16 · quiz_cam_3

```
Use the attached character sheet as strict reference for characters and style.

Calm, modern children's picture-book illustration in a soft flat style.
Gentle rounded shapes, thin soft navy outlines, very little shading, no harsh contrast.
Muted, harmonious palette: navy blue, sage green, warm amber, soft sky blue, muted coral, warm sand.
Plain solid cream background (#F6F1EA) that fills the entire image edge to edge –
no border, no frame, no vignette, no drop shadow, no white margin, no rounded corners.
Few objects, plenty of calm empty space, relaxed friendly expressions, no motion lines, no clutter.
Recurring characters (always identical):
"Tedo" – 8-year-old boy, short messy brown hair, navy hoodie;
"Kiki" – 8-year-old girl, dark curly hair in two puffs, amber-striped shirt;
"Mama" – woman, brown shoulder-length hair, sage-green cardigan;
"Papa" – man, short dark hair and beard, warm sand-colored sweater.
The smartphone is a simple rounded rectangle with a navy case; screen content only as simple icons.
Landscape 4:3, main subject centered, everything important inside the middle 80 % of the image.
Absolutely NO text, NO letters, NO numbers, NO words, NO logos anywhere in the image.

Scene: Phone screen shows a photo of a friend in front of a house; the house number area is highlighted with a red circle and a magnifier icon.
```

## 17 · quiz_oth_1

```
Use the attached character sheet as strict reference for characters and style.

Calm, modern children's picture-book illustration in a soft flat style.
Gentle rounded shapes, thin soft navy outlines, very little shading, no harsh contrast.
Muted, harmonious palette: navy blue, sage green, warm amber, soft sky blue, muted coral, warm sand.
Plain solid cream background (#F6F1EA) that fills the entire image edge to edge –
no border, no frame, no vignette, no drop shadow, no white margin, no rounded corners.
Few objects, plenty of calm empty space, relaxed friendly expressions, no motion lines, no clutter.
Recurring characters (always identical):
"Tedo" – 8-year-old boy, short messy brown hair, navy hoodie;
"Kiki" – 8-year-old girl, dark curly hair in two puffs, amber-striped shirt;
"Mama" – woman, brown shoulder-length hair, sage-green cardigan;
"Papa" – man, short dark hair and beard, warm sand-colored sweater.
The smartphone is a simple rounded rectangle with a navy case; screen content only as simple icons.
Landscape 4:3, main subject centered, everything important inside the middle 80 % of the image.
Absolutely NO text, NO letters, NO numbers, NO words, NO logos anywhere in the image.

Scene: Tedo holds a phone with a funny photo of a friend making a face; a big question mark between the phone and a group-chat icon.
```

## 18 · quiz_oth_2

```
Use the attached character sheet as strict reference for characters and style.

Calm, modern children's picture-book illustration in a soft flat style.
Gentle rounded shapes, thin soft navy outlines, very little shading, no harsh contrast.
Muted, harmonious palette: navy blue, sage green, warm amber, soft sky blue, muted coral, warm sand.
Plain solid cream background (#F6F1EA) that fills the entire image edge to edge –
no border, no frame, no vignette, no drop shadow, no white margin, no rounded corners.
Few objects, plenty of calm empty space, relaxed friendly expressions, no motion lines, no clutter.
Recurring characters (always identical):
"Tedo" – 8-year-old boy, short messy brown hair, navy hoodie;
"Kiki" – 8-year-old girl, dark curly hair in two puffs, amber-striped shirt;
"Mama" – woman, brown shoulder-length hair, sage-green cardigan;
"Papa" – man, short dark hair and beard, warm sand-colored sweater.
The smartphone is a simple rounded rectangle with a navy case; screen content only as simple icons.
Landscape 4:3, main subject centered, everything important inside the middle 80 % of the image.
Absolutely NO text, NO letters, NO numbers, NO words, NO logos anywhere in the image.

Scene: Kiki says (gesture, no text) "please don't" with crossed hands; Tedo puts his phone away and nods, respectful.
```

## 19 · quiz_p_oth_3

```
Use the attached character sheet as strict reference for characters and style.

Calm, modern children's picture-book illustration in a soft flat style.
Gentle rounded shapes, thin soft navy outlines, very little shading, no harsh contrast.
Muted, harmonious palette: navy blue, sage green, warm amber, soft sky blue, muted coral, warm sand.
Plain solid cream background (#F6F1EA) that fills the entire image edge to edge –
no border, no frame, no vignette, no drop shadow, no white margin, no rounded corners.
Few objects, plenty of calm empty space, relaxed friendly expressions, no motion lines, no clutter.
Recurring characters (always identical):
"Tedo" – 8-year-old boy, short messy brown hair, navy hoodie;
"Kiki" – 8-year-old girl, dark curly hair in two puffs, amber-striped shirt;
"Mama" – woman, brown shoulder-length hair, sage-green cardigan;
"Papa" – man, short dark hair and beard, warm sand-colored sweater.
The smartphone is a simple rounded rectangle with a navy case; screen content only as simple icons.
Landscape 4:3, main subject centered, everything important inside the middle 80 % of the image.
Absolutely NO text, NO letters, NO numbers, NO words, NO logos anywhere in the image.

Scene: Group photo of several children on a phone, Papa and Tedo look at it together, a lock icon and question mark above.
```

## 20 · quiz_vn_1

```
Use the attached character sheet as strict reference for characters and style.

Calm, modern children's picture-book illustration in a soft flat style.
Gentle rounded shapes, thin soft navy outlines, very little shading, no harsh contrast.
Muted, harmonious palette: navy blue, sage green, warm amber, soft sky blue, muted coral, warm sand.
Plain solid cream background (#F6F1EA) that fills the entire image edge to edge –
no border, no frame, no vignette, no drop shadow, no white margin, no rounded corners.
Few objects, plenty of calm empty space, relaxed friendly expressions, no motion lines, no clutter.
Recurring characters (always identical):
"Tedo" – 8-year-old boy, short messy brown hair, navy hoodie;
"Kiki" – 8-year-old girl, dark curly hair in two puffs, amber-striped shirt;
"Mama" – woman, brown shoulder-length hair, sage-green cardigan;
"Papa" – man, short dark hair and beard, warm sand-colored sweater.
The smartphone is a simple rounded rectangle with a navy case; screen content only as simple icons.
Landscape 4:3, main subject centered, everything important inside the middle 80 % of the image.
Absolutely NO text, NO letters, NO numbers, NO words, NO logos anywhere in the image.

Scene: Tedo with headphones listens to a voice message (sound-wave icon on screen) later in a quiet room, relaxed; a small clock shows "later".
```

## 21 · quiz_vn_2

```
Use the attached character sheet as strict reference for characters and style.

Calm, modern children's picture-book illustration in a soft flat style.
Gentle rounded shapes, thin soft navy outlines, very little shading, no harsh contrast.
Muted, harmonious palette: navy blue, sage green, warm amber, soft sky blue, muted coral, warm sand.
Plain solid cream background (#F6F1EA) that fills the entire image edge to edge –
no border, no frame, no vignette, no drop shadow, no white margin, no rounded corners.
Few objects, plenty of calm empty space, relaxed friendly expressions, no motion lines, no clutter.
Recurring characters (always identical):
"Tedo" – 8-year-old boy, short messy brown hair, navy hoodie;
"Kiki" – 8-year-old girl, dark curly hair in two puffs, amber-striped shirt;
"Mama" – woman, brown shoulder-length hair, sage-green cardigan;
"Papa" – man, short dark hair and beard, warm sand-colored sweater.
The smartphone is a simple rounded rectangle with a navy case; screen content only as simple icons.
Landscape 4:3, main subject centered, everything important inside the middle 80 % of the image.
Absolutely NO text, NO letters, NO numbers, NO words, NO logos anywhere in the image.

Scene: Kiki wants to record a voice message, many other kids chat behind her; she walks to a quiet corner, microphone icon on screen.
```

## 22 · quiz_blk_1

```
Use the attached character sheet as strict reference for characters and style.

Calm, modern children's picture-book illustration in a soft flat style.
Gentle rounded shapes, thin soft navy outlines, very little shading, no harsh contrast.
Muted, harmonious palette: navy blue, sage green, warm amber, soft sky blue, muted coral, warm sand.
Plain solid cream background (#F6F1EA) that fills the entire image edge to edge –
no border, no frame, no vignette, no drop shadow, no white margin, no rounded corners.
Few objects, plenty of calm empty space, relaxed friendly expressions, no motion lines, no clutter.
Recurring characters (always identical):
"Tedo" – 8-year-old boy, short messy brown hair, navy hoodie;
"Kiki" – 8-year-old girl, dark curly hair in two puffs, amber-striped shirt;
"Mama" – woman, brown shoulder-length hair, sage-green cardigan;
"Papa" – man, short dark hair and beard, warm sand-colored sweater.
The smartphone is a simple rounded rectangle with a navy case; screen content only as simple icons.
Landscape 4:3, main subject centered, everything important inside the middle 80 % of the image.
Absolutely NO text, NO letters, NO numbers, NO words, NO logos anywhere in the image.

Scene: Phone buzzing with many annoying message bubbles; Kiki shows it to Mama, both look determined.
```

## 23 · quiz_blk_2

```
Use the attached character sheet as strict reference for characters and style.

Calm, modern children's picture-book illustration in a soft flat style.
Gentle rounded shapes, thin soft navy outlines, very little shading, no harsh contrast.
Muted, harmonious palette: navy blue, sage green, warm amber, soft sky blue, muted coral, warm sand.
Plain solid cream background (#F6F1EA) that fills the entire image edge to edge –
no border, no frame, no vignette, no drop shadow, no white margin, no rounded corners.
Few objects, plenty of calm empty space, relaxed friendly expressions, no motion lines, no clutter.
Recurring characters (always identical):
"Tedo" – 8-year-old boy, short messy brown hair, navy hoodie;
"Kiki" – 8-year-old girl, dark curly hair in two puffs, amber-striped shirt;
"Mama" – woman, brown shoulder-length hair, sage-green cardigan;
"Papa" – man, short dark hair and beard, warm sand-colored sweater.
The smartphone is a simple rounded rectangle with a navy case; screen content only as simple icons.
Landscape 4:3, main subject centered, everything important inside the middle 80 % of the image.
Absolutely NO text, NO letters, NO numbers, NO words, NO logos anywhere in the image.

Scene: Phone screen with a contact avatar and a big shield icon closing like a door between the avatar and Tedo; messages bounce off the shield.
```

## 24 · quiz_dat_1

```
Use the attached character sheet as strict reference for characters and style.

Calm, modern children's picture-book illustration in a soft flat style.
Gentle rounded shapes, thin soft navy outlines, very little shading, no harsh contrast.
Muted, harmonious palette: navy blue, sage green, warm amber, soft sky blue, muted coral, warm sand.
Plain solid cream background (#F6F1EA) that fills the entire image edge to edge –
no border, no frame, no vignette, no drop shadow, no white margin, no rounded corners.
Few objects, plenty of calm empty space, relaxed friendly expressions, no motion lines, no clutter.
Recurring characters (always identical):
"Tedo" – 8-year-old boy, short messy brown hair, navy hoodie;
"Kiki" – 8-year-old girl, dark curly hair in two puffs, amber-striped shirt;
"Mama" – woman, brown shoulder-length hair, sage-green cardigan;
"Papa" – man, short dark hair and beard, warm sand-colored sweater.
The smartphone is a simple rounded rectangle with a navy case; screen content only as simple icons.
Landscape 4:3, main subject centered, everything important inside the middle 80 % of the image.
Absolutely NO text, NO letters, NO numbers, NO words, NO logos anywhere in the image.

Scene: Tedo holds a treasure chest with icons inside (house, school, phone, birthday cake), lock on the chest, smiling.
```

## 25 · quiz_dat_2

```
Use the attached character sheet as strict reference for characters and style.

Calm, modern children's picture-book illustration in a soft flat style.
Gentle rounded shapes, thin soft navy outlines, very little shading, no harsh contrast.
Muted, harmonious palette: navy blue, sage green, warm amber, soft sky blue, muted coral, warm sand.
Plain solid cream background (#F6F1EA) that fills the entire image edge to edge –
no border, no frame, no vignette, no drop shadow, no white margin, no rounded corners.
Few objects, plenty of calm empty space, relaxed friendly expressions, no motion lines, no clutter.
Recurring characters (always identical):
"Tedo" – 8-year-old boy, short messy brown hair, navy hoodie;
"Kiki" – 8-year-old girl, dark curly hair in two puffs, amber-striped shirt;
"Mama" – woman, brown shoulder-length hair, sage-green cardigan;
"Papa" – man, short dark hair and beard, warm sand-colored sweater.
The smartphone is a simple rounded rectangle with a navy case; screen content only as simple icons.
Landscape 4:3, main subject centered, everything important inside the middle 80 % of the image.
Absolutely NO text, NO letters, NO numbers, NO words, NO logos anywhere in the image.

Scene: Chat from a grey unknown avatar with icons house + school + name tag; Kiki holds up a stop-sign-shaped hand, then shows Papa.
```

## 26 · quiz_p_dat_3

```
Use the attached character sheet as strict reference for characters and style.

Calm, modern children's picture-book illustration in a soft flat style.
Gentle rounded shapes, thin soft navy outlines, very little shading, no harsh contrast.
Muted, harmonious palette: navy blue, sage green, warm amber, soft sky blue, muted coral, warm sand.
Plain solid cream background (#F6F1EA) that fills the entire image edge to edge –
no border, no frame, no vignette, no drop shadow, no white margin, no rounded corners.
Few objects, plenty of calm empty space, relaxed friendly expressions, no motion lines, no clutter.
Recurring characters (always identical):
"Tedo" – 8-year-old boy, short messy brown hair, navy hoodie;
"Kiki" – 8-year-old girl, dark curly hair in two puffs, amber-striped shirt;
"Mama" – woman, brown shoulder-length hair, sage-green cardigan;
"Papa" – man, short dark hair and beard, warm sand-colored sweater.
The smartphone is a simple rounded rectangle with a navy case; screen content only as simple icons.
Landscape 4:3, main subject centered, everything important inside the middle 80 % of the image.
Absolutely NO text, NO letters, NO numbers, NO words, NO logos anywhere in the image.

Scene: Mama and Kiki sit together at the kitchen table looking at a tablet, open friendly conversation, a small shield with heart icon.
```

## 27 · quiz_snd_1

```
Use the attached character sheet as strict reference for characters and style.

Calm, modern children's picture-book illustration in a soft flat style.
Gentle rounded shapes, thin soft navy outlines, very little shading, no harsh contrast.
Muted, harmonious palette: navy blue, sage green, warm amber, soft sky blue, muted coral, warm sand.
Plain solid cream background (#F6F1EA) that fills the entire image edge to edge –
no border, no frame, no vignette, no drop shadow, no white margin, no rounded corners.
Few objects, plenty of calm empty space, relaxed friendly expressions, no motion lines, no clutter.
Recurring characters (always identical):
"Tedo" – 8-year-old boy, short messy brown hair, navy hoodie;
"Kiki" – 8-year-old girl, dark curly hair in two puffs, amber-striped shirt;
"Mama" – woman, brown shoulder-length hair, sage-green cardigan;
"Papa" – man, short dark hair and beard, warm sand-colored sweater.
The smartphone is a simple rounded rectangle with a navy case; screen content only as simple icons.
Landscape 4:3, main subject centered, everything important inside the middle 80 % of the image.
Absolutely NO text, NO letters, NO numbers, NO words, NO logos anywhere in the image.

Scene: Tedo holds his phone, a photo ready to send; above him a checklist icon with three ticks; his finger waits above the send button.
```

## 28 · quiz_snd_2

```
Use the attached character sheet as strict reference for characters and style.

Calm, modern children's picture-book illustration in a soft flat style.
Gentle rounded shapes, thin soft navy outlines, very little shading, no harsh contrast.
Muted, harmonious palette: navy blue, sage green, warm amber, soft sky blue, muted coral, warm sand.
Plain solid cream background (#F6F1EA) that fills the entire image edge to edge –
no border, no frame, no vignette, no drop shadow, no white margin, no rounded corners.
Few objects, plenty of calm empty space, relaxed friendly expressions, no motion lines, no clutter.
Recurring characters (always identical):
"Tedo" – 8-year-old boy, short messy brown hair, navy hoodie;
"Kiki" – 8-year-old girl, dark curly hair in two puffs, amber-striped shirt;
"Mama" – woman, brown shoulder-length hair, sage-green cardigan;
"Papa" – man, short dark hair and beard, warm sand-colored sweater.
The smartphone is a simple rounded rectangle with a navy case; screen content only as simple icons.
Landscape 4:3, main subject centered, everything important inside the middle 80 % of the image.
Absolutely NO text, NO letters, NO numbers, NO words, NO logos anywhere in the image.

Scene: Kiki laughs at a funny picture on her phone, then pauses and imagines a sad friend in a thought bubble; send button greyed.
```

## 29 · quiz_p_snd_3

```
Use the attached character sheet as strict reference for characters and style.

Calm, modern children's picture-book illustration in a soft flat style.
Gentle rounded shapes, thin soft navy outlines, very little shading, no harsh contrast.
Muted, harmonious palette: navy blue, sage green, warm amber, soft sky blue, muted coral, warm sand.
Plain solid cream background (#F6F1EA) that fills the entire image edge to edge –
no border, no frame, no vignette, no drop shadow, no white margin, no rounded corners.
Few objects, plenty of calm empty space, relaxed friendly expressions, no motion lines, no clutter.
Recurring characters (always identical):
"Tedo" – 8-year-old boy, short messy brown hair, navy hoodie;
"Kiki" – 8-year-old girl, dark curly hair in two puffs, amber-striped shirt;
"Mama" – woman, brown shoulder-length hair, sage-green cardigan;
"Papa" – man, short dark hair and beard, warm sand-colored sweater.
The smartphone is a simple rounded rectangle with a navy case; screen content only as simple icons.
Landscape 4:3, main subject centered, everything important inside the middle 80 % of the image.
Absolutely NO text, NO letters, NO numbers, NO words, NO logos anywhere in the image.

Scene: Tedo shows his phone to Papa, both look at the screen together, Papa gives a calm thumbs-up.
```

## 30 · quiz_surf_1

```
Use the attached character sheet as strict reference for characters and style.

Calm, modern children's picture-book illustration in a soft flat style.
Gentle rounded shapes, thin soft navy outlines, very little shading, no harsh contrast.
Muted, harmonious palette: navy blue, sage green, warm amber, soft sky blue, muted coral, warm sand.
Plain solid cream background (#F6F1EA) that fills the entire image edge to edge –
no border, no frame, no vignette, no drop shadow, no white margin, no rounded corners.
Few objects, plenty of calm empty space, relaxed friendly expressions, no motion lines, no clutter.
Recurring characters (always identical):
"Tedo" – 8-year-old boy, short messy brown hair, navy hoodie;
"Kiki" – 8-year-old girl, dark curly hair in two puffs, amber-striped shirt;
"Mama" – woman, brown shoulder-length hair, sage-green cardigan;
"Papa" – man, short dark hair and beard, warm sand-colored sweater.
The smartphone is a simple rounded rectangle with a navy case; screen content only as simple icons.
Landscape 4:3, main subject centered, everything important inside the middle 80 % of the image.
Absolutely NO text, NO letters, NO numbers, NO words, NO logos anywhere in the image.

Scene: Tedo turns away from a tablet showing a dark scary shape (not graphic), and runs to Mama who opens her arms.
```

## 31 · quiz_c_surf_2

```
Use the attached character sheet as strict reference for characters and style.

Calm, modern children's picture-book illustration in a soft flat style.
Gentle rounded shapes, thin soft navy outlines, very little shading, no harsh contrast.
Muted, harmonious palette: navy blue, sage green, warm amber, soft sky blue, muted coral, warm sand.
Plain solid cream background (#F6F1EA) that fills the entire image edge to edge –
no border, no frame, no vignette, no drop shadow, no white margin, no rounded corners.
Few objects, plenty of calm empty space, relaxed friendly expressions, no motion lines, no clutter.
Recurring characters (always identical):
"Tedo" – 8-year-old boy, short messy brown hair, navy hoodie;
"Kiki" – 8-year-old girl, dark curly hair in two puffs, amber-striped shirt;
"Mama" – woman, brown shoulder-length hair, sage-green cardigan;
"Papa" – man, short dark hair and beard, warm sand-colored sweater.
The smartphone is a simple rounded rectangle with a navy case; screen content only as simple icons.
Landscape 4:3, main subject centered, everything important inside the middle 80 % of the image.
Absolutely NO text, NO letters, NO numbers, NO words, NO logos anywhere in the image.

Scene: Tablet shows a colorful form with input fields and a sticker prize icon; Kiki pulls her hand back, lock icon above.
```

## 32 · quiz_surf_3

```
Use the attached character sheet as strict reference for characters and style.

Calm, modern children's picture-book illustration in a soft flat style.
Gentle rounded shapes, thin soft navy outlines, very little shading, no harsh contrast.
Muted, harmonious palette: navy blue, sage green, warm amber, soft sky blue, muted coral, warm sand.
Plain solid cream background (#F6F1EA) that fills the entire image edge to edge –
no border, no frame, no vignette, no drop shadow, no white margin, no rounded corners.
Few objects, plenty of calm empty space, relaxed friendly expressions, no motion lines, no clutter.
Recurring characters (always identical):
"Tedo" – 8-year-old boy, short messy brown hair, navy hoodie;
"Kiki" – 8-year-old girl, dark curly hair in two puffs, amber-striped shirt;
"Mama" – woman, brown shoulder-length hair, sage-green cardigan;
"Papa" – man, short dark hair and beard, warm sand-colored sweater.
The smartphone is a simple rounded rectangle with a navy case; screen content only as simple icons.
Landscape 4:3, main subject centered, everything important inside the middle 80 % of the image.
Absolutely NO text, NO letters, NO numbers, NO words, NO logos anywhere in the image.

Scene: Tablet shows a flashing gift box with stars and a big fake "win" phone icon; Tedo looks suspicious with a magnifying glass.
```

## 33 · quiz_c_surf_4

```
Use the attached character sheet as strict reference for characters and style.

Calm, modern children's picture-book illustration in a soft flat style.
Gentle rounded shapes, thin soft navy outlines, very little shading, no harsh contrast.
Muted, harmonious palette: navy blue, sage green, warm amber, soft sky blue, muted coral, warm sand.
Plain solid cream background (#F6F1EA) that fills the entire image edge to edge –
no border, no frame, no vignette, no drop shadow, no white margin, no rounded corners.
Few objects, plenty of calm empty space, relaxed friendly expressions, no motion lines, no clutter.
Recurring characters (always identical):
"Tedo" – 8-year-old boy, short messy brown hair, navy hoodie;
"Kiki" – 8-year-old girl, dark curly hair in two puffs, amber-striped shirt;
"Mama" – woman, brown shoulder-length hair, sage-green cardigan;
"Papa" – man, short dark hair and beard, warm sand-colored sweater.
The smartphone is a simple rounded rectangle with a navy case; screen content only as simple icons.
Landscape 4:3, main subject centered, everything important inside the middle 80 % of the image.
Absolutely NO text, NO letters, NO numbers, NO words, NO logos anywhere in the image.

Scene: Kiki plays an online game, a chat icon from a grey unknown avatar pops up with a house and meeting-point icon; she closes it and calls Mama.
```

## 34 · quiz_p_surf_1

```
Use the attached character sheet as strict reference for characters and style.

Calm, modern children's picture-book illustration in a soft flat style.
Gentle rounded shapes, thin soft navy outlines, very little shading, no harsh contrast.
Muted, harmonious palette: navy blue, sage green, warm amber, soft sky blue, muted coral, warm sand.
Plain solid cream background (#F6F1EA) that fills the entire image edge to edge –
no border, no frame, no vignette, no drop shadow, no white margin, no rounded corners.
Few objects, plenty of calm empty space, relaxed friendly expressions, no motion lines, no clutter.
Recurring characters (always identical):
"Tedo" – 8-year-old boy, short messy brown hair, navy hoodie;
"Kiki" – 8-year-old girl, dark curly hair in two puffs, amber-striped shirt;
"Mama" – woman, brown shoulder-length hair, sage-green cardigan;
"Papa" – man, short dark hair and beard, warm sand-colored sweater.
The smartphone is a simple rounded rectangle with a navy case; screen content only as simple icons.
Landscape 4:3, main subject centered, everything important inside the middle 80 % of the image.
Absolutely NO text, NO letters, NO numbers, NO words, NO logos anywhere in the image.

Scene: Child-safe "garden": a tablet screen designed like a walled garden with friendly icons (book, mouse, music), Papa and Tedo explore together.
```

## 35 · quiz_p_surf_3

```
Use the attached character sheet as strict reference for characters and style.

Calm, modern children's picture-book illustration in a soft flat style.
Gentle rounded shapes, thin soft navy outlines, very little shading, no harsh contrast.
Muted, harmonious palette: navy blue, sage green, warm amber, soft sky blue, muted coral, warm sand.
Plain solid cream background (#F6F1EA) that fills the entire image edge to edge –
no border, no frame, no vignette, no drop shadow, no white margin, no rounded corners.
Few objects, plenty of calm empty space, relaxed friendly expressions, no motion lines, no clutter.
Recurring characters (always identical):
"Tedo" – 8-year-old boy, short messy brown hair, navy hoodie;
"Kiki" – 8-year-old girl, dark curly hair in two puffs, amber-striped shirt;
"Mama" – woman, brown shoulder-length hair, sage-green cardigan;
"Papa" – man, short dark hair and beard, warm sand-colored sweater.
The smartphone is a simple rounded rectangle with a navy case; screen content only as simple icons.
Landscape 4:3, main subject centered, everything important inside the middle 80 % of the image.
Absolutely NO text, NO letters, NO numbers, NO words, NO logos anywhere in the image.

Scene: Kitchen timer/clock and a tablet on the table; Tedo puts the tablet away happily and goes to play football.
```

## 36 · quiz_vid_1

```
Use the attached character sheet as strict reference for characters and style.

Calm, modern children's picture-book illustration in a soft flat style.
Gentle rounded shapes, thin soft navy outlines, very little shading, no harsh contrast.
Muted, harmonious palette: navy blue, sage green, warm amber, soft sky blue, muted coral, warm sand.
Plain solid cream background (#F6F1EA) that fills the entire image edge to edge –
no border, no frame, no vignette, no drop shadow, no white margin, no rounded corners.
Few objects, plenty of calm empty space, relaxed friendly expressions, no motion lines, no clutter.
Recurring characters (always identical):
"Tedo" – 8-year-old boy, short messy brown hair, navy hoodie;
"Kiki" – 8-year-old girl, dark curly hair in two puffs, amber-striped shirt;
"Mama" – woman, brown shoulder-length hair, sage-green cardigan;
"Papa" – man, short dark hair and beard, warm sand-colored sweater.
The smartphone is a simple rounded rectangle with a navy case; screen content only as simple icons.
Landscape 4:3, main subject centered, everything important inside the middle 80 % of the image.
Absolutely NO text, NO letters, NO numbers, NO words, NO logos anywhere in the image.

Scene: Tedo on the sofa, phone shows a video player with a big "next" arrow icon and a small countdown circle; he calmly puts the phone face-down on the table, a little clock icon above.
```

## 37 · quiz_vid_2

```
Use the attached character sheet as strict reference for characters and style.

Calm, modern children's picture-book illustration in a soft flat style.
Gentle rounded shapes, thin soft navy outlines, very little shading, no harsh contrast.
Muted, harmonious palette: navy blue, sage green, warm amber, soft sky blue, muted coral, warm sand.
Plain solid cream background (#F6F1EA) that fills the entire image edge to edge –
no border, no frame, no vignette, no drop shadow, no white margin, no rounded corners.
Few objects, plenty of calm empty space, relaxed friendly expressions, no motion lines, no clutter.
Recurring characters (always identical):
"Tedo" – 8-year-old boy, short messy brown hair, navy hoodie;
"Kiki" – 8-year-old girl, dark curly hair in two puffs, amber-striped shirt;
"Mama" – woman, brown shoulder-length hair, sage-green cardigan;
"Papa" – man, short dark hair and beard, warm sand-colored sweater.
The smartphone is a simple rounded rectangle with a navy case; screen content only as simple icons.
Landscape 4:3, main subject centered, everything important inside the middle 80 % of the image.
Absolutely NO text, NO letters, NO numbers, NO words, NO logos anywhere in the image.

Scene: Kiki looks uneasy at a tablet showing a dark cloud shape (not scary in detail); she presses a big pause icon and turns to Papa who sits next to her.
```

## 38 · quiz_vid_3

```
Use the attached character sheet as strict reference for characters and style.

Calm, modern children's picture-book illustration in a soft flat style.
Gentle rounded shapes, thin soft navy outlines, very little shading, no harsh contrast.
Muted, harmonious palette: navy blue, sage green, warm amber, soft sky blue, muted coral, warm sand.
Plain solid cream background (#F6F1EA) that fills the entire image edge to edge –
no border, no frame, no vignette, no drop shadow, no white margin, no rounded corners.
Few objects, plenty of calm empty space, relaxed friendly expressions, no motion lines, no clutter.
Recurring characters (always identical):
"Tedo" – 8-year-old boy, short messy brown hair, navy hoodie;
"Kiki" – 8-year-old girl, dark curly hair in two puffs, amber-striped shirt;
"Mama" – woman, brown shoulder-length hair, sage-green cardigan;
"Papa" – man, short dark hair and beard, warm sand-colored sweater.
The smartphone is a simple rounded rectangle with a navy case; screen content only as simple icons.
Landscape 4:3, main subject centered, everything important inside the middle 80 % of the image.
Absolutely NO text, NO letters, NO numbers, NO words, NO logos anywhere in the image.

Scene: Phone screen with a video and a comment bubble from a grey unknown avatar containing house and birthday-cake icons; Tedo shakes his head and shows the phone to Mama.
```

## 39 · quiz_game_1

```
Use the attached character sheet as strict reference for characters and style.

Calm, modern children's picture-book illustration in a soft flat style.
Gentle rounded shapes, thin soft navy outlines, very little shading, no harsh contrast.
Muted, harmonious palette: navy blue, sage green, warm amber, soft sky blue, muted coral, warm sand.
Plain solid cream background (#F6F1EA) that fills the entire image edge to edge –
no border, no frame, no vignette, no drop shadow, no white margin, no rounded corners.
Few objects, plenty of calm empty space, relaxed friendly expressions, no motion lines, no clutter.
Recurring characters (always identical):
"Tedo" – 8-year-old boy, short messy brown hair, navy hoodie;
"Kiki" – 8-year-old girl, dark curly hair in two puffs, amber-striped shirt;
"Mama" – woman, brown shoulder-length hair, sage-green cardigan;
"Papa" – man, short dark hair and beard, warm sand-colored sweater.
The smartphone is a simple rounded rectangle with a navy case; screen content only as simple icons.
Landscape 4:3, main subject centered, everything important inside the middle 80 % of the image.
Absolutely NO text, NO letters, NO numbers, NO words, NO logos anywhere in the image.

Scene: Kiki plays a colorful game on her phone; a chat bubble from a grey avatar offers a shiny gem icon in exchange for a key icon; Kiki holds the key icon close to her chest, determined.
```

## 40 · quiz_game_2

```
Use the attached character sheet as strict reference for characters and style.

Calm, modern children's picture-book illustration in a soft flat style.
Gentle rounded shapes, thin soft navy outlines, very little shading, no harsh contrast.
Muted, harmonious palette: navy blue, sage green, warm amber, soft sky blue, muted coral, warm sand.
Plain solid cream background (#F6F1EA) that fills the entire image edge to edge –
no border, no frame, no vignette, no drop shadow, no white margin, no rounded corners.
Few objects, plenty of calm empty space, relaxed friendly expressions, no motion lines, no clutter.
Recurring characters (always identical):
"Tedo" – 8-year-old boy, short messy brown hair, navy hoodie;
"Kiki" – 8-year-old girl, dark curly hair in two puffs, amber-striped shirt;
"Mama" – woman, brown shoulder-length hair, sage-green cardigan;
"Papa" – man, short dark hair and beard, warm sand-colored sweater.
The smartphone is a simple rounded rectangle with a navy case; screen content only as simple icons.
Landscape 4:3, main subject centered, everything important inside the middle 80 % of the image.
Absolutely NO text, NO letters, NO numbers, NO words, NO logos anywhere in the image.

Scene: A big blinking shop button with a gem icon and a coin stack on Tedo's phone screen; Tedo raises his finger and looks over to Mama with a questioning face.
```

## 41 · quiz_game_3

```
Use the attached character sheet as strict reference for characters and style.

Calm, modern children's picture-book illustration in a soft flat style.
Gentle rounded shapes, thin soft navy outlines, very little shading, no harsh contrast.
Muted, harmonious palette: navy blue, sage green, warm amber, soft sky blue, muted coral, warm sand.
Plain solid cream background (#F6F1EA) that fills the entire image edge to edge –
no border, no frame, no vignette, no drop shadow, no white margin, no rounded corners.
Few objects, plenty of calm empty space, relaxed friendly expressions, no motion lines, no clutter.
Recurring characters (always identical):
"Tedo" – 8-year-old boy, short messy brown hair, navy hoodie;
"Kiki" – 8-year-old girl, dark curly hair in two puffs, amber-striped shirt;
"Mama" – woman, brown shoulder-length hair, sage-green cardigan;
"Papa" – man, short dark hair and beard, warm sand-colored sweater.
The smartphone is a simple rounded rectangle with a navy case; screen content only as simple icons.
Landscape 4:3, main subject centered, everything important inside the middle 80 % of the image.
Absolutely NO text, NO letters, NO numbers, NO words, NO logos anywhere in the image.

Scene: Tedo after losing a game, small grey storm-cloud bubbles coming from the phone; he presses a shield/block icon and Papa puts a hand on his shoulder.
```

## 42 · quiz_intro_quiz_hero

```
Use the attached character sheet as strict reference for characters and style.

Calm, modern children's picture-book illustration in a soft flat style.
Gentle rounded shapes, thin soft navy outlines, very little shading, no harsh contrast.
Muted, harmonious palette: navy blue, sage green, warm amber, soft sky blue, muted coral, warm sand.
Plain solid cream background (#F6F1EA) that fills the entire image edge to edge –
no border, no frame, no vignette, no drop shadow, no white margin, no rounded corners.
Few objects, plenty of calm empty space, relaxed friendly expressions, no motion lines, no clutter.
Recurring characters (always identical):
"Tedo" – 8-year-old boy, short messy brown hair, navy hoodie;
"Kiki" – 8-year-old girl, dark curly hair in two puffs, amber-striped shirt;
"Mama" – woman, brown shoulder-length hair, sage-green cardigan;
"Papa" – man, short dark hair and beard, warm sand-colored sweater.
The smartphone is a simple rounded rectangle with a navy case; screen content only as simple icons.
Landscape 4:3, main subject centered, everything important inside the middle 80 % of the image.
Absolutely NO text, NO letters, NO numbers, NO words, NO logos anywhere in the image.

Scene: Tedo in a little superhero cape holds his phone proudly, confetti, friendly.
```

## 43 · quiz_intro_call

```
Use the attached character sheet as strict reference for characters and style.

Calm, modern children's picture-book illustration in a soft flat style.
Gentle rounded shapes, thin soft navy outlines, very little shading, no harsh contrast.
Muted, harmonious palette: navy blue, sage green, warm amber, soft sky blue, muted coral, warm sand.
Plain solid cream background (#F6F1EA) that fills the entire image edge to edge –
no border, no frame, no vignette, no drop shadow, no white margin, no rounded corners.
Few objects, plenty of calm empty space, relaxed friendly expressions, no motion lines, no clutter.
Recurring characters (always identical):
"Tedo" – 8-year-old boy, short messy brown hair, navy hoodie;
"Kiki" – 8-year-old girl, dark curly hair in two puffs, amber-striped shirt;
"Mama" – woman, brown shoulder-length hair, sage-green cardigan;
"Papa" – man, short dark hair and beard, warm sand-colored sweater.
The smartphone is a simple rounded rectangle with a navy case; screen content only as simple icons.
Landscape 4:3, main subject centered, everything important inside the middle 80 % of the image.
Absolutely NO text, NO letters, NO numbers, NO words, NO logos anywhere in the image.

Scene: Tedo holds the phone to his ear, big green phone icon beside him.
```

## 44 · quiz_intro_camera

```
Use the attached character sheet as strict reference for characters and style.

Calm, modern children's picture-book illustration in a soft flat style.
Gentle rounded shapes, thin soft navy outlines, very little shading, no harsh contrast.
Muted, harmonious palette: navy blue, sage green, warm amber, soft sky blue, muted coral, warm sand.
Plain solid cream background (#F6F1EA) that fills the entire image edge to edge –
no border, no frame, no vignette, no drop shadow, no white margin, no rounded corners.
Few objects, plenty of calm empty space, relaxed friendly expressions, no motion lines, no clutter.
Recurring characters (always identical):
"Tedo" – 8-year-old boy, short messy brown hair, navy hoodie;
"Kiki" – 8-year-old girl, dark curly hair in two puffs, amber-striped shirt;
"Mama" – woman, brown shoulder-length hair, sage-green cardigan;
"Papa" – man, short dark hair and beard, warm sand-colored sweater.
The smartphone is a simple rounded rectangle with a navy case; screen content only as simple icons.
Landscape 4:3, main subject centered, everything important inside the middle 80 % of the image.
Absolutely NO text, NO letters, NO numbers, NO words, NO logos anywhere in the image.

Scene: Tedo takes a photo of a flower, big camera icon beside him.
```

## 45 · quiz_intro_whatsapp

```
Use the attached character sheet as strict reference for characters and style.

Calm, modern children's picture-book illustration in a soft flat style.
Gentle rounded shapes, thin soft navy outlines, very little shading, no harsh contrast.
Muted, harmonious palette: navy blue, sage green, warm amber, soft sky blue, muted coral, warm sand.
Plain solid cream background (#F6F1EA) that fills the entire image edge to edge –
no border, no frame, no vignette, no drop shadow, no white margin, no rounded corners.
Few objects, plenty of calm empty space, relaxed friendly expressions, no motion lines, no clutter.
Recurring characters (always identical):
"Tedo" – 8-year-old boy, short messy brown hair, navy hoodie;
"Kiki" – 8-year-old girl, dark curly hair in two puffs, amber-striped shirt;
"Mama" – woman, brown shoulder-length hair, sage-green cardigan;
"Papa" – man, short dark hair and beard, warm sand-colored sweater.
The smartphone is a simple rounded rectangle with a navy case; screen content only as simple icons.
Landscape 4:3, main subject centered, everything important inside the middle 80 % of the image.
Absolutely NO text, NO letters, NO numbers, NO words, NO logos anywhere in the image.

Scene: Kiki with phone, generic green chat-bubble icon (no WhatsApp logo).
```

## 46 · quiz_intro_photos

```
Use the attached character sheet as strict reference for characters and style.

Calm, modern children's picture-book illustration in a soft flat style.
Gentle rounded shapes, thin soft navy outlines, very little shading, no harsh contrast.
Muted, harmonious palette: navy blue, sage green, warm amber, soft sky blue, muted coral, warm sand.
Plain solid cream background (#F6F1EA) that fills the entire image edge to edge –
no border, no frame, no vignette, no drop shadow, no white margin, no rounded corners.
Few objects, plenty of calm empty space, relaxed friendly expressions, no motion lines, no clutter.
Recurring characters (always identical):
"Tedo" – 8-year-old boy, short messy brown hair, navy hoodie;
"Kiki" – 8-year-old girl, dark curly hair in two puffs, amber-striped shirt;
"Mama" – woman, brown shoulder-length hair, sage-green cardigan;
"Papa" – man, short dark hair and beard, warm sand-colored sweater.
The smartphone is a simple rounded rectangle with a navy case; screen content only as simple icons.
Landscape 4:3, main subject centered, everything important inside the middle 80 % of the image.
Absolutely NO text, NO letters, NO numbers, NO words, NO logos anywhere in the image.

Scene: Kiki scrolls a photo gallery of colorful thumbnails.
```

## 47 · quiz_intro_messages

```
Use the attached character sheet as strict reference for characters and style.

Calm, modern children's picture-book illustration in a soft flat style.
Gentle rounded shapes, thin soft navy outlines, very little shading, no harsh contrast.
Muted, harmonious palette: navy blue, sage green, warm amber, soft sky blue, muted coral, warm sand.
Plain solid cream background (#F6F1EA) that fills the entire image edge to edge –
no border, no frame, no vignette, no drop shadow, no white margin, no rounded corners.
Few objects, plenty of calm empty space, relaxed friendly expressions, no motion lines, no clutter.
Recurring characters (always identical):
"Tedo" – 8-year-old boy, short messy brown hair, navy hoodie;
"Kiki" – 8-year-old girl, dark curly hair in two puffs, amber-striped shirt;
"Mama" – woman, brown shoulder-length hair, sage-green cardigan;
"Papa" – man, short dark hair and beard, warm sand-colored sweater.
The smartphone is a simple rounded rectangle with a navy case; screen content only as simple icons.
Landscape 4:3, main subject centered, everything important inside the middle 80 % of the image.
Absolutely NO text, NO letters, NO numbers, NO words, NO logos anywhere in the image.

Scene: Tedo types a message, blue chat-bubble icon.
```

## 48 · quiz_intro_surf

```
Use the attached character sheet as strict reference for characters and style.

Calm, modern children's picture-book illustration in a soft flat style.
Gentle rounded shapes, thin soft navy outlines, very little shading, no harsh contrast.
Muted, harmonious palette: navy blue, sage green, warm amber, soft sky blue, muted coral, warm sand.
Plain solid cream background (#F6F1EA) that fills the entire image edge to edge –
no border, no frame, no vignette, no drop shadow, no white margin, no rounded corners.
Few objects, plenty of calm empty space, relaxed friendly expressions, no motion lines, no clutter.
Recurring characters (always identical):
"Tedo" – 8-year-old boy, short messy brown hair, navy hoodie;
"Kiki" – 8-year-old girl, dark curly hair in two puffs, amber-striped shirt;
"Mama" – woman, brown shoulder-length hair, sage-green cardigan;
"Papa" – man, short dark hair and beard, warm sand-colored sweater.
The smartphone is a simple rounded rectangle with a navy case; screen content only as simple icons.
Landscape 4:3, main subject centered, everything important inside the middle 80 % of the image.
Absolutely NO text, NO letters, NO numbers, NO words, NO logos anywhere in the image.

Scene: Tedo and Kiki look at a tablet with a globe icon.
```

## 49 · quiz_feedback_success

```
Use the attached character sheet as strict reference for characters and style.

Calm, modern children's picture-book illustration in a soft flat style.
Gentle rounded shapes, thin soft navy outlines, very little shading, no harsh contrast.
Muted, harmonious palette: navy blue, sage green, warm amber, soft sky blue, muted coral, warm sand.
Plain solid cream background (#F6F1EA) that fills the entire image edge to edge –
no border, no frame, no vignette, no drop shadow, no white margin, no rounded corners.
Few objects, plenty of calm empty space, relaxed friendly expressions, no motion lines, no clutter.
Recurring characters (always identical):
"Tedo" – 8-year-old boy, short messy brown hair, navy hoodie;
"Kiki" – 8-year-old girl, dark curly hair in two puffs, amber-striped shirt;
"Mama" – woman, brown shoulder-length hair, sage-green cardigan;
"Papa" – man, short dark hair and beard, warm sand-colored sweater.
The smartphone is a simple rounded rectangle with a navy case; screen content only as simple icons.
Landscape 4:3, main subject centered, everything important inside the middle 80 % of the image.
Absolutely NO text, NO letters, NO numbers, NO words, NO logos anywhere in the image.

Scene: Tedo and Kiki cheer with arms up, confetti and a big green check mark.
```

## 50 · quiz_feedback_retry

```
Use the attached character sheet as strict reference for characters and style.

Calm, modern children's picture-book illustration in a soft flat style.
Gentle rounded shapes, thin soft navy outlines, very little shading, no harsh contrast.
Muted, harmonious palette: navy blue, sage green, warm amber, soft sky blue, muted coral, warm sand.
Plain solid cream background (#F6F1EA) that fills the entire image edge to edge –
no border, no frame, no vignette, no drop shadow, no white margin, no rounded corners.
Few objects, plenty of calm empty space, relaxed friendly expressions, no motion lines, no clutter.
Recurring characters (always identical):
"Tedo" – 8-year-old boy, short messy brown hair, navy hoodie;
"Kiki" – 8-year-old girl, dark curly hair in two puffs, amber-striped shirt;
"Mama" – woman, brown shoulder-length hair, sage-green cardigan;
"Papa" – man, short dark hair and beard, warm sand-colored sweater.
The smartphone is a simple rounded rectangle with a navy case; screen content only as simple icons.
Landscape 4:3, main subject centered, everything important inside the middle 80 % of the image.
Absolutely NO text, NO letters, NO numbers, NO words, NO logos anywhere in the image.

Scene: Kiki thinks with her finger on her chin, light bulb, friendly – no failure mood.
```

## 51 · quiz_parent_discussion

```
Use the attached character sheet as strict reference for characters and style.

Calm, modern children's picture-book illustration in a soft flat style.
Gentle rounded shapes, thin soft navy outlines, very little shading, no harsh contrast.
Muted, harmonious palette: navy blue, sage green, warm amber, soft sky blue, muted coral, warm sand.
Plain solid cream background (#F6F1EA) that fills the entire image edge to edge –
no border, no frame, no vignette, no drop shadow, no white margin, no rounded corners.
Few objects, plenty of calm empty space, relaxed friendly expressions, no motion lines, no clutter.
Recurring characters (always identical):
"Tedo" – 8-year-old boy, short messy brown hair, navy hoodie;
"Kiki" – 8-year-old girl, dark curly hair in two puffs, amber-striped shirt;
"Mama" – woman, brown shoulder-length hair, sage-green cardigan;
"Papa" – man, short dark hair and beard, warm sand-colored sweater.
The smartphone is a simple rounded rectangle with a navy case; screen content only as simple icons.
Landscape 4:3, main subject centered, everything important inside the middle 80 % of the image.
Absolutely NO text, NO letters, NO numbers, NO words, NO logos anywhere in the image.

Scene: Mama/Papa and child sit together on the sofa looking at a phone.
```
