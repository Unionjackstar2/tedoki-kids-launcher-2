plugins {
  alias(libs.plugins.android.application)
  alias(libs.plugins.kotlin.compose)
}

android {
  namespace = "com.example"
  compileSdk { version = release(36) { minorApiLevel = 1 } }

  defaultConfig {
    // Eigene, eindeutige App-ID (com.example kollidiert mit unzähligen Beispiel-Apps)
    applicationId = "de.tedoki.kids"
    minSdk = 24
    targetSdk = 36
    // In GitHub Actions wird die Build-Nummer automatisch hochgezählt
    versionCode = (System.getenv("VERSION_CODE") ?: "1").toInt()
    versionName = System.getenv("VERSION_NAME") ?: "0.5"

    // Nur ARM (64 + 32 Bit) – keine x86-Varianten
    ndk { abiFilters += listOf("arm64-v8a", "armeabi-v7a") }

    testInstrumentationRunner = "androidx.test.runner.AndroidJUnitRunner"
  }

  // Signatur kommt aus GitHub-Secrets. Unterstützt beide Namensschemata:
  //   KEYSTORE_PATH / KEYSTORE_PASSWORD  (eigene build.yml)
  //   EVR_KEYSTORE  / EVR_KEYSTORE_PASSWORD (build.yml von ELdoroado)
  // Der Alias wird automatisch aus dem Keystore gelesen, falls KEY_ALIAS nicht gesetzt ist.
  fun env(vararg names: String): String? =
    names.firstNotNullOfOrNull { System.getenv(it)?.takeIf { v -> v.isNotBlank() } }

  val ksFile = env("KEYSTORE_PATH", "EVR_KEYSTORE")?.let { file(it) }?.takeIf { it.exists() }
  val ksPassword = env("KEYSTORE_PASSWORD", "EVR_KEYSTORE_PASSWORD")
  val ksAlias = env("KEY_ALIAS", "EVR_KEY_ALIAS") ?: if (ksFile != null && ksPassword != null) {
    runCatching {
      java.security.KeyStore.getInstance(ksFile, ksPassword.toCharArray()).aliases().toList().firstOrNull()
    }.getOrNull()
  } else null
  val hasReleaseKey = ksFile != null && ksPassword != null && ksAlias != null

  signingConfigs {
    if (hasReleaseKey) {
      create("release") {
        storeFile = ksFile
        storePassword = ksPassword
        keyAlias = ksAlias
        keyPassword = env("KEY_PASSWORD", "EVR_KEY_PASSWORD") ?: ksPassword
      }
    }
  }

  buildTypes {
    release {
      isCrunchPngs = false
      isMinifyEnabled = false
      proguardFiles(getDefaultProguardFile("proguard-android-optimize.txt"), "proguard-rules.pro")
      signingConfig = signingConfigs.getByName(if (hasReleaseKey) "release" else "debug")
    }
    // Auch Debug-Builds mit dem festen Schlüssel signieren – sonst hat jede GitHub-APK
    // eine andere Signatur und Updates lassen sich nicht drüberinstallieren.
    debug {
      if (hasReleaseKey) signingConfig = signingConfigs.getByName("release")
    }
  }
  compileOptions {
    sourceCompatibility = JavaVersion.VERSION_17
    targetCompatibility = JavaVersion.VERSION_17
  }
  buildFeatures {
    compose = true
    buildConfig = true
  }
  testOptions { unitTests { isIncludeAndroidResources = true } }
  dependenciesInfo {
    includeInApk = false
    includeInBundle = true
  }
}

dependencies {
  implementation(platform(libs.androidx.compose.bom))
  implementation(libs.androidx.activity.compose)
  implementation(libs.androidx.camera.camera2)
  implementation(libs.androidx.camera.core)
  implementation(libs.androidx.camera.lifecycle)
  implementation(libs.androidx.camera.view)
  implementation(libs.androidx.compose.material.icons.core)
  implementation(libs.androidx.compose.material.icons.extended)
  implementation(libs.androidx.compose.material3)
  implementation(libs.androidx.compose.ui)
  implementation(libs.androidx.compose.ui.graphics)
  implementation(libs.androidx.compose.ui.tooling.preview)
  implementation(libs.androidx.core.ktx)
  implementation(libs.androidx.lifecycle.runtime.ktx)
  implementation(libs.coil.compose)
  implementation(libs.kotlinx.coroutines.android)
  implementation(libs.kotlinx.coroutines.core)
  testImplementation(libs.androidx.compose.ui.test.junit4)
  testImplementation(libs.androidx.core)
  testImplementation(libs.androidx.junit)
  testImplementation(libs.junit)
  testImplementation(libs.kotlinx.coroutines.test)
  testImplementation(libs.robolectric)
  androidTestImplementation(platform(libs.androidx.compose.bom))
  androidTestImplementation(libs.androidx.compose.ui.test.junit4)
  androidTestImplementation(libs.androidx.espresso.core)
  androidTestImplementation(libs.androidx.junit)
  androidTestImplementation(libs.androidx.runner)
  debugImplementation(libs.androidx.compose.ui.test.manifest)
  debugImplementation(libs.androidx.compose.ui.tooling)
}
